import { useState } from "react";
import { Link, useLocation } from "wouter";

const Login = () => {
  const [, setLocation] = useLocation();
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Check if user exists in storage
    const existingUsers = JSON.parse(
      localStorage.getItem("registeredUsers") || "[]",
    );
    const userData = JSON.parse(localStorage.getItem("userData") || "null");

    // For demo purposes, also check basic validation
    if (credentials.email && credentials.password) {
      // Store user session
      localStorage.setItem("userAuth", "true");
      localStorage.setItem("userEmail", credentials.email);
      localStorage.setItem("userLoginTime", new Date().toISOString());

      // Check if user is in trial or has existing data
      if (userData && userData.email === credentials.email) {
        // Check trial status
        if (userData.accountType === "trial") {
          const trialEndDate = new Date(userData.trialEndDate);
          const now = new Date();
          const daysRemaining = Math.ceil(
            (trialEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24),
          );

          if (daysRemaining <= 0) {
            alert(
              "⚠️ Deneme süreniz dolmuş. Hesabınız pasif durumda. Lütfen ödeme yaparak aktifleştirin.",
            );
          } else {
            alert(
              `🎁 Deneme hesabınızla giriş yaptınız. ${daysRemaining} gün kaldı.`,
            );
          }
        } else if (userData.accountType === "active") {
          alert("✅ Aktif hesabınızla giriş yaptınız!");
        }
      }

      // Redirect to user dashboard
      setLocation("/dashboard");
    } else {
      setError("Lütfen email ve şifrenizi girin.");
    }

    setIsLoading(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCredentials((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        {/* Logo Section */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-block">
            <div className="w-16 h-16 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-spiritual-glow">
              <span className="text-white font-bold text-2xl">🕊️</span>
            </div>
          </Link>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-spiritual-turquoise-600 to-spiritual-purple-600 bg-clip-text text-transparent">
            Üye Girişi
          </h1>
          <p className="text-spiritual-gold-600 font-medium mt-2">
            Kutbul Zaman - Manevi Rehberim
          </p>
        </div>

        {/* Login Form */}
        <div className="spiritual-card p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
              >
                Email Adresi
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={credentials.email}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                placeholder="ornek@email.com"
              />
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
              >
                Şifre
              </label>
              <input
                type="password"
                id="password"
                name="password"
                value={credentials.password}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                placeholder="••••••••••••"
              />
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  className="rounded border-spiritual-turquoise-300 text-spiritual-turquoise-600 focus:ring-spiritual-turquoise-500"
                />
                <span className="ml-2 text-sm text-gray-600">Beni hatırla</span>
              </label>
              <Link
                href="/forgot-password"
                className="text-sm text-spiritual-purple-600 hover:text-spiritual-purple-700"
              >
                Şifremi unuttum
              </Link>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-spiritual-turquoise-500 text-white py-3 px-4 rounded-lg font-semibold hover:bg-spiritual-turquoise-600 focus:ring-2 focus:ring-spiritual-turquoise-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Giriş yapılıyor...
                </div>
              ) : (
                "Giriş Yap"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Henüz üye değil misiniz?{" "}
              <Link
                href="/register"
                className="text-spiritual-purple-600 hover:text-spiritual-purple-700 font-medium"
              >
                Hemen üye olun
              </Link>
            </p>
          </div>

          <div className="mt-4 text-center space-y-2">
            <Link
              href="/"
              className="block text-spiritual-turquoise-600 hover:text-spiritual-turquoise-700 font-medium"
            >
              ← Ana Sayfaya Dön
            </Link>
            <Link
              href="/admin-login"
              className="block text-red-600 hover:text-red-800 font-semibold text-sm"
            >
              🔐 Admin Girişi
            </Link>
          </div>
        </div>

        {/* Social Login */}
        <div className="mt-6 spiritual-card p-6">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-4">Sosyal medya ile giriş</p>
            <div className="flex space-x-4 justify-center">
              <button className="flex items-center justify-center w-12 h-12 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors">
                <span className="text-lg">📘</span>
              </button>
              <button className="flex items-center justify-center w-12 h-12 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors">
                <span className="text-lg">📧</span>
              </button>
              <button className="flex items-center justify-center w-12 h-12 bg-blue-400 text-white rounded-full hover:bg-blue-500 transition-colors">
                <span className="text-lg">🐦</span>
              </button>
            </div>
          </div>
        </div>

        {/* Security Info */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            Bu sayfa SSL ile korunmaktadır 🔒
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
