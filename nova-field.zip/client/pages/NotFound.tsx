import { useLocation, Link } from "wouter";
import { useEffect } from "react";

const NotFound = () => {
  const [location] = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location,
    );
  }, [location]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-peaceful-gradient">
      <div className="text-center spiritual-card p-12 max-w-md">
        <div className="text-6xl mb-6">🔍</div>
        <h1 className="text-4xl font-bold mb-4 text-spiritual-purple-700">
          404
        </h1>
        <p className="text-xl text-spiritual-turquoise-600 mb-6">
          Aradığınız sayfa bulunamadı
        </p>
        <p className="text-gray-600 mb-8">
          Bu sayfa mevcut değil veya taşınmış olabilir.
        </p>
        <Link
          href="/"
          className="bg-spiritual-turquoise-500 text-white px-6 py-3 rounded-full hover:bg-spiritual-turquoise-600 transition-colors font-semibold"
        >
          🕊️ Ana Sayfaya Dön
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
