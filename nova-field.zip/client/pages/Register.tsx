import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  findOptimalPlacement,
  generateToken,
  User,
  NEFS_LEVELS,
} from "../lib/mlmSystem";

const Register = () => {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    sponsorId: "",
    agreeTerms: false,
    country: "",
    city: "",
    referralSource: "",
  });
  const [sponsorInfo, setSponsorInfo] = useState<any>(null);
  const [showSponsorDetails, setShowSponsorDetails] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Check for sponsor ID in URL parameters and validate
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sponsorId = urlParams.get("sponsor");
    if (sponsorId) {
      setFormData((prev) => ({ ...prev, sponsorId }));
      validateSponsor(sponsorId);
    }
  }, []);

  const validateSponsor = (sponsorId: string) => {
    // Get all users to validate sponsor
    const allUsers: User[] = JSON.parse(
      localStorage.getItem("allUsers") || "[]",
    );
    const sponsor = allUsers.find((u) => u.id === sponsorId);

    if (sponsor) {
      setSponsorInfo({
        name: `${sponsor.firstName} ${sponsor.lastName}`,
        level: sponsor.nefsLevel,
        nefsName: NEFS_LEVELS[sponsor.nefsLevel - 1]?.name,
        joinDate: sponsor.joinDate,
        teamSize: allUsers.filter((u) => u.sponsorId === sponsorId).length,
      });
      setShowSponsorDetails(true);
    } else {
      setSponsorInfo(null);
      setShowSponsorDetails(false);
    }
  };

  const handleSponsorIdChange = (sponsorId: string) => {
    setFormData((prev) => ({ ...prev, sponsorId }));
    if (sponsorId.length >= 8) {
      // MB123456 format
      validateSponsor(sponsorId);
    } else {
      setSponsorInfo(null);
      setShowSponsorDetails(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Basic validation
    if (formData.password !== formData.confirmPassword) {
      setError("Şifreler eşleşmiyor.");
      setIsLoading(false);
      return;
    }

    if (!formData.agreeTerms) {
      setError("Kullanım koşullarını kabul etmelisiniz.");
      setIsLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError("Şifre en az 6 karakter olmalıdır.");
      setIsLoading(false);
      return;
    }

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 2000));

    try {
      // Generate user ID and member data
      const userId = "MB" + Date.now().toString().slice(-6);
      const registrationDate = new Date();
      const trialEndDate = new Date(
        registrationDate.getTime() + 7 * 24 * 60 * 60 * 1000,
      ); // 7 days later

      const memberData = {
        id: userId,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        sponsorId: formData.sponsorId || "auto-placement",
        nefsLevel: 1, // Start at level 1 (Nefs-i Emmare)
        joinDate: registrationDate.toISOString(),
        status: "trial", // Start with trial status
        accountType: "trial", // trial, active, expired
        trialStartDate: registrationDate.toISOString(),
        trialEndDate: trialEndDate.toISOString(),
        paymentStatus: "pending",
        clonePageUrl: `${window.location.origin}/?sponsor=${userId}`,
        limitedAccess: true,
      };

      // Store member data and login
      localStorage.setItem("userAuth", "true");
      localStorage.setItem("userEmail", formData.email);
      localStorage.setItem("userData", JSON.stringify(memberData));
      localStorage.setItem("userLoginTime", new Date().toISOString());

      alert(
        `🎉 Kayıt başarılı! 7 günlük ücretsiz deneme süreniz başladı.\n\nDeneme süresi: ${trialEndDate.toLocaleDateString("tr-TR")}\nÖdeme yaparak tam erişim sağlayabilirsiniz.`,
      );

      // Redirect to dashboard with trial access
      setLocation("/dashboard");
    } catch (err) {
      setError("Kayıt sırasında bir hata oluştu. Lütfen tekrar deneyin.");
    }

    setIsLoading(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Logo Section */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-block">
            <div className="w-16 h-16 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-spiritual-glow">
              <span className="text-white font-bold text-2xl">🕊️</span>
            </div>
          </Link>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-spiritual-turquoise-600 to-spiritual-purple-600 bg-clip-text text-transparent">
            Manevi Yolculuğa Katılın
          </h1>
          <p className="text-spiritual-gold-600 font-medium mt-2">
            Kutbul Zaman - Manevi Rehberim
          </p>
        </div>

        {/* Registration Form */}
        <div className="spiritual-card p-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-spiritual-purple-700 mb-2">
              Üyelik Kaydı
            </h2>
            <p className="text-gray-600">
              7 Nefs seviyesinde manevi gelişim ve maddi kazanım için hemen üye
              olun.
            </p>
          </div>

          {formData.sponsorId && (
            <div className="mb-6 p-4 bg-spiritual-turquoise-50 border border-spiritual-turquoise-200 rounded-lg">
              <div className="flex items-center">
                <span className="text-2xl mr-3">👥</span>
                <div>
                  <p className="font-semibold text-spiritual-turquoise-700">
                    Sponsor ID: {formData.sponsorId}
                  </p>
                  <p className="text-sm text-gray-600">
                    Bu sponsor tarafından davet edildiniz
                  </p>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="firstName"
                  className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
                >
                  Adınız *
                </label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                  placeholder="Adınız"
                />
              </div>

              <div>
                <label
                  htmlFor="lastName"
                  className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
                >
                  Soyadınız *
                </label>
                <input
                  type="text"
                  id="lastName"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                  placeholder="Soyadınız"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
              >
                Email Adresi *
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                placeholder="ornek@email.com"
              />
            </div>

            <div>
              <label
                htmlFor="phone"
                className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
              >
                Telefon Numarası
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                placeholder="+90 (555) 123 45 67"
              />
            </div>

            <div>
              <label
                htmlFor="sponsorId"
                className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
              >
                Sponsor ID (Opsiyonel)
              </label>
              <input
                type="text"
                id="sponsorId"
                name="sponsorId"
                value={formData.sponsorId}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                placeholder="Sizi davet eden kişinin ID'si"
              />
              <p className="text-xs text-gray-500 mt-1">
                Sponsor ID'niz yoksa otomatik yerleştirme yapılacaktır
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
                >
                  Şifre *
                </label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                  placeholder="••••••��•••••"
                />
              </div>

              <div>
                <label
                  htmlFor="confirmPassword"
                  className="block text-sm font-medium text-spiritual-turquoise-700 mb-2"
                >
                  Şifre Tekrar *
                </label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent transition-all"
                  placeholder="••••••••••••"
                />
              </div>
            </div>

            <div className="flex items-start">
              <input
                type="checkbox"
                id="agreeTerms"
                name="agreeTerms"
                checked={formData.agreeTerms}
                onChange={handleInputChange}
                required
                className="mt-1 rounded border-spiritual-turquoise-300 text-spiritual-turquoise-600 focus:ring-spiritual-turquoise-500"
              />
              <label
                htmlFor="agreeTerms"
                className="ml-3 text-sm text-gray-600"
              >
                <Link
                  href="/terms"
                  className="text-spiritual-purple-600 hover:text-spiritual-purple-700"
                >
                  Kullanım Koşulları
                </Link>{" "}
                ve{" "}
                <Link
                  href="/privacy"
                  className="text-spiritual-purple-600 hover:text-spiritual-purple-700"
                >
                  Gizlilik Politikası
                </Link>
                'nı okudum ve kabul ediyorum.
              </label>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-spiritual-purple-500 text-white py-3 px-4 rounded-lg font-semibold hover:bg-spiritual-purple-600 focus:ring-2 focus:ring-spiritual-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Kayıt işlemi yapılıyor...
                </div>
              ) : (
                "🌿 7 Günlük Ücretsiz Deneme Başlat"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Zaten üye misiniz?{" "}
              <Link
                href="/login"
                className="text-spiritual-turquoise-600 hover:text-spiritual-turquoise-700 font-medium"
              >
                Giriş yapın
              </Link>
            </p>
          </div>

          <div className="mt-4 text-center space-y-2">
            <Link
              href="/"
              className="block text-spiritual-turquoise-600 hover:text-spiritual-turquoise-700 font-medium"
            >
              ← Ana Sayfaya Dön
            </Link>
            <Link
              href="/admin-login"
              className="block text-red-600 hover:text-red-800 font-semibold text-sm"
            >
              🔐 Admin Girişi
            </Link>
          </div>
        </div>

        {/* Trial & Pricing Info */}
        <div className="mt-8 spiritual-card p-6 text-center">
          <h3 className="text-xl font-bold text-spiritual-purple-700 mb-4">
            💰 Üyelik Bilgileri
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
              <h4 className="font-semibold text-green-700">
                🎁 Ücretsiz Deneme
              </h4>
              <p className="text-2xl font-bold text-green-600">7 Gün</p>
              <p className="text-sm text-gray-600">Sınırlı erişim</p>
            </div>
            <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
              <h4 className="font-semibold text-spiritual-turquoise-700">
                Başlangıç Ücreti
              </h4>
              <p className="text-2xl font-bold text-spiritual-turquoise-600">
                $100
              </p>
              <p className="text-sm text-gray-600">Tek seferlik ödeme</p>
            </div>
            <div className="bg-spiritual-gold-50 p-4 rounded-lg">
              <h4 className="font-semibold text-spiritual-gold-700">
                Aylık Abonelik
              </h4>
              <p className="text-2xl font-bold text-spiritual-gold-600">$10</p>
              <p className="text-sm text-gray-600">Her ay otomatik</p>
            </div>
          </div>
          <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              ⚠️ 7 günlük deneme süresi sonunda ödeme yapmazsanız hesabınız
              pasif duruma geçer.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
