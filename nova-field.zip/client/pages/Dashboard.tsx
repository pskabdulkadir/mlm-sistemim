import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";

interface UserStats {
  nefsLevel: number;
  totalEarnings: number;
  monthlyEarnings: number;
  leftLeg: number;
  rightLeg: number;
  totalReferrals: number;
  activeReferrals: number;
  pendingCommissions: number;
  walletBalance: number;
  totalWithdrawn: number;
}

interface TeamMember {
  id: string;
  name: string;
  email: string;
  joinDate: string;
  nefsLevel: number;
  position: "left" | "right";
  status: "active" | "inactive";
  totalEarnings: number;
  directReferrals: number;
}

interface Transaction {
  id: string;
  type: "deposit" | "withdrawal" | "commission" | "bonus";
  amount: number;
  date: string;
  description: string;
  status: "completed" | "pending" | "failed";
}

const Dashboard = () => {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const [meditationTime, setMeditationTime] = useState(10);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds

  const [user, setUser] = useState({
    name: "Kullanıcı",
    email: "",
    memberId: "MB123456",
    joinDate: "2024-01-15",
    clonePageUrl: "",
    phone: "+90 555 123 45 67",
    address: "İstanbul, Türkiye",
    bankAccount: "**** **** **** 1234",
    iban: "",
  });

  const [stats, setStats] = useState<UserStats>({
    nefsLevel: 1,
    totalEarnings: 450.75,
    monthlyEarnings: 125.3,
    leftLeg: 8,
    rightLeg: 5,
    totalReferrals: 13,
    activeReferrals: 11,
    pendingCommissions: 85.5,
    walletBalance: 245.8,
    totalWithdrawn: 204.95,
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [teamMembers] = useState<TeamMember[]>([
    {
      id: "MB123457",
      name: "Ahmet Yılmaz",
      email: "ahmet@example.com",
      joinDate: "2024-01-20",
      nefsLevel: 2,
      position: "left",
      status: "active",
      totalEarnings: 125.5,
      directReferrals: 3,
    },
    {
      id: "MB123458",
      name: "Fatma Kaya",
      email: "fatma@example.com",
      joinDate: "2024-01-25",
      nefsLevel: 1,
      position: "right",
      status: "active",
      totalEarnings: 78.25,
      directReferrals: 2,
    },
    {
      id: "MB123459",
      name: "Mehmet Özkan",
      email: "mehmet@example.com",
      joinDate: "2024-02-01",
      nefsLevel: 3,
      position: "left",
      status: "active",
      totalEarnings: 234.75,
      directReferrals: 5,
    },
  ]);

  const [transactions] = useState<Transaction[]>([
    {
      id: "TX001",
      type: "commission",
      amount: 25.5,
      date: "2024-02-15",
      description: "Sponsor komisyonu - Ahmet Y.",
      status: "completed",
    },
    {
      id: "TX002",
      type: "bonus",
      amount: 12.0,
      date: "2024-02-14",
      description: "Seviye bonusu - Nefs Level 1",
      status: "completed",
    },
    {
      id: "TX003",
      type: "withdrawal",
      amount: -50.0,
      date: "2024-02-13",
      description: "Banka hesabına çekim",
      status: "completed",
    },
    {
      id: "TX004",
      type: "commission",
      amount: 18.75,
      date: "2024-02-12",
      description: "İkili komisyon - Sol bacak",
      status: "completed",
    },
  ]);

  const [trialStatus, setTrialStatus] = useState({
    isTrialUser: false,
    daysRemaining: 0,
    trialExpired: false,
    accountLocked: false,
  });

  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const checkTrialStatus = () => {
    const userData = localStorage.getItem("userData");
    if (userData) {
      const user = JSON.parse(userData);
      if (user.accountType === "trial") {
        const trialEndDate = new Date(user.trialEndDate);
        const now = new Date();
        const daysRemaining = Math.ceil(
          (trialEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24),
        );

        if (daysRemaining <= 0) {
          // Trial expired
          setTrialStatus({
            isTrialUser: true,
            daysRemaining: 0,
            trialExpired: true,
            accountLocked: true,
          });
          // Update user status to expired
          const updatedUser = {
            ...user,
            accountType: "expired",
            status: "inactive",
          };
          localStorage.setItem("userData", JSON.stringify(updatedUser));
        } else {
          // Trial active
          setTrialStatus({
            isTrialUser: true,
            daysRemaining: daysRemaining,
            trialExpired: false,
            accountLocked: false,
          });
        }
      } else if (user.accountType === "active") {
        setTrialStatus({
          isTrialUser: false,
          daysRemaining: 0,
          trialExpired: false,
          accountLocked: false,
        });
      } else if (user.accountType === "expired") {
        setTrialStatus({
          isTrialUser: true,
          daysRemaining: 0,
          trialExpired: true,
          accountLocked: true,
        });
      }
    }
  };

  const activateAccount = () => {
    const userData = localStorage.getItem("userData");
    if (userData) {
      const user = JSON.parse(userData);
      const updatedUser = {
        ...user,
        accountType: "active",
        status: "active",
        paymentStatus: "paid",
        activationDate: new Date().toISOString(),
        limitedAccess: false,
      };
      localStorage.setItem("userData", JSON.stringify(updatedUser));
      setTrialStatus({
        isTrialUser: false,
        daysRemaining: 0,
        trialExpired: false,
        accountLocked: false,
      });
      alert(
        "🎉 Hesabınız başarıyla aktifleştirildi! Tüm özelliklere tam erişim sağladınız.",
      );
    }
  };

  useEffect(() => {
    // Check user authentication
    const isUserAuth = localStorage.getItem("userAuth");
    const userEmail = localStorage.getItem("userEmail");

    if (!isUserAuth) {
      setLocation("/login");
      return;
    }

    // Check trial status
    checkTrialStatus();

    // Set user data
    if (userEmail) {
      setUser((prev) => ({
        ...prev,
        email: userEmail,
        name: userEmail.split("@")[0],
        clonePageUrl: `${window.location.origin}/?sponsor=${prev.memberId}`,
      }));
    }
  }, [setLocation]);

  // Meditation timer effect
  useEffect(() => {
    let interval: number;
    if (isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsTimerRunning(false);
      alert("🧘‍♂️ Meditasyon tamamlandı! Ruhunuz arındı.");
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timeLeft]);

  const handleLogout = () => {
    localStorage.removeItem("userAuth");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userLoginTime");
    setLocation("/login");
  };

  const nefsLevels = [
    {
      level: 1,
      name: "Nefs-i Emmare",
      icon: "🌿",
      commission: 20,
      minReferrals: 1,
    },
    {
      level: 2,
      name: "Nefs-i Levvame",
      icon: "🌱",
      commission: 15,
      minReferrals: 2,
    },
    {
      level: 3,
      name: "Nefs-i Mülhime",
      icon: "🌾",
      commission: 12,
      minReferrals: 4,
    },
    {
      level: 4,
      name: "Nefs-i Mutmainne",
      icon: "🌼",
      commission: 10,
      minReferrals: 8,
    },
    {
      level: 5,
      name: "Nefs-i Râziye",
      icon: "🌸",
      commission: 8,
      minReferrals: 16,
    },
    {
      level: 6,
      name: "Nefs-i Mardiyye",
      icon: "🌷",
      commission: 6,
      minReferrals: 32,
    },
    {
      level: 7,
      name: "Nefs-i Kâmile",
      icon: "🌺",
      commission: 4,
      minReferrals: 64,
    },
  ];

  const currentNefs = nefsLevels[stats.nefsLevel - 1];
  const nextNefs = nefsLevels[stats.nefsLevel];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const copyCloneUrl = () => {
    navigator.clipboard.writeText(user.clonePageUrl);
    alert("Klon sayfa URL'si kopyalandı!");
  };

  // Wallet operations
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [depositAmount, setDepositAmount] = useState("");
  const [receipt, setReceipt] = useState<File | null>(null);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawReason, setWithdrawReason] = useState("");
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [transferAmount, setTransferAmount] = useState("");
  const [transferMemberId, setTransferMemberId] = useState("");

  const ADMIN_IBAN = "TR86 0011 1000 0000 0091 7751 22";
  const ADMIN_BANK = "QNB Finans Bank";

  const handleDeposit = () => {
    if (trialStatus.accountLocked) {
      alert(
        "⚠️ Hesabınız pasif durumda. Para yatırma işlemi için hesabınızı aktifleştirin.",
      );
      return;
    }
    setShowDepositModal(true);
  };

  // Iyzipay Payment Integration
  const redirectToIyzipay = (amount: number, description: string) => {
    // Iyzipay.com entegrasyonu - gerçek uygulamada API anahtarları ve endpoint'ler kullanılacak
    const iyzipayData = {
      amount: amount,
      currency: "USD",
      description: description,
      userEmail: user.email,
      userName: user.name,
      memberId: user.memberId,
    };

    // Demo amaçlı alert - gerçek uygulamada Iyzipay API'sine POST request yapılacak
    alert(
      `🔄 Iyzipay.com sanal POS'a yönlendiriliyorsunuz...\n\nÖdeme Detayları:\n- Tutar: $${amount}\n- Açıklama: ${description}\n- Email: ${user.email}\n\nGüvenli ödeme için Iyzipay kullanılıyor.`,
    );

    // Gerçek entegrasyonda burası Iyzipay ödeme sayfasına yönlendirecek
    // window.location.href = `https://sandbox-api.iyzipay.com/payment/checkout?token=${paymentToken}`;

    console.log("Iyzipay payment initiated:", iyzipayData);
  };

  const submitDeposit = () => {
    if (!depositAmount || !receipt) {
      alert("Lütfen tutarı girin ve dekont yükleyin!");
      return;
    }

    // Create withdrawal request for admin approval
    const depositRequest = {
      id: `DEP${Date.now()}`,
      userId: user.memberId,
      userName: user.name,
      amount: Number(depositAmount),
      type: "deposit",
      receipt: receipt.name,
      date: new Date().toISOString(),
      status: "pending",
    };

    // Store in localStorage (in real app, send to server)
    const existingRequests = JSON.parse(
      localStorage.getItem("adminRequests") || "[]",
    );
    existingRequests.push(depositRequest);
    localStorage.setItem("adminRequests", JSON.stringify(existingRequests));

    alert(
      `Para yatırma talebiniz alındı! Admin onayından sonra bakiyenize eklenecektir.\n\nAdmin IBAN: ${ADMIN_IBAN}\nBanka: ${ADMIN_BANK}\nTutar: $${depositAmount}`,
    );

    setShowDepositModal(false);
    setDepositAmount("");
    setReceipt(null);
  };

  const handleWithdraw = () => {
    if (trialStatus.accountLocked) {
      alert(
        "⚠️ Hesabınız pasif durumda. Para çekme işlemi için hesabınızı aktifleştirin.",
      );
      return;
    }
    setShowWithdrawModal(true);
  };

  const submitWithdraw = () => {
    if (!withdrawAmount || !withdrawReason) {
      alert("Lütfen tüm alanları doldurun!");
      return;
    }

    if (Number(withdrawAmount) > stats.walletBalance) {
      alert("Yetersiz bakiye!");
      return;
    }

    // Create withdrawal request for admin approval
    const withdrawRequest = {
      id: `WTH${Date.now()}`,
      userId: user.memberId,
      userName: user.name,
      amount: Number(withdrawAmount),
      reason: withdrawReason,
      type: "withdraw",
      date: new Date().toISOString(),
      status: "pending",
      userIBAN: user.iban || "Belirtilmemiş",
    };

    // Store in localStorage (in real app, send to server)
    const existingRequests = JSON.parse(
      localStorage.getItem("adminRequests") || "[]",
    );
    existingRequests.push(withdrawRequest);
    localStorage.setItem("adminRequests", JSON.stringify(existingRequests));

    alert(
      `Para çekme talebiniz admin onayına gönderildi!\nTutar: $${withdrawAmount}\nDurum: Onay bekliyor`,
    );

    setShowWithdrawModal(false);
    setWithdrawAmount("");
    setWithdrawReason("");
  };

  const handleTransfer = () => {
    if (trialStatus.accountLocked) {
      alert(
        "⚠️ Hesabınız pasif durumda. Transfer işlemi için hesabınızı aktifleştirin.",
      );
      return;
    }
    setShowTransferModal(true);
  };

  const submitTransfer = () => {
    if (!transferAmount || !transferMemberId) {
      alert("Lütfen tüm alanları doldurun!");
      return;
    }

    if (Number(transferAmount) > stats.walletBalance) {
      alert("Yetersiz bakiye!");
      return;
    }

    if (transferMemberId === user.memberId) {
      alert("Kendi hesabınıza transfer yapamazsınız!");
      return;
    }

    // Process the transfer
    setStats((prev) => ({
      ...prev,
      walletBalance: prev.walletBalance - Number(transferAmount),
    }));

    // Create transfer record
    const transferRecord = {
      id: `TRF${Date.now()}`,
      fromUserId: user.memberId,
      fromUserName: user.name,
      toUserId: transferMemberId,
      amount: Number(transferAmount),
      type: "transfer",
      date: new Date().toISOString(),
      status: "completed",
    };

    // Store transfer record
    const existingTransfers = JSON.parse(
      localStorage.getItem("transfers") || "[]",
    );
    existingTransfers.push(transferRecord);
    localStorage.setItem("transfers", JSON.stringify(existingTransfers));

    alert(
      `$${transferAmount} ${transferMemberId} üyesine başarıyla transfer edildi!`,
    );

    setShowTransferModal(false);
    setTransferAmount("");
    setTransferMemberId("");
  };

  // Social media sharing with auto sponsor registration
  const registerSponsorActivity = (platform: string) => {
    const activityRecord = {
      id: `SHA${Date.now()}`,
      sponsorId: user.memberId,
      sponsorName: user.name,
      platform: platform,
      sharedUrl: user.clonePageUrl,
      date: new Date().toISOString(),
      clicks: 0,
    };

    // Store sharing activity
    const existingShares = JSON.parse(
      localStorage.getItem("sponsorShares") || "[]",
    );
    existingShares.push(activityRecord);
    localStorage.setItem("sponsorShares", JSON.stringify(existingShares));

    console.log(
      `Sponsor activity registered: ${user.memberId} shared on ${platform}`,
    );
  };

  const shareOnFacebook = () => {
    registerSponsorActivity("Facebook");
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(user.clonePageUrl)}`;
    window.open(url, "_blank");
    alert(
      `Klon sayfa linkiniz Facebook'ta paylaşıldı!\nSponsor ID: ${user.memberId}\nReferans linki otomatik kayıtlı.`,
    );
  };

  const shareOnTwitter = () => {
    registerSponsorActivity("Twitter");
    const text =
      "Kutbul Zaman - Manevi Rehberim ile manevi gelişim yolculuğuna katıl!";
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(user.clonePageUrl)}`;
    window.open(url, "_blank");
    alert(
      `Klon sayfa linkiniz Twitter'da paylaşıldı!\nSponsor ID: ${user.memberId}\nReferans linki otomatik kayıtlı.`,
    );
  };

  const shareOnWhatsApp = () => {
    registerSponsorActivity("WhatsApp");
    const text = `Kutbul Zaman - Manevi Rehberim ile manevi gelişim yolculuğuna katıl! ${user.clonePageUrl}`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
    alert(
      `Klon sayfa linkiniz WhatsApp'ta paylaşıldı!\nSponsor ID: ${user.memberId}\nReferans linki otomatik kayıtlı.`,
    );
  };

  const shareViaEmail = () => {
    registerSponsorActivity("Email");
    const subject = "Kutbul Zaman - Manevi Rehberim";
    const body = `Merhaba,\n\nKutbul Zaman - Manevi Rehberim platformuna katılmak için bu özel linki kullanabilirsiniz:\n\n${user.clonePageUrl}\n\nBu link ${user.memberId} sponsor numarası ile kayıtlıdır.\n\nManevi gelişim ve maddi kazanç için harika bir fırsat!`;
    const url = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(url, "_blank");
    alert(
      `Klon sayfa linkiniz Email ile paylaşıldı!\nSponsor ID: ${user.memberId}\nReferans linki otomatik kayıtlı.`,
    );
  };

  // Update profile
  const handleProfileUpdate = () => {
    // Profile update logic
    alert("Profil bilgileriniz başarıyla güncellendi!");
  };

  // Meditation YouTube integration
  const [meditationUrl, setMeditationUrl] = useState(
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  ); // Admin can change this

  const playMeditationMusic = () => {
    window.open(meditationUrl, "_blank");
  };

  // Special prayers with auto-updating content
  const [dailyPrayers, setDailyPrayers] = useState({
    rizik:
      "اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا - Allah'ım! Bize rızık olarak verdiğin şeylerde bize bereket ver.",
    saglik:
      "اللَّهُمَّ اشْفِ مَرْضَانَا وَمَرْضَى الْمُسْلِمِينَ - Allah'ım! Hastalarımızı ve Müslümanların hastalarını şifa et.",
    temizlik:
      "اللَّهُمَّ طَهِّرْ قَلْبِي مِنَ النِّفَاقِ - Allah'ım! Kalbimi nifaktan temizle.",
  });

  // Auto-update prayers daily (this would be connected to an API in real implementation)
  useEffect(() => {
    const updatePrayers = () => {
      // In real implementation, this would fetch from an Islamic prayers API
      const prayers = [
        "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
        "اللَّهُمَّ أَصْلِحْ لِي دِينِي الَّذِي هُوَ عِصْمَةُ أَمْرِي",
        "رَبَّنَا اغْفِرْ لَنَا ذُنُوبَنَا وَإِسْرَافَنَا فِي أَمْرِنَا",
      ];
      const randomPrayer = prayers[Math.floor(Math.random() * prayers.length)];
      // Update prayers periodically
    };

    const interval = setInterval(updatePrayers, 24 * 60 * 60 * 1000); // Daily
    return () => clearInterval(interval);
  }, []);

  // Dream interpretation with auto-response
  const [dreamInput, setDreamInput] = useState("");
  const [dreamInterpretation, setDreamInterpretation] = useState("");

  const interpretDream = async () => {
    if (!dreamInput.trim()) return;

    // Simple AI-like interpretation based on keywords
    let interpretation = "🌙 **Rüya Tahlili:**\n\n";

    const keywords = dreamInput.toLowerCase();

    if (keywords.includes("su") || keywords.includes("deniz")) {
      interpretation += "💧 Su görmek bereket ve temizliği simgeler.\n";
    }
    if (keywords.includes("kuş") || keywords.includes("uçmak")) {
      interpretation +=
        "🕊️ Kuş veya uçma özgürlük ve manevi yükselişi işaret eder.\n";
    }
    if (keywords.includes("ışık") || keywords.includes("nur")) {
      interpretation += "✨ Işık görmek hidayet ve rehberlik alametidir.\n";
    }
    if (keywords.includes("ağaç") || keywords.includes("yeşil")) {
      interpretation += "🌳 Yeşillik ve ağaç büyüme ve bereketi simgeler.\n";
    }

    interpretation +=
      "\n📚 Bu genel bir yorumdur. Detaylı tabir için uzman görüşü alınız.";

    setDreamInterpretation(interpretation);
  };

  // Generate QR Code for clone page
  const generateQRCode = () => {
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(user.clonePageUrl)}`;
    const newWindow = window.open();
    newWindow.document.write(`
      <html>
        <head><title>QR Kod - ${user.name}</title></head>
        <body style="text-align: center; padding: 50px;">
          <h2>Kişisel QR Kodunuz</h2>
          <img src="${qrUrl}" alt="QR Code" style="border: 2px solid #ccc; padding: 20px;">
          <p>Bu QR kodu yazdırıp fiziksel materyallerde kullanabilirsiniz</p>
          <p>${user.clonePageUrl}</p>
        </body>
      </html>
    `);
  };

  const startMeditation = () => {
    setTimeLeft(meditationTime * 60);
    setIsTimerRunning(true);
  };

  const stopMeditation = () => {
    setIsTimerRunning(false);
  };

  const renderOverview = () => (
    <div className="space-y-8">
      {/* Current Nefs Level */}
      <div className="spiritual-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-2xl font-bold text-spiritual-purple-700">
              Mevcut Nefs Seviyeniz
            </h3>
            <p className="text-gray-600">Manevi gelişim yolculuğunuz</p>
          </div>
          <div className="text-6xl">{currentNefs.icon}</div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-xl font-semibold text-spiritual-turquoise-700 mb-2">
              {currentNefs.name}
            </h4>
            <p className="text-lg text-spiritual-purple-600 mb-4">
              Seviye {stats.nefsLevel} - %{currentNefs.commission} Komisyon
            </p>

            {nextNefs && (
              <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
                <p className="text-sm text-spiritual-turquoise-700 mb-2">
                  <strong>Sonraki Seviye:</strong> {nextNefs.name}
                </p>
                <p className="text-sm text-gray-600">
                  {nextNefs.minReferrals - stats.activeReferrals} aktif üye daha
                  gerekli
                </p>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div
                    className="bg-spiritual-turquoise-500 h-2 rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.min(100, (stats.activeReferrals / nextNefs.minReferrals) * 100)}%`,
                    }}
                  ></div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="bg-white p-4 rounded-lg border border-spiritual-turquoise-200">
              <p className="text-sm text-gray-600">Toplam Kazanç</p>
              <p className="text-2xl font-bold text-spiritual-gold-600">
                {formatCurrency(stats.totalEarnings)}
              </p>
            </div>
            <div className="bg-white p-4 rounded-lg border border-spiritual-turquoise-200">
              <p className="text-sm text-gray-600">Cüzdan Bakiyesi</p>
              <p className="text-2xl font-bold text-spiritual-turquoise-600">
                {formatCurrency(stats.walletBalance)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">👥</div>
          <h4 className="font-semibold text-spiritual-turquoise-700">
            Toplam Üyeler
          </h4>
          <p className="text-2xl font-bold text-spiritual-purple-600">
            {stats.totalReferrals}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">✅</div>
          <h4 className="font-semibold text-spiritual-turquoise-700">
            Aktif Üyeler
          </h4>
          <p className="text-2xl font-bold text-spiritual-purple-600">
            {stats.activeReferrals}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">⚖️</div>
          <h4 className="font-semibold text-spiritual-turquoise-700">
            İkili Ağaç
          </h4>
          <p className="text-lg text-spiritual-purple-600">
            Sol: {stats.leftLeg} | Sağ: {stats.rightLeg}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">💰</div>
          <h4 className="font-semibold text-spiritual-turquoise-700">
            E-Cüzdan
          </h4>
          <p className="text-2xl font-bold text-spiritual-gold-600">
            {formatCurrency(stats.walletBalance)}
          </p>
        </div>
      </div>

      {/* Daily Spiritual Content */}
      <div className="spiritual-card p-6">
        <h3 className="text-xl font-bold text-spiritual-purple-700 mb-4">
          🤲 Günün Manevi Mesajı
        </h3>
        <blockquote className="text-lg italic text-spiritual-turquoise-700 mb-2">
          "Kim nefsini bilirse, Rabbini bilir."
        </blockquote>
        <p className="text-spiritual-purple-600">- Hz. Ali (ra)</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => setActiveTab("meditation")}
            className="bg-spiritual-turquoise-50 p-4 rounded-lg text-center hover:bg-spiritual-turquoise-100 transition-colors"
          >
            <div className="text-3xl mb-2">🧘‍♂️</div>
            <h4 className="font-semibold text-spiritual-turquoise-700">
              Meditasyon
            </h4>
          </button>
          <button
            onClick={() => setActiveTab("prayers")}
            className="bg-spiritual-purple-50 p-4 rounded-lg text-center hover:bg-spiritual-purple-100 transition-colors"
          >
            <div className="text-3xl mb-2">🤲</div>
            <h4 className="font-semibold text-spiritual-purple-700">
              Günlük Dualar
            </h4>
          </button>
          <button
            onClick={() => setActiveTab("dreams")}
            className="bg-spiritual-gold-50 p-4 rounded-lg text-center hover:bg-spiritual-gold-100 transition-colors"
          >
            <div className="text-3xl mb-2">🌙</div>
            <h4 className="font-semibold text-spiritual-gold-700">
              Rüya Yorumu
            </h4>
          </button>
        </div>
      </div>
    </div>
  );

  const renderEarnings = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        💰 Kazanç Detayları & E-Cüzdan
      </h3>

      {/* Wallet Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">💳</div>
          <h4 className="font-semibold text-spiritual-turquoise-700">
            Cüzdan Bakiyesi
          </h4>
          <p className="text-2xl font-bold text-spiritual-turquoise-600">
            {formatCurrency(stats.walletBalance)}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">📈</div>
          <h4 className="font-semibold text-spiritual-purple-700">Bu Ay</h4>
          <p className="text-2xl font-bold text-spiritual-purple-600">
            {formatCurrency(stats.monthlyEarnings)}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">💎</div>
          <h4 className="font-semibold text-spiritual-gold-700">
            Toplam Kazanç
          </h4>
          <p className="text-2xl font-bold text-spiritual-gold-600">
            {formatCurrency(stats.totalEarnings)}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">💸</div>
          <h4 className="font-semibold text-red-700">Çekilen Toplam</h4>
          <p className="text-2xl font-bold text-red-600">
            {formatCurrency(stats.totalWithdrawn)}
          </p>
        </div>
      </div>

      {/* Wallet Actions */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-bold text-spiritual-purple-700 mb-4">
          💳 Cüzdan İşlemleri
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => {
              const amount = prompt("Yatırılacak tutarı girin (USD):");
              if (amount && Number(amount) > 0) {
                redirectToIyzipay(
                  Number(amount),
                  `Para Yatırma - ${user.name}`,
                );
              }
            }}
            className="bg-green-500 text-white p-4 rounded-lg hover:bg-green-600 transition-colors transform hover:scale-105"
          >
            <div className="text-2xl mb-2">💰</div>
            <p className="font-semibold">Para Yatır</p>
            <p className="text-xs">Iyzipay Sanal POS</p>
          </button>
          <button
            onClick={handleWithdraw}
            className="bg-blue-500 text-white p-4 rounded-lg hover:bg-blue-600 transition-colors transform hover:scale-105"
          >
            <div className="text-2xl mb-2">💸</div>
            <p className="font-semibold">Para Çek</p>
          </button>
          <button
            onClick={handleTransfer}
            className="bg-purple-500 text-white p-4 rounded-lg hover:bg-purple-600 transition-colors transform hover:scale-105"
          >
            <div className="text-2xl mb-2">🔄</div>
            <p className="font-semibold">Transfer Yap</p>
          </button>
        </div>
      </div>

      {/* Transaction History */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-bold text-spiritual-purple-700 mb-4">
          📋 İşlem Geçmişi
        </h4>
        <div className="space-y-3">
          {transactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex justify-between items-center py-3 border-b border-gray-100 last:border-b-0"
            >
              <div className="flex items-center space-x-4">
                <div
                  className={`w-3 h-3 rounded-full ${
                    transaction.status === "completed"
                      ? "bg-green-500"
                      : transaction.status === "pending"
                        ? "bg-yellow-500"
                        : "bg-red-500"
                  }`}
                ></div>
                <div>
                  <p className="font-medium text-gray-800">
                    {transaction.description}
                  </p>
                  <p className="text-sm text-gray-500">{transaction.date}</p>
                </div>
              </div>
              <div className="text-right">
                <p
                  className={`font-semibold ${
                    transaction.amount > 0 ? "text-green-600" : "text-red-600"
                  }`}
                >
                  {transaction.amount > 0 ? "+" : ""}
                  {formatCurrency(transaction.amount)}
                </p>
                <p className="text-xs text-gray-500 capitalize">
                  {transaction.status}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderTeam = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        👥 Ekibim & Downline
      </h3>

      {/* Team Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">👤</div>
          <h4 className="font-semibold text-spiritual-turquoise-700">
            Direkt Üyeler
          </h4>
          <p className="text-2xl font-bold text-spiritual-turquoise-600">
            {teamMembers.length}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">🌳</div>
          <h4 className="font-semibold text-spiritual-purple-700">
            Toplam Downline
          </h4>
          <p className="text-2xl font-bold text-spiritual-purple-600">
            {stats.totalReferrals}
          </p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">💰</div>
          <h4 className="font-semibold text-spiritual-gold-700">
            Ekip Kazancı
          </h4>
          <p className="text-2xl font-bold text-spiritual-gold-600">
            {formatCurrency(stats.totalEarnings * 0.3)}
          </p>
        </div>
      </div>

      {/* Team Members */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-bold text-spiritual-purple-700 mb-4">
          👥 Direkt Ekip Üyeleri
        </h4>
        <div className="space-y-4">
          {teamMembers.map((member) => (
            <div key={member.id} className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-start">
                <div className="flex items-center space-x-4">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      member.position === "left"
                        ? "bg-spiritual-turquoise-500"
                        : "bg-spiritual-purple-500"
                    } text-white font-bold`}
                  >
                    {member.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-800">
                      {member.name}
                    </h5>
                    <p className="text-sm text-gray-600">{member.email}</p>
                    <p className="text-xs text-gray-500">
                      {nefsLevels[member.nefsLevel - 1].icon}{" "}
                      {nefsLevels[member.nefsLevel - 1].name}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-spiritual-gold-600">
                    {formatCurrency(member.totalEarnings)}
                  </p>
                  <p className="text-sm text-gray-600">
                    {member.directReferrals} direkt üye
                  </p>
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${
                      member.status === "active"
                        ? "bg-green-100 text-green-800"
                        : "bg-red-100 text-red-800"
                    }`}
                  >
                    {member.status === "active" ? "Aktif" : "Pasif"}
                  </span>
                </div>
              </div>
              <div className="mt-3 flex justify-between text-sm">
                <span
                  className={`px-2 py-1 rounded ${
                    member.position === "left"
                      ? "bg-spiritual-turquoise-100 text-spiritual-turquoise-700"
                      : "bg-spiritual-purple-100 text-spiritual-purple-700"
                  }`}
                >
                  {member.position === "left" ? "Sol Bacak" : "Sağ Bacak"}
                </span>
                <span className="text-gray-500">
                  Katılım: {member.joinDate}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recruitment Tools */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-bold text-spiritual-purple-700 mb-4">
          🎯 Üye Kazanma Araçları
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
            <h5 className="font-semibold text-spiritual-turquoise-700 mb-2">
              📱 Klon Sayfanız
            </h5>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={user.clonePageUrl}
                readOnly
                className="flex-1 px-3 py-2 border rounded text-sm bg-white"
              />
              <button
                onClick={copyCloneUrl}
                className="bg-spiritual-turquoise-500 text-white px-3 py-2 rounded text-sm hover:bg-spiritual-turquoise-600"
              >
                Kopyala
              </button>
            </div>
          </div>

          <div className="bg-spiritual-purple-50 p-4 rounded-lg">
            <h5 className="font-semibold text-spiritual-purple-700 mb-2">
              💬 Sosyal Medya
            </h5>
            <div className="flex space-x-2">
              <button
                onClick={shareOnFacebook}
                className="bg-blue-600 text-white px-3 py-2 rounded text-sm hover:bg-blue-700 transition-colors"
              >
                Facebook
              </button>
              <button
                onClick={shareOnTwitter}
                className="bg-blue-400 text-white px-3 py-2 rounded text-sm hover:bg-blue-500 transition-colors"
              >
                Twitter
              </button>
              <button
                onClick={shareOnWhatsApp}
                className="bg-green-600 text-white px-3 py-2 rounded text-sm hover:bg-green-700 transition-colors"
              >
                WhatsApp
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderGenealogy = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        🌳 İkili Ağaç Görünümü
      </h3>

      {/* Binary Tree Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-turquoise-700 mb-4">
            📊 Ağaç İstatistikleri
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Sol Bacak Hacmi:</span>
              <span className="font-semibold text-spiritual-turquoise-600">
                {stats.leftLeg} üye
              </span>
            </div>
            <div className="flex justify-between">
              <span>Sağ Bacak Hacmi:</span>
              <span className="font-semibold text-spiritual-purple-600">
                {stats.rightLeg} üye
              </span>
            </div>
            <div className="flex justify-between">
              <span>Dengelilik Oranı:</span>
              <span className="font-semibold text-spiritual-gold-600">
                {Math.round(
                  (Math.min(stats.leftLeg, stats.rightLeg) /
                    Math.max(stats.leftLeg, stats.rightLeg)) *
                    100,
                )}
                %
              </span>
            </div>
            <div className="flex justify-between">
              <span>Aktif Komisyon:</span>
              <span className="font-semibold text-green-600">
                {formatCurrency(stats.pendingCommissions)}
              </span>
            </div>
          </div>
        </div>

        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
            🎯 Yerleştirme Kontrolü
          </h4>
          <div className="space-y-3">
            <p className="text-sm text-gray-600">
              Yeni üyelerin otomatik yerleştirme pozisyonu:
            </p>
            <div className="bg-spiritual-turquoise-50 p-3 rounded">
              <p className="font-semibold text-spiritual-turquoise-700">
                Sonraki Yerleştirme:{" "}
                {stats.leftLeg <= stats.rightLeg ? "Sol Bacak" : "Sağ Bacak"}
              </p>
            </div>
            <button
              onClick={() => {
                const newMemberId = prompt(
                  "Yerleştirilecek üye ID'sini girin:",
                );
                const position = prompt("Pozisyon seçin (left/right):");
                if (
                  newMemberId &&
                  (position === "left" || position === "right")
                ) {
                  alert(
                    `${newMemberId} üyesi ${position === "left" ? "sol" : "sağ"} bacağınıza yerleştirildi!`,
                  );
                } else {
                  alert(
                    "Geçersiz bilgi! Lütfen geçerli üye ID'si ve pozisyon (left/right) girin.",
                  );
                }
              }}
              className="w-full bg-spiritual-purple-500 text-white py-2 rounded hover:bg-spiritual-purple-600 transition-colors"
            >
              Manuel Yerleştirme Yap
            </button>
          </div>
        </div>
      </div>

      {/* Visual Binary Tree */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-bold text-spiritual-purple-700 mb-6 text-center">
          🌳 Görsel İkili Ağaç
        </h4>

        {/* Tree Visualization */}
        <div className="flex flex-col items-center space-y-8">
          {/* You (Root) */}
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 bg-spiritual-gold-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
              SEN
            </div>
            <p className="text-sm font-semibold mt-2">{user.name}</p>
            <p className="text-xs text-gray-500">
              {nefsLevels[stats.nefsLevel - 1].name}
            </p>
          </div>

          {/* Branches */}
          <div className="flex justify-between w-full max-w-md">
            {/* Left Branch */}
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center text-white font-bold">
                SOL
              </div>
              <p className="text-sm font-semibold mt-2">Sol Bacak</p>
              <p className="text-xs text-spiritual-turquoise-600">
                {stats.leftLeg} üye
              </p>

              {/* Left members preview */}
              <div className="mt-4 space-y-2">
                {teamMembers
                  .filter((m) => m.position === "left")
                  .slice(0, 2)
                  .map((member) => (
                    <div
                      key={member.id}
                      className="bg-spiritual-turquoise-50 p-2 rounded text-center min-w-24"
                    >
                      <p className="text-xs font-semibold">
                        {member.name.split(" ")[0]}
                      </p>
                      <p className="text-xs text-gray-500">
                        {nefsLevels[member.nefsLevel - 1].icon}
                      </p>
                    </div>
                  ))}
                {stats.leftLeg > 2 && (
                  <div className="text-xs text-gray-500">
                    +{stats.leftLeg - 2} diğer
                  </div>
                )}
              </div>
            </div>

            {/* Right Branch */}
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-spiritual-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                SAĞ
              </div>
              <p className="text-sm font-semibold mt-2">Sağ Bacak</p>
              <p className="text-xs text-spiritual-purple-600">
                {stats.rightLeg} üye
              </p>

              {/* Right members preview */}
              <div className="mt-4 space-y-2">
                {teamMembers
                  .filter((m) => m.position === "right")
                  .slice(0, 2)
                  .map((member) => (
                    <div
                      key={member.id}
                      className="bg-spiritual-purple-50 p-2 rounded text-center min-w-24"
                    >
                      <p className="text-xs font-semibold">
                        {member.name.split(" ")[0]}
                      </p>
                      <p className="text-xs text-gray-500">
                        {nefsLevels[member.nefsLevel - 1].icon}
                      </p>
                    </div>
                  ))}
                {stats.rightLeg > 2 && (
                  <div className="text-xs text-gray-500">
                    +{stats.rightLeg - 2} diğer
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderMeditation = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        🧘‍♂️ Meditasyon & Zikir
      </h3>

      {/* Meditation Timer */}
      <div className="spiritual-card p-8 text-center">
        <h4 className="text-xl font-semibold text-spiritual-turquoise-700 mb-6">
          ⏰ Meditasyon Zamanlayıcısı
        </h4>

        <div className="mb-6">
          <div className="text-6xl font-bold text-spiritual-purple-600 mb-4">
            {formatTime(timeLeft)}
          </div>
          <p className="text-gray-600">
            {isTimerRunning
              ? "Meditasyon devam ediyor..."
              : "Meditasyona hazır"}
          </p>
        </div>

        {!isTimerRunning && (
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Süre seçin (dakika):
            </label>
            <select
              value={meditationTime}
              onChange={(e) => setMeditationTime(Number(e.target.value))}
              className="px-4 py-2 border rounded-lg"
            >
              <option value={5}>5 dakika</option>
              <option value={10}>10 dakika</option>
              <option value={15}>15 dakika</option>
              <option value={20}>20 dakika</option>
              <option value={30}>30 dakika</option>
            </select>
          </div>
        )}

        <div className="flex justify-center space-x-4">
          {!isTimerRunning ? (
            <div className="flex space-x-4">
              <button
                onClick={startMeditation}
                className="bg-spiritual-turquoise-500 text-white px-8 py-3 rounded-full hover:bg-spiritual-turquoise-600 transition-colors"
              >
                🧘‍♂️ Meditasyonu Başlat
              </button>
              <button
                onClick={playMeditationMusic}
                className="bg-spiritual-purple-500 text-white px-8 py-3 rounded-full hover:bg-spiritual-purple-600 transition-colors"
              >
                🎵 Meditasyon Müziği
              </button>
            </div>
          ) : (
            <button
              onClick={stopMeditation}
              className="bg-red-500 text-white px-8 py-3 rounded-full hover:bg-red-600 transition-colors"
            >
              ⏹️ Durdur
            </button>
          )}
        </div>
      </div>

      {/* Meditation Guides */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-turquoise-700 mb-4">
            📿 Zikir Rehberi
          </h4>
          <div className="space-y-4">
            <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
              <h5 className="font-semibold mb-2">Subhanallah (33x)</h5>
              <p className="text-sm text-gray-600">
                Yücelik O Allah'a mahsustur
              </p>
            </div>
            <div className="bg-spiritual-purple-50 p-4 rounded-lg">
              <h5 className="font-semibold mb-2">Elhamdulillah (33x)</h5>
              <p className="text-sm text-gray-600">Hamd O Allah'a mahsustur</p>
            </div>
            <div className="bg-spiritual-gold-50 p-4 rounded-lg">
              <h5 className="font-semibold mb-2">Allahu Ekber (34x)</h5>
              <p className="text-sm text-gray-600">Allah en büyüktür</p>
            </div>
          </div>
        </div>

        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
            💫 Meditasyon Teknikleri
          </h4>
          <div className="space-y-3">
            <div className="p-3 bg-gray-50 rounded">
              <h5 className="font-semibold text-sm">Nefes Meditasyonu</h5>
              <p className="text-xs text-gray-600">
                Nefes alış verişe odaklanma
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded">
              <h5 className="font-semibold text-sm">Farkındalık Meditasyonu</h5>
              <p className="text-xs text-gray-600">An'da kalma pratiği</p>
            </div>
            <div className="p-3 bg-gray-50 rounded">
              <h5 className="font-semibold text-sm">
                Sevgi-Merhamet Meditasyonu
              </h5>
              <p className="text-xs text-gray-600">Kalbinizi açma pratiği</p>
            </div>
          </div>
        </div>
      </div>

      {/* Meditation Progress */}
      <div className="spiritual-card p-6">
        <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
          📈 Meditasyon İlerlemesi
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-spiritual-turquoise-600">
              15
            </div>
            <p className="text-sm text-gray-600">Bu hafta (dakika)</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-spiritual-purple-600">
              45
            </div>
            <p className="text-sm text-gray-600">Bu ay (dakika)</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-spiritual-gold-600">
              180
            </div>
            <p className="text-sm text-gray-600">Toplam (dakika)</p>
          </div>
        </div>
      </div>

      {/* Admin Meditation URL Control */}
      <div className="spiritual-card p-6">
        <h4 className="text-lg font-semibold text-spiritual-gold-700 mb-4">
          ⚙️ Meditasyon Müziği Ayarları (Admin)
        </h4>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              YouTube Müzik URL'si:
            </label>
            <input
              type="url"
              value={meditationUrl}
              onChange={(e) => setMeditationUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="w-full px-4 py-2 border border-spiritual-gold-300 rounded-lg focus:ring-2 focus:ring-spiritual-gold-500"
            />
          </div>
          <button
            onClick={() => alert("Meditasyon müziği URL'si güncellendi!")}
            className="bg-spiritual-gold-500 text-white px-6 py-2 rounded-lg hover:bg-spiritual-gold-600 transition-colors"
          >
            URL'yi Güncelle
          </button>
        </div>
      </div>
    </div>
  );

  const renderPrayers = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        🤲 Günlük Dualar & Zikirler
      </h3>

      {/* Daily Prayer */}
      <div className="spiritual-card p-6 text-center">
        <h4 className="text-xl font-semibold text-spiritual-turquoise-700 mb-4">
          📅 Bugünün Duası
        </h4>
        <div className="bg-spiritual-turquoise-50 p-6 rounded-lg">
          <p className="text-lg font-arabic text-spiritual-turquoise-800 mb-4">
            رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً
            وَقِنَا عَذَابَ النَّارِ
          </p>
          <p className="text-spiritual-purple-700 font-semibold mb-2">
            "Rabbimiz! Bize dünyada da iyilik ver, ahirette de iyilik ver ve
            bizi cehennem azabından koru."
          </p>
          <p className="text-sm text-gray-600">(Bakara Suresi, 201. Ayet)</p>
        </div>
      </div>

      {/* Prayer Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-turquoise-700 mb-4">
            🌅 Sabah Duaları
          </h4>
          <div className="space-y-3">
            <div className="p-3 bg-spiritual-turquoise-50 rounded">
              <h5 className="font-semibold text-sm mb-1">Sabah Kalktığında</h5>
              <p className="text-xs text-gray-600">
                "Elhamdulillahillezi ahyana ba'de ma ematena ve ileyhin-nüşur"
              </p>
            </div>
            <div className="p-3 bg-spiritual-turquoise-50 rounded">
              <h5 className="font-semibold text-sm mb-1">Güne Başlarken</h5>
              <p className="text-xs text-gray-600">
                "Allahümme bika esbahnâ ve bika emsaynâ..."
              </p>
            </div>
          </div>
        </div>

        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
            🌙 Akşam Duaları
          </h4>
          <div className="space-y-3">
            <div className="p-3 bg-spiritual-purple-50 rounded">
              <h5 className="font-semibold text-sm mb-1">Akşam Duası</h5>
              <p className="text-xs text-gray-600">
                "Allahümme bika emsaynâ ve bika esbahnâ..."
              </p>
            </div>
            <div className="p-3 bg-spiritual-purple-50 rounded">
              <h5 className="font-semibold text-sm mb-1">Yatmadan Önce</h5>
              <p className="text-xs text-gray-600">
                "Bismike Allahümme emutu ve ahya"
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Special Duas */}
      <div className="spiritual-card p-6">
        <h4 className="text-lg font-semibold text-spiritual-gold-700 mb-4">
          ✨ Özel Dualar
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => alert(`💰 Rızık Duası:\n\n${dailyPrayers.rizik}`)}
            className="text-center p-4 bg-spiritual-gold-50 rounded-lg hover:bg-spiritual-gold-100 transition-colors cursor-pointer"
          >
            <div className="text-2xl mb-2">💰</div>
            <h5 className="font-semibold text-sm">Rızık Duası</h5>
            <p className="text-xs text-gray-600 mt-2">Bereket ve kazanç için</p>
          </button>
          <button
            onClick={() => alert(`❤️ Sağlık Duası:\n\n${dailyPrayers.saglik}`)}
            className="text-center p-4 bg-spiritual-turquoise-50 rounded-lg hover:bg-spiritual-turquoise-100 transition-colors cursor-pointer"
          >
            <div className="text-2xl mb-2">❤️</div>
            <h5 className="font-semibold text-sm">Sağlık Duası</h5>
            <p className="text-xs text-gray-600 mt-2">Şifa ve afiyet için</p>
          </button>
          <button
            onClick={() =>
              alert(`🌸 Manevi Temizlik Duası:\n\n${dailyPrayers.temizlik}`)
            }
            className="text-center p-4 bg-spiritual-purple-50 rounded-lg hover:bg-spiritual-purple-100 transition-colors cursor-pointer"
          >
            <div className="text-2xl mb-2">🌸</div>
            <h5 className="font-semibold text-sm">Manevi Temizlik</h5>
            <p className="text-xs text-gray-600 mt-2">Kalp temizliği için</p>
          </button>
        </div>
      </div>

      {/* Daily Progress */}
      <div className="spiritual-card p-6">
        <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
          📊 Günlük İbadet Takibi
        </h4>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span>Fecir Namazı</span>
            <input
              type="checkbox"
              className="rounded text-spiritual-turquoise-600"
            />
          </div>
          <div className="flex justify-between items-center">
            <span>Sabah Zikirları</span>
            <input
              type="checkbox"
              className="rounded text-spiritual-turquoise-600"
            />
          </div>
          <div className="flex justify-between items-center">
            <span>Kuran Okuma</span>
            <input
              type="checkbox"
              className="rounded text-spiritual-turquoise-600"
            />
          </div>
          <div className="flex justify-between items-center">
            <span>Akşam Zikirları</span>
            <input
              type="checkbox"
              className="rounded text-spiritual-turquoise-600"
            />
          </div>
        </div>
      </div>

      {/* Dream Interpretation Section */}
      <div className="spiritual-card p-6">
        <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
          🌙 Rüya Yorumu
        </h4>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Rüyanızı anlatın:
            </label>
            <textarea
              value={dreamInput}
              onChange={(e) => setDreamInput(e.target.value)}
              placeholder="Gördüğünüz rüyayı detaylı olarak anlatın..."
              className="w-full h-24 p-3 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
            />
          </div>
          <button
            onClick={interpretDream}
            className="bg-spiritual-turquoise-500 text-white px-6 py-2 rounded-lg hover:bg-spiritual-turquoise-600 transition-colors"
          >
            🔮 Rüyayı Yorumla
          </button>
          {dreamInterpretation && (
            <div className="bg-spiritual-gold-50 p-4 rounded-lg border border-spiritual-gold-200">
              <h5 className="font-semibold text-spiritual-gold-700 mb-2">
                Rüya Tahlili:
              </h5>
              <pre className="whitespace-pre-wrap text-sm text-gray-700">
                {dreamInterpretation}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderDreams = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        🌙 Rüya Yorumu & Tabiri
      </h3>

      {/* Dream Input */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-semibold text-spiritual-turquoise-700 mb-4">
          📝 Rüyanızı Anlatın
        </h4>
        <textarea
          placeholder="Gördüğünüz rüyayı detaylı olarak anlatın..."
          className="w-full h-32 p-4 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
        ></textarea>
        <button className="mt-4 bg-spiritual-turquoise-500 text-white px-6 py-2 rounded-lg hover:bg-spiritual-turquoise-600">
          🔮 Rüya Yorumu Al
        </button>
      </div>

      {/* Common Dream Symbols */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
            🔮 Yaygın Rüya Sembolleri
          </h4>
          <div className="space-y-3">
            <div className="p-3 bg-gray-50 rounded">
              <h5 className="font-semibold text-sm">🌊 Su</h5>
              <p className="text-xs text-gray-600">
                Temizlik, arınma, yenilenme
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded">
              <h5 className="font-semibold text-sm">🕊️ Kuş</h5>
              <p className="text-xs text-gray-600">Özgürlük, manevi yükseliş</p>
            </div>
            <div className="p-3 bg-gray-50 rounded">
              <h5 className="font-semibold text-sm">🌳 Ağaç</h5>
              <p className="text-xs text-gray-600">Büyüme, gelişim, hayat</p>
            </div>
            <div className="p-3 bg-gray-50 rounded">
              <h5 className="font-semibold text-sm">🏠 Ev</h5>
              <p className="text-xs text-gray-600">Güvenlik, aile, istikrar</p>
            </div>
          </div>
        </div>

        <div className="spiritual-card p-6">
          <h4 className="text-lg font-semibold text-spiritual-gold-700 mb-4">
            ✨ Müjde Rüyaları
          </h4>
          <div className="space-y-3">
            <div className="p-3 bg-spiritual-gold-50 rounded">
              <h5 className="font-semibold text-sm">🌅 Güneş</h5>
              <p className="text-xs text-gray-600">Aydınlanma, rehberlik</p>
            </div>
            <div className="p-3 bg-spiritual-gold-50 rounded">
              <h5 className="font-semibold text-sm">🌙 Ay</h5>
              <p className="text-xs text-gray-600">Manevi güzellik, nur</p>
            </div>
            <div className="p-3 bg-spiritual-gold-50 rounded">
              <h5 className="font-semibold text-sm">🌸 Çiçek</h5>
              <p className="text-xs text-gray-600">Güzellik, bereket</p>
            </div>
            <div className="p-3 bg-spiritual-gold-50 rounded">
              <h5 className="font-semibold text-sm">👼 Melek</h5>
              <p className="text-xs text-gray-600">İlahi korunma, müjde</p>
            </div>
          </div>
        </div>
      </div>

      {/* Dream History */}
      <div className="spiritual-card p-6">
        <h4 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
          📚 Rüya Geçmişiniz
        </h4>
        <div className="space-y-4">
          <div className="border-l-4 border-spiritual-turquoise-500 pl-4">
            <h5 className="font-semibold text-sm">15 Şubat 2024</h5>
            <p className="text-sm text-gray-600">
              "Temiz bir denizde yüzüyordum..."
            </p>
            <p className="text-xs text-spiritual-turquoise-600 mt-1">
              Yorum: Manevi temizlik ve arınma döneminde olduğunuzu gösterir.
            </p>
          </div>
          <div className="border-l-4 border-spiritual-purple-500 pl-4">
            <h5 className="font-semibold text-sm">12 Şubat 2024</h5>
            <p className="text-sm text-gray-600">
              "Büyük bir ağacın altında oturuyordum..."
            </p>
            <p className="text-xs text-spiritual-purple-600 mt-1">
              Yorum: Bilgi ve hikmet kazanma dönemini işaret eder.
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        👤 Profil Bilgileri
      </h3>

      {/* Personal Information */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-semibold text-spiritual-turquoise-700 mb-4">
          📋 Kişisel Bilgiler
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ad Soyad
              </label>
              <input
                type="text"
                value={user.name}
                onChange={(e) =>
                  setUser((prev) => ({ ...prev, name: e.target.value }))
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                value={user.email}
                onChange={(e) =>
                  setUser((prev) => ({ ...prev, email: e.target.value }))
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Telefon
              </label>
              <input
                type="tel"
                value={user.phone}
                onChange={(e) =>
                  setUser((prev) => ({ ...prev, phone: e.target.value }))
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Üye ID
              </label>
              <input
                type="text"
                value={user.memberId}
                readOnly
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Katılım Tarihi
              </label>
              <input
                type="text"
                value={user.joinDate}
                readOnly
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Adres
              </label>
              <input
                type="text"
                value={user.address}
                onChange={(e) =>
                  setUser((prev) => ({ ...prev, address: e.target.value }))
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>
        </div>
        <button
          onClick={handleProfileUpdate}
          className="mt-6 bg-spiritual-turquoise-500 text-white px-6 py-2 rounded-lg hover:bg-spiritual-turquoise-600 transition-colors transform hover:scale-105"
        >
          Bilgileri Güncelle
        </button>
      </div>

      {/* Security Settings */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-semibold text-spiritual-purple-700 mb-4">
          🔒 Güvenlik Ayarları
        </h4>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Mevcut Şifre
            </label>
            <input
              type="password"
              value={passwordForm.currentPassword}
              onChange={(e) =>
                setPasswordForm((prev) => ({
                  ...prev,
                  currentPassword: e.target.value,
                }))
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              placeholder="Mevcut şifrenizi girin"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Yeni Şifre
            </label>
            <input
              type="password"
              value={passwordForm.newPassword}
              onChange={(e) =>
                setPasswordForm((prev) => ({
                  ...prev,
                  newPassword: e.target.value,
                }))
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              placeholder="Yeni şifrenizi girin"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Yeni Şifre Tekrar
            </label>
            <input
              type="password"
              value={passwordForm.confirmPassword}
              onChange={(e) =>
                setPasswordForm((prev) => ({
                  ...prev,
                  confirmPassword: e.target.value,
                }))
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              placeholder="Yeni şifrenizi tekrar girin"
            />
          </div>
          <button className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600">
            Şifreyi Değiştir
          </button>
        </div>
      </div>

      {/* Banking Information */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-semibold text-spiritual-gold-700 mb-4">
          🏦 Banka Bilgileri
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Banka Adı
              </label>
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
                <option>Ziraat Bankası</option>
                <option>İş Bankası</option>
                <option>Vakıfbank</option>
                <option>Garanti BBVA</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Hesap Sahibi
              </label>
              <input
                type="text"
                value={user.name}
                onChange={(e) =>
                  setUser((prev) => ({ ...prev, name: e.target.value }))
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                IBAN
              </label>
              <input
                type="text"
                value={user.iban}
                onChange={(e) =>
                  setUser((prev) => ({ ...prev, iban: e.target.value }))
                }
                placeholder="TR00 0000 0000 0000 0000 0000 00"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Kayıtlı Hesap
              </label>
              <input
                type="text"
                value={user.bankAccount}
                readOnly
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
              />
            </div>
          </div>
        </div>
        <button className="mt-6 bg-spiritual-gold-500 text-white px-6 py-2 rounded-lg hover:bg-spiritual-gold-600">
          Banka Bilgilerini Güncelle
        </button>
      </div>
    </div>
  );

  const renderClone = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-spiritual-purple-700">
        🌐 Klon Sayfa Yönetimi
      </h3>

      {/* Clone Page URL */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-semibold text-spiritual-turquoise-700 mb-4">
          🔗 Klon Sayfa URL'niz
        </h4>
        <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
          <div className="flex items-center space-x-4">
            <input
              type="text"
              value={user.clonePageUrl}
              readOnly
              className="flex-1 px-4 py-3 border border-spiritual-turquoise-300 rounded-lg bg-white"
            />
            <button
              onClick={copyCloneUrl}
              className="bg-spiritual-turquoise-500 text-white px-6 py-3 rounded-lg hover:bg-spiritual-turquoise-600"
            >
              📋 Kopyala
            </button>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Bu özel linki paylaşarak yeni üyeler kazanın ve komisyon elde edin.
          </p>
        </div>
      </div>

      {/* Sharing Tools */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-semibold text-spiritual-purple-700 mb-4">
          📱 Paylaşım Araçları
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={shareOnFacebook}
            className="bg-blue-600 text-white p-4 rounded-lg hover:bg-blue-700 transition-colors transform hover:scale-105"
          >
            <div className="text-2xl mb-2">📘</div>
            <p className="font-semibold">Facebook</p>
            <p className="text-xs">Paylaş</p>
          </button>
          <button
            onClick={shareOnTwitter}
            className="bg-blue-400 text-white p-4 rounded-lg hover:bg-blue-500 transition-colors transform hover:scale-105"
          >
            <div className="text-2xl mb-2">🐦</div>
            <p className="font-semibold">Twitter</p>
            <p className="text-xs">Tweet</p>
          </button>
          <button
            onClick={shareOnWhatsApp}
            className="bg-green-600 text-white p-4 rounded-lg hover:bg-green-700 transition-colors transform hover:scale-105"
          >
            <div className="text-2xl mb-2">💬</div>
            <p className="font-semibold">WhatsApp</p>
            <p className="text-xs">Gönder</p>
          </button>
          <button
            onClick={shareViaEmail}
            className="bg-red-600 text-white p-4 rounded-lg hover:bg-red-700 transition-colors transform hover:scale-105"
          >
            <div className="text-2xl mb-2">📧</div>
            <p className="font-semibold">Email</p>
            <p className="text-xs">E-posta</p>
          </button>
        </div>
      </div>

      {/* Clone Page Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">👁️</div>
          <h4 className="font-semibold text-spiritual-turquoise-700">
            Ziyaret
          </h4>
          <p className="text-2xl font-bold text-spiritual-turquoise-600">246</p>
          <p className="text-sm text-gray-600">Bu ay</p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">👥</div>
          <h4 className="font-semibold text-spiritual-purple-700">Kayıt</h4>
          <p className="text-2xl font-bold text-spiritual-purple-600">18</p>
          <p className="text-sm text-gray-600">Dönüşüm %7.3</p>
        </div>

        <div className="spiritual-card p-6 text-center">
          <div className="text-4xl mb-2">💰</div>
          <h4 className="font-semibold text-spiritual-gold-700">Kazanç</h4>
          <p className="text-2xl font-bold text-spiritual-gold-600">
            {formatCurrency(1800)}
          </p>
          <p className="text-sm text-gray-600">Klon sayfadan</p>
        </div>
      </div>

      {/* Marketing Materials */}
      <div className="spiritual-card p-6">
        <h4 className="text-xl font-semibold text-spiritual-gold-700 mb-4">
          📈 Pazarlama Materyalleri
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="font-semibold text-spiritual-turquoise-700 mb-3">
              📝 Hazır Metinler
            </h5>
            <div className="space-y-2">
              <div className="p-3 bg-gray-50 rounded border">
                <p className="text-sm font-semibold">Kısa Metin</p>
                <p className="text-xs text-gray-600">
                  50 karakter sosyal medya için
                </p>
              </div>
              <div className="p-3 bg-gray-50 rounded border">
                <p className="text-sm font-semibold">Orta Metin</p>
                <p className="text-xs text-gray-600">
                  200 karakter WhatsApp için
                </p>
              </div>
              <div className="p-3 bg-gray-50 rounded border">
                <p className="text-sm font-semibold">Uzun Metin</p>
                <p className="text-xs text-gray-600">500 karakter blog için</p>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-semibold text-spiritual-purple-700 mb-3">
              🖼️ Görsel Materyaller
            </h5>
            <div className="space-y-2">
              <div className="p-3 bg-gray-50 rounded border">
                <p className="text-sm font-semibold">Instagram Story</p>
                <p className="text-xs text-gray-600">
                  1080x1920 hikaye formatı
                </p>
              </div>
              <div className="p-3 bg-gray-50 rounded border">
                <p className="text-sm font-semibold">Facebook Post</p>
                <p className="text-xs text-gray-600">1200x630 post formatı</p>
              </div>
              <div className="p-3 bg-gray-50 rounded border">
                <p className="text-sm font-semibold">Banner</p>
                <p className="text-xs text-gray-600">728x90 web banner</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* QR Code */}
      <div className="spiritual-card p-6 text-center">
        <h4 className="text-xl font-semibold text-spiritual-purple-700 mb-4">
          📱 QR Kod
        </h4>
        <div className="inline-block p-6 bg-white border-2 border-spiritual-turquoise-300 rounded-lg">
          <div className="w-48 h-48 bg-gray-200 flex items-center justify-center rounded">
            <div className="text-6xl">📱</div>
          </div>
        </div>
        <p className="text-sm text-gray-600 mt-4">
          Bu QR kodu yazdırıp fiziksel materyallerde kullanabilirsiniz
        </p>
        <button
          onClick={generateQRCode}
          className="mt-4 bg-spiritual-turquoise-500 text-white px-6 py-2 rounded-lg hover:bg-spiritual-turquoise-600 transition-colors transform hover:scale-105"
        >
          QR Kodu Oluştur & Görüntüle
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-spiritual-turquoise-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">🕊️</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-spiritual-turquoise-700">
                    Kullanıcı Paneli
                  </h1>
                  <p className="text-sm text-spiritual-purple-600">
                    Kutbul Zaman - Manevi Rehberim
                  </p>
                </div>
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              {/* Trial Status */}
              {trialStatus.isTrialUser && (
                <div className="text-center">
                  {trialStatus.accountLocked ? (
                    <div className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs">
                      ⚠️ Hesap Kilitli
                    </div>
                  ) : (
                    <div className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs">
                      🎁 Deneme: {trialStatus.daysRemaining} gün kaldı
                    </div>
                  )}
                </div>
              )}

              <div className="text-right">
                <p className="text-sm font-medium text-spiritual-turquoise-700">
                  {user.name}
                </p>
                <p className="text-xs text-gray-500">ID: {user.memberId}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-spiritual-gold-600">
                  {formatCurrency(stats.walletBalance)}
                </p>
                <p className="text-xs text-gray-500">Cüzdan</p>
              </div>

              {/* Upgrade Button for Trial Users */}
              {trialStatus.isTrialUser && (
                <button
                  onClick={() => {
                    redirectToIyzipay(100, `Hesap Aktivasyonu - ${user.name}`);
                    setTimeout(() => activateAccount(), 2000); // Demo amaçlı
                  }}
                  className="bg-spiritual-gold-500 text-white px-4 py-2 rounded-lg hover:bg-spiritual-gold-600 text-sm font-semibold"
                >
                  💳 Aktifleştir
                  <div className="text-xs">Iyzipay</div>
                </button>
              )}

              <button
                onClick={handleLogout}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 text-sm"
              >
                Çıkış Yap
              </button>
            </div>
          </div>
        </div>

        {/* Trial Warning Banner */}
        {trialStatus.isTrialUser && !trialStatus.accountLocked && (
          <div className="bg-yellow-50 border-b border-yellow-200 px-6 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">⏰</span>
                <div>
                  <p className="text-sm font-semibold text-yellow-800">
                    Deneme süresi: {trialStatus.daysRemaining} gün kaldı
                  </p>
                  <p className="text-xs text-yellow-700">
                    Tam erişim için hesabınızı aktifleştirin. Sınırlı özellikler
                    kullanılabilir.
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  redirectToIyzipay(100, `Hesap Aktivasyonu - ${user.name}`);
                  setTimeout(() => activateAccount(), 2000);
                }}
                className="bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700 text-sm font-semibold"
              >
                Hemen Aktifleştir
                <div className="text-xs">Iyzipay Sanal POS</div>
              </button>
            </div>
          </div>
        )}

        {/* Account Locked Banner */}
        {trialStatus.accountLocked && (
          <div className="bg-red-50 border-b border-red-200 px-6 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">🔒</span>
                <div>
                  <p className="text-sm font-semibold text-red-800">
                    Hesabınız pasif durumda
                  </p>
                  <p className="text-xs text-red-700">
                    7 günlük deneme süreniz doldu. Özellikler kısıtlanmıştır.
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  redirectToIyzipay(100, `Hesap Aktivasyonu - ${user.name}`);
                  setTimeout(() => activateAccount(), 2000);
                }}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 text-sm font-semibold"
              >
                Hesabı Aktifleştir
                <div className="text-xs">Iyzipay Sanal POS</div>
              </button>
            </div>
          </div>
        )}
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-lg min-h-screen">
          <nav className="p-4">
            <ul className="space-y-2">
              {[
                { id: "overview", label: "Genel Bakış", icon: "📊" },
                { id: "earnings", label: "Kazançlar", icon: "💰" },
                { id: "team", label: "Ekibim", icon: "👥" },
                { id: "genealogy", label: "İkili Ağaç", icon: "🌳" },
                { id: "meditation", label: "Meditasyon", icon: "🧘‍♂️" },
                { id: "prayers", label: "Dualar", icon: "🤲" },
                { id: "dreams", label: "Rüya Yorumu", icon: "🌙" },
                { id: "profile", label: "Profil", icon: "👤" },
                { id: "clone", label: "Klon Sayfa", icon: "🌐" },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-left transition-colors ${
                      activeTab === item.id
                        ? "bg-spiritual-turquoise-100 text-spiritual-turquoise-700"
                        : "text-gray-600 hover:bg-gray-100"
                    }`}
                  >
                    <span className="text-xl">{item.icon}</span>
                    <span className="font-medium">{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {activeTab === "overview" && renderOverview()}
          {activeTab === "earnings" && renderEarnings()}
          {activeTab === "team" && renderTeam()}
          {activeTab === "genealogy" && renderGenealogy()}
          {activeTab === "meditation" && renderMeditation()}
          {activeTab === "prayers" && renderPrayers()}
          {activeTab === "dreams" && renderDreams()}
          {activeTab === "profile" && renderProfile()}
          {activeTab === "clone" && renderClone()}
        </main>
      </div>

      {/* Deposit Modal */}
      {showDepositModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6">
              💰 Para Yatırma
            </h3>

            <div className="space-y-4">
              <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
                <h4 className="font-semibold text-spiritual-turquoise-700 mb-2">
                  Admin Banka Bilgileri:
                </h4>
                <p className="text-sm">
                  <strong>Banka:</strong> {ADMIN_BANK}
                </p>
                <p className="text-sm">
                  <strong>IBAN:</strong> {ADMIN_IBAN}
                </p>
                <p className="text-sm">
                  {" "}
                  <strong>Hesap Sahibi:</strong> Abdulkadir Kan
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Yatırılacak Tutar (USD) *
                </label>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  placeholder="100"
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Dekont/Makbuz Yükle *
                </label>
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={(e) => setReceipt(e.target.files?.[0] || null)}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  JPG, PNG veya PDF formatında dekont yükleyin
                </p>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setShowDepositModal(false)}
                  className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600"
                >
                  İptal
                </button>
                <button
                  onClick={() => {
                    if (depositAmount) {
                      redirectToIyzipay(
                        Number(depositAmount),
                        `Para Yatırma - ${user.name}`,
                      );
                      setShowDepositModal(false);
                    } else {
                      submitDeposit();
                    }
                  }}
                  className="flex-1 bg-spiritual-turquoise-500 text-white py-2 rounded-lg hover:bg-spiritual-turquoise-600"
                >
                  💳 Iyzipay ile Öde
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Withdraw Modal */}
      {showWithdrawModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6">
              💸 Para Çekme
            </h3>

            <div className="space-y-4">
              <div className="bg-spiritual-gold-50 p-4 rounded-lg">
                <p className="text-sm text-spiritual-gold-700">
                  <strong>Mevcut Bakiye:</strong>{" "}
                  {formatCurrency(stats.walletBalance)}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Çekilecek Tutar (USD) *
                </label>
                <input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  placeholder="50"
                  max={stats.walletBalance}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-purple-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Çekim Nedeni *
                </label>
                <textarea
                  value={withdrawReason}
                  onChange={(e) => setWithdrawReason(e.target.value)}
                  placeholder="Para çekme nedeninizi belirtin..."
                  rows={3}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-purple-500"
                />
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setShowWithdrawModal(false)}
                  className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600"
                >
                  İptal
                </button>
                <button
                  onClick={submitWithdraw}
                  className="flex-1 bg-spiritual-purple-500 text-white py-2 rounded-lg hover:bg-spiritual-purple-600"
                >
                  Talep Gönder
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Transfer Modal */}
      {showTransferModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6">
              🔄 Para Transferi
            </h3>

            <div className="space-y-4">
              <div className="bg-spiritual-gold-50 p-4 rounded-lg">
                <p className="text-sm text-spiritual-gold-700">
                  <strong>Mevcut Bakiye:</strong>{" "}
                  {formatCurrency(stats.walletBalance)}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Alıcı Üye ID'si *
                </label>
                <input
                  type="text"
                  value={transferMemberId}
                  onChange={(e) => setTransferMemberId(e.target.value)}
                  placeholder="MB123456"
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-purple-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Transfer Tutarı (USD) *
                </label>
                <input
                  type="number"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  placeholder="25"
                  max={stats.walletBalance}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-purple-500"
                />
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setShowTransferModal(false)}
                  className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600"
                >
                  İptal
                </button>
                <button
                  onClick={submitTransfer}
                  className="flex-1 bg-spiritual-purple-500 text-white py-2 rounded-lg hover:bg-spiritual-purple-600"
                >
                  Transfer Yap
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment/Activation Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6">
              💳 Hesap Aktivasyonu
            </h3>

            <div className="space-y-6">
              <div className="text-center">
                <div className="text-6xl mb-4">🚀</div>
                <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-2">
                  Tam Erişim Sağlayın
                </h4>
                <p className="text-gray-600">
                  Hesabınızı aktifleştirerek tüm özelliklere sınırsız erişim
                  kazanın.
                </p>
              </div>

              <div className="bg-spiritual-gold-50 p-4 rounded-lg">
                <h5 className="font-semibold text-spiritual-gold-700 mb-2">
                  Aktivasyon Ücreti:
                </h5>
                <p className="text-3xl font-bold text-spiritual-gold-600">
                  $100
                </p>
                <p className="text-sm text-gray-600">Tek seferlik ödeme</p>
              </div>

              <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
                <h5 className="font-semibold text-spiritual-turquoise-700 mb-2">
                  Aktivasyon Sonrası:
                </h5>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>✅ Sınırsız para yatırma/çekme</li>
                  <li>✅ Transfer işlemleri</li>
                  <li>✅ Komisyon kazanımları</li>
                  <li>✅ Ekip oluşturma</li>
                  <li>✅ Tüm manevi özellikler</li>
                </ul>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg">
                <h5 className="font-semibold text-yellow-700 mb-2">
                  Demo Aktivasyon:
                </h5>
                <p className="text-sm text-yellow-700 mb-3">
                  Demo amaçlı olarak hesabınızı ücretsiz aktifleştirin.
                </p>
                <button
                  onClick={activateAccount}
                  className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition-colors"
                >
                  🎁 Demo Aktivasyon (Ücretsiz)
                </button>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => {
                    redirectToIyzipay(100, `Hesap Aktivasyonu - ${user.name}`);
                    // Gerçek uygulamada ödeme başarılı olduktan sonra activateAccount() çalışacak
                    setTimeout(() => activateAccount(), 2000); // Demo amaçlı gecikme
                  }}
                  className="w-full bg-spiritual-gold-500 text-white py-3 rounded-lg hover:bg-spiritual-gold-600 transition-colors font-semibold"
                >
                  💳 $100 Öde ve Aktifleştir
                  <div className="text-xs mt-1">Güvenli Ödeme: Iyzipay</div>
                </button>

                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="w-full bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Daha Sonra
                </button>
              </div>

              {trialStatus.daysRemaining > 0 && (
                <div className="text-center">
                  <p className="text-xs text-gray-500">
                    Deneme süreniz bitmeden {trialStatus.daysRemaining} gün var
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
