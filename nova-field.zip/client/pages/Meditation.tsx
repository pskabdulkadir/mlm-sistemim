import { useState, useEffect } from "react";
import { Link } from "wouter";

const Meditation = () => {
  const [activeTab, setActiveTab] = useState("guided");
  const [meditationTime, setMeditationTime] = useState(10);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600);
  const [selectedDhikr, setSelectedDhikr] = useState<string | null>(null);
  const [dhikrCount, setDhikrCount] = useState(0);

  // Timer effect
  useEffect(() => {
    let interval: number;
    if (isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsTimerRunning(false);
      alert("🧘‍♂️ Meditasyon tamamlandı! Allah razı olsun.");
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const startMeditation = () => {
    setTimeLeft(meditationTime * 60);
    setIsTimerRunning(true);
  };

  const stopMeditation = () => {
    setIsTimerRunning(false);
  };

  const dhikrList = [
    {
      id: "subhanallah",
      arabic: "سُبْحَانَ اللّهِ",
      transliteration: "Subhanallah",
      meaning: "Allah'ı eksikliklerden tenzih ederim",
      count: 33,
      virtue: "Her bir tesbih için bir hasene yazılır ve bir günah silinir.",
    },
    {
      id: "alhamdulillah",
      arabic: "الْحَمْدُ لِلّهِ",
      transliteration: "Elhamdulillah",
      meaning: "Hamd Allah'a mahsustur",
      count: 33,
      virtue: "Bu zikir, mizanın en ağır tarafına konur.",
    },
    {
      id: "allahuekber",
      arabic: "اللّهُ أَكْبَرُ",
      transliteration: "Allahu Ekber",
      meaning: "Allah en büyüktür",
      count: 34,
      virtue: "Bu tekbir, gökleri ve yeri doldurur.",
    },
    {
      id: "laila",
      arabic: "لَا إِلَهَ إِلَّا اللّهُ",
      transliteration: "La ilahe illallah",
      meaning: "Allah'tan başka tapılacak yoktur",
      count: 100,
      virtue: "Bu kelime, en büyük zikir ve duadır.",
    },
    {
      id: "astaghfirullah",
      arabic: "أَسْتَغْفِرُ اللّهَ",
      transliteration: "Estaghfirullah",
      meaning: "Allah'tan bağışlanma dilerim",
      count: 100,
      virtue: "İstiğfar kalbi temizler ve bereketi arttırır.",
    },
    {
      id: "salawat",
      arabic: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ",
      transliteration: "Allahumme salli ala Muhammed",
      meaning: "Allah'ım Hz. Muhammed'e rahmet et",
      count: 100,
      virtue: "Bir salavat için on rahmet ve bereket gelir.",
    },
  ];

  const meditationTechniques = [
    {
      id: "breath",
      title: "Nefes Meditasyonu",
      icon: "🫁",
      description: "Nefes alış verişe odaklanma ve zikir ile nefes düzenleme",
      duration: "5-20 dakika",
      level: "Başlangıç",
      steps: [
        "Rahat bir pozisyonda oturun",
        "Gözlerinizi kapatın ve nefsinizi sakinleştirin",
        "Burnunuzdan derin nefes alın (4 saniye)",
        "Nefsinizi tutun (4 saniye)",
        "Ağzınızdan yavaşça verin (6 saniye)",
        "Bu sırada 'La ilahe illallah' zikredin",
      ],
    },
    {
      id: "dhikr",
      title: "Zikir Meditasyonu",
      icon: "📿",
      description: "İslami zikirler ile kalp temizliği ve ruhsal huzur",
      duration: "10-30 dakika",
      level: "Tüm Seviyeler",
      steps: [
        "Kıbleyə dönük oturun",
        "Abdestli olduğunuzdan emin olun",
        "Euzubillah ve Besmele çekin",
        "Seçtiğiniz zikri tekrar edin",
        "Kalben anlamını düşünün",
        "Allah'ın huzurunda olduğunuzu hissedin",
      ],
    },
    {
      id: "tafakkur",
      title: "Tefekkür Meditasyonu",
      icon: "🌌",
      description: "Allah'ın yaratılışı üzerinde düşünme ve ibret alma",
      duration: "15-30 dakika",
      level: "İleri",
      steps: [
        "Sakin ve temiz bir ortam seçin",
        "Gökyüzü, deniz veya doğaya bakın",
        "Allah'ın yaratışının mükemmelliğini düşünün",
        "Kendi yaratılışınız üzerinde tefekkür edin",
        "Allah'ın büyüklüğünü hissedin",
        "Şükür ve hamd zikirlerinizi artırın",
      ],
    },
    {
      id: "muraqaba",
      title: "Murâkabe Meditasyonu",
      icon: "👁️",
      description: "Kalp ile Allah'ı anma ve ruhsal yakınlık hissetme",
      duration: "20-45 dakika",
      level: "İleri",
      steps: [
        "Tam sükûnet içinde oturun",
        "Dünyevi düşünceleri bırakın",
        "Kalbinizi Allah'a yönlendirin",
        "Allah'ın size bakıdığını hissedin",
        "Sessizce 'Allah' ismi ile meşgul olun",
        "Ruhsal huzur ve yakınlığı yaşayın",
      ],
    },
  ];

  const spiritualBenefits = [
    {
      icon: "💚",
      title: "Kalp Temizliği",
      description: "Zikir ve meditasyon ile kalpteki pas ve kir temizlenir",
    },
    {
      icon: "🕊️",
      title: "Ruhsal Huzur",
      description: "İç huzur ve sükunet elde edilir, stres azalır",
    },
    {
      icon: "🌟",
      title: "Manevi Uyanış",
      description: "Allah'a yakınlık hissi ve manevi farkındalık artar",
    },
    {
      icon: "🔮",
      title: "İç Görü",
      description: "Hayatın anlamı ve amacı konusunda berrak görüş",
    },
    {
      icon: "⚖️",
      title: "Nefs Terbiyesi",
      description: "Nefsin kötü isteklerine karşı irade gücü gelişir",
    },
    {
      icon: "🌈",
      title: "Pozitif Enerji",
      description: "Olumlu düşünce ve davranış kalıpları gelişir",
    },
  ];

  const dailyPractices = [
    {
      time: "Fajr Sonrası",
      practice: "Sabah Zikirları",
      duration: "15 dakika",
      description: "Fecir namazı sonrası güneş doğana kadar zikir",
    },
    {
      time: "Kuşluk Vakti",
      practice: "Tefekkür",
      duration: "10 dakika",
      description: "Allah'ın yaratılışı üzerinde düşünme",
    },
    {
      time: "Öğle Arası",
      practice: "Nefes Meditasyonu",
      duration: "5 dakika",
      description: "İş stresini atmak için kısa nefes egzersizi",
    },
    {
      time: "Akşam",
      practice: "Akşam Zikirları",
      duration: "20 dakika",
      description: "Maghrib namazı sonrası zikir ve tesbih",
    },
    {
      time: "Yatsı Sonrası",
      practice: "Murâkabe",
      duration: "30 dakika",
      description: "Gün sonu ruhsal muhâsebe ve Allah'ı anma",
    },
  ];

  const renderGuidedMeditation = () => (
    <div className="space-y-8">
      {/* Timer Section */}
      <div className="spiritual-card p-8 text-center">
        <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6">
          🕐 Meditasyon Zamanlayıcısı
        </h3>

        <div className="mb-8">
          <div className="text-8xl font-bold text-spiritual-turquoise-600 mb-4 animate-pulse-spiritual">
            {formatTime(timeLeft)}
          </div>
          <p className="text-lg text-gray-600">
            {isTimerRunning ? "Meditasyon devam ediyor..." : "Hazırsınız"}
          </p>
        </div>

        {!isTimerRunning && (
          <div className="mb-6">
            <label className="block text-lg font-medium text-gray-700 mb-4">
              Meditasyon süresi:
            </label>
            <div className="flex justify-center space-x-4 mb-6">
              {[5, 10, 15, 20, 30].map((time) => (
                <button
                  key={time}
                  onClick={() => setMeditationTime(time)}
                  className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                    meditationTime === time
                      ? "bg-spiritual-turquoise-500 text-white"
                      : "bg-white border border-spiritual-turquoise-300 text-spiritual-turquoise-700 hover:bg-spiritual-turquoise-50"
                  }`}
                >
                  {time} dk
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-center space-x-4">
          {!isTimerRunning ? (
            <button
              onClick={startMeditation}
              className="bg-spiritual-turquoise-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spiritual-turquoise-600 transition-colors animate-float"
            >
              🧘‍♂️ Meditasyonu Başlat
            </button>
          ) : (
            <button
              onClick={stopMeditation}
              className="bg-red-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-red-600 transition-colors"
            >
              ⏹️ Durdur
            </button>
          )}
        </div>
      </div>

      {/* Meditation Techniques */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {meditationTechniques.map((technique) => (
          <div key={technique.id} className="spiritual-card p-6">
            <div className="flex items-center mb-4">
              <span className="text-4xl mr-4">{technique.icon}</span>
              <div>
                <h4 className="text-xl font-bold text-spiritual-turquoise-700">
                  {technique.title}
                </h4>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span>⏱️ {technique.duration}</span>
                  <span>📊 {technique.level}</span>
                </div>
              </div>
            </div>

            <p className="text-gray-600 mb-4">{technique.description}</p>

            <div className="space-y-2">
              <h5 className="font-semibold text-spiritual-purple-700">
                Uygulama Adımları:
              </h5>
              {technique.steps.map((step, index) => (
                <div key={index} className="flex items-start">
                  <span className="bg-spiritual-turquoise-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                    {index + 1}
                  </span>
                  <span className="text-sm text-gray-700">{step}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderDhikr = () => (
    <div className="space-y-8">
      {/* Dhikr Counter */}
      {selectedDhikr && (
        <div className="spiritual-card p-8 text-center">
          <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6">
            📿 Zikir Sayacı
          </h3>

          <div className="mb-6">
            <div className="text-6xl font-bold text-spiritual-gold-600 mb-4">
              {dhikrCount}
            </div>
            <p className="text-lg text-gray-600">
              {dhikrList.find((d) => d.id === selectedDhikr)?.transliteration}
            </p>
          </div>

          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setDhikrCount((prev) => prev + 1)}
              className="bg-spiritual-turquoise-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spiritual-turquoise-600 transition-colors"
            >
              ☝️ Zikir Yap
            </button>
            <button
              onClick={() => setDhikrCount(0)}
              className="bg-gray-500 text-white px-6 py-4 rounded-full font-semibold hover:bg-gray-600 transition-colors"
            >
              🔄 Sıfırla
            </button>
          </div>
        </div>
      )}

      {/* Dhikr List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {dhikrList.map((dhikr) => (
          <div
            key={dhikr.id}
            className={`spiritual-card p-6 cursor-pointer transition-all hover:scale-105 ${
              selectedDhikr === dhikr.id
                ? "ring-2 ring-spiritual-turquoise-500"
                : ""
            }`}
            onClick={() => {
              setSelectedDhikr(dhikr.id);
              setDhikrCount(0);
            }}
          >
            <div className="text-center mb-4">
              <div className="text-3xl font-arabic text-spiritual-turquoise-700 mb-2">
                {dhikr.arabic}
              </div>
              <h4 className="text-lg font-bold text-spiritual-purple-700">
                {dhikr.transliteration}
              </h4>
              <p className="text-sm text-gray-600 italic">{dhikr.meaning}</p>
            </div>

            <div className="text-center mb-4">
              <span className="bg-spiritual-gold-100 text-spiritual-gold-700 px-4 py-2 rounded-full font-semibold">
                {dhikr.count} defa
              </span>
            </div>

            <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
              <h5 className="font-semibold text-spiritual-turquoise-700 mb-2">
                Fazileti:
              </h5>
              <p className="text-sm text-gray-700">{dhikr.virtue}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderBenefits = () => (
    <div className="space-y-8">
      {/* Spiritual Benefits */}
      <div className="spiritual-card p-8">
        <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6 text-center">
          🌟 Meditasyon ve Zikrin Faydaları
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {spiritualBenefits.map((benefit, index) => (
            <div key={index} className="text-center p-6 bg-white rounded-lg">
              <div className="text-4xl mb-4">{benefit.icon}</div>
              <h4 className="text-lg font-bold text-spiritual-turquoise-700 mb-2">
                {benefit.title}
              </h4>
              <p className="text-sm text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Scientific Benefits */}
      <div className="spiritual-card p-8">
        <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6 text-center">
          🧠 Bilimsel Faydalar
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h4 className="text-xl font-semibold text-spiritual-turquoise-700 mb-4">
              Fiziksel Faydalar
            </h4>
            <ul className="space-y-2">
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Kan basıncını düzenler</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Kalp ritmi normalize olur</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Bağışıklık sistemi güçlenir</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Uyku kalitesi artar</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Kronik ağrılar azalır</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xl font-semibold text-spiritual-purple-700 mb-4">
              Zihinsel Faydalar
            </h4>
            <ul className="space-y-2">
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Konsantrasyon artır</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Hafıza güçlenir</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Yaratıcılık gelişir</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Kaygı ve stres azalır</span>
              </li>
              <li className="flex items-center">
                <span className="text-green-500 mr-2">✓</span>
                <span>Duygusal denge sağlanır</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderDaily = () => (
    <div className="space-y-8">
      {/* Daily Practice Schedule */}
      <div className="spiritual-card p-8">
        <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6 text-center">
          📅 Günlük Meditasyon Programı
        </h3>

        <div className="space-y-4">
          {dailyPractices.map((practice, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-white rounded-lg border border-spiritual-turquoise-200"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center text-white font-bold">
                  {index + 1}
                </div>
                <div>
                  <h4 className="font-bold text-spiritual-turquoise-700">
                    {practice.time}
                  </h4>
                  <p className="text-sm text-gray-600">
                    {practice.description}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-spiritual-purple-700">
                  {practice.practice}
                </p>
                <p className="text-sm text-gray-500">{practice.duration}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Progress Tracking */}
      <div className="spiritual-card p-8">
        <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6 text-center">
          📈 İlerleme Takibi
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-6 bg-spiritual-turquoise-50 rounded-lg">
            <div className="text-4xl font-bold text-spiritual-turquoise-600 mb-2">
              7
            </div>
            <p className="text-sm text-gray-600">Bu hafta (gün)</p>
          </div>
          <div className="text-center p-6 bg-spiritual-purple-50 rounded-lg">
            <div className="text-4xl font-bold text-spiritual-purple-600 mb-2">
              128
            </div>
            <p className="text-sm text-gray-600">Bu ay (dakika)</p>
          </div>
          <div className="text-center p-6 bg-spiritual-gold-50 rounded-lg">
            <div className="text-4xl font-bold text-spiritual-gold-600 mb-2">
              45
            </div>
            <p className="text-sm text-gray-600">Toplam (seans)</p>
          </div>
        </div>
      </div>

      {/* Islamic Meditation Quote */}
      <div className="spiritual-card p-8 text-center">
        <blockquote className="text-xl italic text-spiritual-turquoise-700 mb-4">
          "Allah'ı zikredenler ve O'nu zikrederken kalpleri huzur bulanlar..."
        </blockquote>
        <p className="text-spiritual-purple-600 font-semibold">
          (Ra'd Suresi, 28. Ayet)
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-spiritual-turquoise-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center animate-spiritual-glow">
                <span className="text-white font-bold text-xl">🕊️</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-spiritual-turquoise-600 to-spiritual-purple-600 bg-clip-text text-transparent">
                  Meditasyon & Zikir
                </h1>
                <p className="text-sm text-spiritual-gold-600 font-medium">
                  Kutbul Zaman - Manevi Rehberim
                </p>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-6">
              <Link
                href="/"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Ana Sayfa
              </Link>
              <Link
                href="/coaching"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Yaşam Koçluğu
              </Link>
              <Link
                href="/dreams"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Rüya Yorumu
              </Link>
              <Link
                href="/products"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Ürünler
              </Link>
              <Link
                href="/admin-login"
                className="text-red-600 hover:text-red-800 font-semibold"
                title="Admin Sistem Girişi"
              >
                🔐 Admin
              </Link>
              <Link
                href="/login"
                className="bg-spiritual-turquoise-500 text-white px-4 py-2 rounded-full"
              >
                Giriş
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-spiritual-turquoise-600 via-spiritual-purple-600 to-spiritual-gold-600 bg-clip-text text-transparent">
              🧘‍♂️ Meditasyon & Zikir
            </h1>
            <p className="text-xl text-gray-700 mb-12 leading-relaxed">
              İslami değerlerle harmanlanan meditasyon teknikleri ile ruhsal
              huzura ulaşın. Zikir, tefekkür ve murâkabe ile manevi gelişiminizi
              destekleyin.
            </p>

            {/* Tab Navigation */}
            <div className="flex justify-center mb-8">
              <div className="bg-white rounded-full p-2 shadow-lg">
                {[
                  { id: "guided", label: "Rehberli Meditasyon", icon: "🧘‍♂️" },
                  { id: "dhikr", label: "Zikir Uygulaması", icon: "📿" },
                  { id: "benefits", label: "Faydalar", icon: "🌟" },
                  { id: "daily", label: "Günlük Program", icon: "📅" },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                      activeTab === tab.id
                        ? "bg-spiritual-turquoise-500 text-white"
                        : "text-spiritual-turquoise-700 hover:bg-spiritual-turquoise-50"
                    }`}
                  >
                    {tab.icon} {tab.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="pb-16 px-4">
        <div className="container mx-auto">
          {activeTab === "guided" && renderGuidedMeditation()}
          {activeTab === "dhikr" && renderDhikr()}
          {activeTab === "benefits" && renderBenefits()}
          {activeTab === "daily" && renderDaily()}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-spiritual-turquoise-800 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h4 className="text-2xl font-bold mb-4">
            "Allah'ı anmakla kalpler huzur bulur"
          </h4>
          <p className="text-spiritual-turquoise-200 mb-6">
            Günlük meditasyon ve zikir pratikleri ile ruhsal gelişiminizi
            sürdürün
          </p>

          <div className="flex justify-center space-x-6">
            <Link
              href="/"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Ana Sayfa
            </Link>
            <Link
              href="/coaching"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Yaşam Koçluğu
            </Link>
            <Link
              href="/dreams"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Rüya Yorumu
            </Link>
            <Link
              href="/products"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Ürünler
            </Link>
          </div>

          <div className="mt-8 pt-6 border-t border-spiritual-turquoise-700">
            <p className="text-spiritual-turquoise-200 text-sm">
              © 2024 Kutbul Zaman - Manevi Rehberim. Tüm hakları saklıdır.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Meditation;
