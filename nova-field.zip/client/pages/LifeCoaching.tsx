import { useState } from "react";
import { Link } from "wouter";

const LifeCoaching = () => {
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [bookingForm, setBookingForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    preferredDate: "",
    preferredTime: "",
    message: "",
  });

  const coachingServices = [
    {
      id: "individual",
      title: "Bireysel Yaşam Koçluğu",
      icon: "👤",
      price: 150,
      duration: "60 dakika",
      description:
        "Kişisel gelişim, hedef belirleme ve yaşam dengesine odaklanır.",
      benefits: [
        "Kişisel hedef belirleme ve planlama",
        "Öz güven geliştirme teknikleri",
        "Stres yönetimi ve duygusal denge",
        "Karar verme becerilerini güçlendirme",
        "İlişkilerde iletişim becerileri",
        "Motivasyon ve odaklanma teknikleri",
      ],
    },
    {
      id: "family",
      title: "Aile Danışmanlığı",
      icon: "👨‍👩‍👧‍👦",
      price: 200,
      duration: "75 dakika",
      description:
        "Aile içi iletişim ve uyumu güçlendiren profesyonel danışmanlık.",
      benefits: [
        "Aile içi iletişimi güçlendirme",
        "Çift terapisi ve ilişki danışmanlığı",
        "Çocuk gelişimi ve ebeveynlik",
        "Aile çatışmalarını çözme teknikleri",
        "Rol dağılımı ve sorumluluklar",
        "Aile bütçesi ve finansal planlama",
      ],
    },
    {
      id: "spiritual",
      title: "Manevi Rehberlik",
      icon: "🕊️",
      price: 120,
      duration: "60 dakika",
      description: "İslami değerler çerçevesinde manevi gelişim ve rehberlik.",
      benefits: [
        "Nefs terbiyesi ve manevi arınma",
        "İbadet hayatını güçlendirme",
        "Manevi krizlerde rehberlik",
        "Kader ve tevekkül konularında danışmanlık",
        "Dua ve zikir alışkanlıkları",
        "Hayatın anlamı ve amaç belirleme",
      ],
    },
    {
      id: "career",
      title: "Kariyer Danışmanlığı",
      icon: "💼",
      price: 130,
      duration: "60 dakika",
      description:
        "Mesleki hedefler ve kariyer planlama konularında uzman desteği.",
      benefits: [
        "Kariyer hedefleri belirleme",
        "CV ve mülakata hazırlık",
        "İş-yaşam dengesini kurma",
        "Liderlik becerilerini geliştirme",
        "İş değişikliği süreçlerinde rehberlik",
        "Girişimcilik ve iş kurma danışmanlığı",
      ],
    },
    {
      id: "group",
      title: "Grup Seansları",
      icon: "👥",
      price: 75,
      duration: "90 dakika",
      description: "Grup dinamiği içinde yapılan yaşam koçluğu seansları.",
      benefits: [
        "Sosyal öğrenme ve paylaşım",
        "Motivasyon artırıcı grup dinamiği",
        "Farklı perspektiflerden faydalanma",
        "Uygun maliyetli çözüm",
        "Sosyal beceri geliştirme",
        "Deneyim paylaşımı ve network",
      ],
    },
    {
      id: "online",
      title: "Online Danışmanlık",
      icon: "💻",
      price: 100,
      duration: "45 dakika",
      description:
        "Uzaktan erişim ile video konferans üzerinden koçluk hizmeti.",
      benefits: [
        "Evden rahatça katılım",
        "Esnek zaman seçenekleri",
        "Kayıt alma imkanı",
        "Düşük maliyet avantajı",
        "Coğrafi sınır olmaksızın erişim",
        "Dijital materyal desteği",
      ],
    },
  ];

  const testimonials = [
    {
      name: "Ayşe K.",
      age: 34,
      service: "Bireysel Yaşam Koçluğu",
      rating: 5,
      comment:
        "Dr. Abdulkadir Kan ile çalışmak hayatımı değiştirdi. Artık hedeflerim net ve kendime olan güvenim tam.",
    },
    {
      name: "Mehmet Y.",
      age: 41,
      service: "Aile Danışmanlığı",
      rating: 5,
      comment:
        "Eşimle aramızdaki sorunları çözmeyi başardık. Aile içi iletişimimiz çok daha güçlü artık.",
    },
    {
      name: "Fatma S.",
      age: 28,
      service: "Manevi Rehberlik",
      rating: 5,
      comment:
        "Manevi gelişimimde çok büyük ilerlemeler kaydettim. Ruhsal huzurum yerine geldi.",
    },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  const handleBooking = (serviceId: string) => {
    setSelectedService(serviceId);
    setBookingForm((prev) => ({
      ...prev,
      service: serviceId,
    }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Booking form submission logic
    alert(
      "Randevu talebiniz alındı! Dr. Abdulkadir Kan sizinle 24 saat içinde iletişime geçecektir.",
    );
    setSelectedService(null);
    setBookingForm({
      name: "",
      email: "",
      phone: "",
      service: "",
      preferredDate: "",
      preferredTime: "",
      message: "",
    });
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-spiritual-turquoise-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center animate-spiritual-glow">
                <span className="text-white font-bold text-xl">🕊️</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-spiritual-turquoise-600 to-spiritual-purple-600 bg-clip-text text-transparent">
                  Kutbul Zaman
                </h1>
                <p className="text-sm text-spiritual-gold-600 font-medium">
                  Yaşam Koçluğu & Manevi Rehberlik
                </p>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-6">
              <Link
                href="/"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Ana Sayfa
              </Link>
              <Link
                href="/meditation"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Meditasyon
              </Link>
              <Link
                href="/dreams"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Rüya Yorumu
              </Link>
              <Link
                href="/products"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Ürünler
              </Link>
              <Link
                href="/admin-login"
                className="text-red-600 hover:text-red-800 font-semibold"
                title="Admin Sistem Girişi"
              >
                🔐 Admin
              </Link>
              <Link
                href="/login"
                className="bg-spiritual-turquoise-500 text-white px-4 py-2 rounded-full"
              >
                Giriş
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <div className="w-32 h-32 bg-spiritual-turquoise-500 rounded-full mx-auto mb-6 flex items-center justify-center animate-spiritual-glow">
                <span className="text-white text-6xl">👨‍⚕️</span>
              </div>
            </div>

            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-spiritual-turquoise-600 via-spiritual-purple-600 to-spiritual-gold-600 bg-clip-text text-transparent">
              Dr. Abdulkadir Kan
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-spiritual-purple-700 mb-8">
              Psikolog & Yaşam Koçu
            </h2>
            <p className="text-lg text-gray-700 mb-12 leading-relaxed">
              15 yıllık deneyim ile bireysel ve aile danışmanlığı, manevi
              rehberlik ve yaşam koçluğu hizmetleri. İslami değerler
              çerçevesinde modern psikoloji yaklaşımları ile hayatınızda pozitif
              değişimler yaratıyoruz.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <div className="spiritual-card p-6 text-center">
                <div className="text-3xl mb-4">🎓</div>
                <h3 className="font-bold text-spiritual-turquoise-700">
                  Eğitim
                </h3>
                <p className="text-sm text-gray-600">
                  İstanbul Üniversitesi Psikoloji Bölümü
                </p>
              </div>
              <div className="spiritual-card p-6 text-center">
                <div className="text-3xl mb-4">⭐</div>
                <h3 className="font-bold text-spiritual-purple-700">Deneyim</h3>
                <p className="text-sm text-gray-600">
                  15+ yıl profesyonel deneyim
                </p>
              </div>
              <div className="spiritual-card p-6 text-center">
                <div className="text-3xl mb-4">👥</div>
                <h3 className="font-bold text-spiritual-gold-700">
                  Müvekkilir
                </h3>
                <p className="text-sm text-gray-600">1000+ başarılı vaka</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 bg-white/50">
        <div className="container mx-auto">
          <h3 className="text-4xl font-bold text-center mb-12 text-spiritual-purple-700">
            Hizmetlerimiz
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {coachingServices.map((service) => (
              <div
                key={service.id}
                className="spiritual-card p-6 hover:transform hover:scale-105 transition-all duration-300"
              >
                <div className="text-center mb-6">
                  <div className="text-5xl mb-4">{service.icon}</div>
                  <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-2">
                    {service.title}
                  </h4>
                  <p className="text-gray-600 mb-4">{service.description}</p>

                  <div className="flex justify-between items-center mb-4">
                    <span className="text-2xl font-bold text-spiritual-gold-600">
                      {formatCurrency(service.price)}
                    </span>
                    <span className="text-sm text-gray-500">
                      {service.duration}
                    </span>
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                  {service.benefits.slice(0, 3).map((benefit, index) => (
                    <div key={index} className="flex items-center text-sm">
                      <span className="text-green-500 mr-2">✓</span>
                      <span className="text-gray-600">{benefit}</span>
                    </div>
                  ))}
                  {service.benefits.length > 3 && (
                    <p className="text-xs text-gray-500">
                      +{service.benefits.length - 3} diğer fayda
                    </p>
                  )}
                </div>

                <button
                  onClick={() => handleBooking(service.id)}
                  className="w-full bg-spiritual-turquoise-500 text-white py-3 rounded-lg hover:bg-spiritual-turquoise-600 transition-colors font-semibold"
                >
                  Randevu Al
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Approach Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-4xl font-bold mb-8 text-spiritual-purple-700">
              Yaklaşımımız
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="spiritual-card p-8">
                <div className="text-4xl mb-4">🧠</div>
                <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-4">
                  Modern Psikoloji
                </h4>
                <p className="text-gray-600">
                  Bilimsel temelli psikoloji yaklaşımları ile kanıta dayalı
                  terapi teknikleri kullanırız. CBT, mindfulness ve pozitif
                  psikoloji yöntemleri ile desteklenir.
                </p>
              </div>

              <div className="spiritual-card p-8">
                <div className="text-4xl mb-4">🕌</div>
                <h4 className="text-xl font-bold text-spiritual-purple-700 mb-4">
                  İslami Değerler
                </h4>
                <p className="text-gray-600">
                  İslam'ın güzel öğretileri ile modern psikoloji bilimini
                  harmanlayarak, maneviyat odaklı bir yaklaşım sunarız. Nefs
                  terbiyesi ve manevi gelişim önceliklidir.
                </p>
              </div>
            </div>

            <div className="spiritual-card p-8">
              <h4 className="text-2xl font-bold text-spiritual-gold-700 mb-6">
                Tedavi Süreci
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-spiritual-turquoise-500 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl">
                    1
                  </div>
                  <h5 className="font-semibold mb-2">Değerlendirme</h5>
                  <p className="text-sm text-gray-600">
                    İhtiyaç analizi ve hedef belirleme
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-spiritual-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl">
                    2
                  </div>
                  <h5 className="font-semibold mb-2">Planlama</h5>
                  <p className="text-sm text-gray-600">
                    Kişiselleştirilmiş terapi planı
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-spiritual-gold-500 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl">
                    3
                  </div>
                  <h5 className="font-semibold mb-2">Uygulama</h5>
                  <p className="text-sm text-gray-600">
                    Aktif terapi seansları
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl">
                    4
                  </div>
                  <h5 className="font-semibold mb-2">Takip</h5>
                  <p className="text-sm text-gray-600">
                    İlerleme değerlendirme
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 bg-white/50">
        <div className="container mx-auto">
          <h3 className="text-4xl font-bold text-center mb-12 text-spiritual-purple-700">
            Müvekkil Yorumları
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="spiritual-card p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center text-white font-bold mr-4">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-800">
                      {testimonial.name}
                    </h5>
                    <p className="text-sm text-gray-600">
                      {testimonial.age} yaş - {testimonial.service}
                    </p>
                  </div>
                </div>

                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <span key={i} className="text-yellow-500">
                      ⭐
                    </span>
                  ))}
                </div>

                <p className="text-gray-600 italic">"{testimonial.comment}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Modal */}
      {selectedService && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full max-h-screen overflow-y-auto">
            <h3 className="text-2xl font-bold text-spiritual-purple-700 mb-6">
              Randevu Talebi
            </h3>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Ad Soyad *
                </label>
                <input
                  type="text"
                  required
                  value={bookingForm.name}
                  onChange={(e) =>
                    setBookingForm((prev) => ({
                      ...prev,
                      name: e.target.value,
                    }))
                  }
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email *
                </label>
                <input
                  type="email"
                  required
                  value={bookingForm.email}
                  onChange={(e) =>
                    setBookingForm((prev) => ({
                      ...prev,
                      email: e.target.value,
                    }))
                  }
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Telefon *
                </label>
                <input
                  type="tel"
                  required
                  value={bookingForm.phone}
                  onChange={(e) =>
                    setBookingForm((prev) => ({
                      ...prev,
                      phone: e.target.value,
                    }))
                  }
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Hizmet
                </label>
                <input
                  type="text"
                  value={
                    coachingServices.find((s) => s.id === selectedService)
                      ?.title || ""
                  }
                  readOnly
                  className="w-full px-4 py-2 border rounded-lg bg-gray-50"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tercih Edilen Tarih
                  </label>
                  <input
                    type="date"
                    value={bookingForm.preferredDate}
                    onChange={(e) =>
                      setBookingForm((prev) => ({
                        ...prev,
                        preferredDate: e.target.value,
                      }))
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tercih Edilen Saat
                  </label>
                  <select
                    value={bookingForm.preferredTime}
                    onChange={(e) =>
                      setBookingForm((prev) => ({
                        ...prev,
                        preferredTime: e.target.value,
                      }))
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                  >
                    <option value="">Seçiniz</option>
                    <option value="09:00">09:00</option>
                    <option value="10:00">10:00</option>
                    <option value="11:00">11:00</option>
                    <option value="14:00">14:00</option>
                    <option value="15:00">15:00</option>
                    <option value="16:00">16:00</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Mesajınız
                </label>
                <textarea
                  value={bookingForm.message}
                  onChange={(e) =>
                    setBookingForm((prev) => ({
                      ...prev,
                      message: e.target.value,
                    }))
                  }
                  rows={3}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                  placeholder="Durumunuz hakkında kısa bilgi..."
                ></textarea>
              </div>

              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => setSelectedService(null)}
                  className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-spiritual-turquoise-500 text-white py-2 rounded-lg hover:bg-spiritual-turquoise-600"
                >
                  Randevu Talep Et
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Contact Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <h3 className="text-4xl font-bold mb-8 text-spiritual-purple-700">
            İletişim
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="spiritual-card p-6">
              <div className="text-3xl mb-4">📍</div>
              <h4 className="font-bold text-spiritual-turquoise-700 mb-2">
                Adres
              </h4>
              <p className="text-gray-600">
                Kadıköy, İstanbul
                <br />
                Acıbadem Mahallesi
              </p>
            </div>

            <div className="spiritual-card p-6">
              <div className="text-3xl mb-4">📞</div>
              <h4 className="font-bold text-spiritual-purple-700 mb-2">
                Telefon
              </h4>
              <p className="text-gray-600">
                +90 555 123 45 67
                <br />
                Hafta içi 09:00-18:00
              </p>
            </div>

            <div className="spiritual-card p-6">
              <div className="text-3xl mb-4">📧</div>
              <h4 className="font-bold text-spiritual-gold-700 mb-2">Email</h4>
              <p className="text-gray-600">
                psikologabdulkadirkan@gmail.com
                <br />
                24 saat içinde yanıt
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-spiritual-turquoise-800 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-6">
            <h4 className="text-2xl font-bold mb-2">Dr. Abdulkadir Kan</h4>
            <p className="text-spiritual-turquoise-200">
              Psikolog & Yaşam Koçu
            </p>
          </div>

          <div className="flex justify-center space-x-6 mb-6">
            <Link
              href="/"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Ana Sayfa
            </Link>
            <Link
              href="/meditation"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Meditasyon
            </Link>
            <Link
              href="/dreams"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Rüya Yorumu
            </Link>
            <Link
              href="/products"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Ürünler
            </Link>
          </div>

          <p className="text-spiritual-turquoise-200 text-sm">
            © 2024 Kutbul Zaman - Manevi Rehberim. Tüm hakları saklıdır.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default LifeCoaching;
