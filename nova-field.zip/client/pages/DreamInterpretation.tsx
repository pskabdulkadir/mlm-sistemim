import { useState } from "react";
import { Link } from "wouter";

const DreamInterpretation = () => {
  const [dreamText, setDreamText] = useState("");
  const [interpretation, setInterpretation] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");

  const dreamSymbols = [
    {
      category: "water",
      symbol: "Su",
      icon: "🌊",
      meanings: [
        "Temizlik ve arınma",
        "Manevi uyanış",
        "Bereket ve bolluk",
        "Yenilenme ve değişim",
      ],
      details:
        "Su, İslam'da temizlik ve bereketin sembolüdür. Temiz su görmek hayırlıdır.",
    },
    {
      category: "nature",
      symbol: "Ağaç",
      icon: "🌳",
      meanings: ["Büyüme ve gelişim", "Aile soyu", "Bereket", "Uzun yaşam"],
      details: "Yeşil ve meyve veren ağaç görmek, hayır ve bereket alametidir.",
    },
    {
      category: "animals",
      symbol: "Kuş",
      icon: "🕊️",
      meanings: ["Özgürlük", "Manevi yükseliş", "İyi haber", "Ruh hali"],
      details: "Beyaz kuş görmek, müjde ve güzel haberlere işarettir.",
    },
    {
      category: "light",
      symbol: "Nur",
      icon: "✨",
      meanings: [
        "İlahi rehberlik",
        "Hidayet",
        "Bilgi ve hikmet",
        "Manevi aydınlanma",
      ],
      details: "Nur görmek, Allah'ın rehberliğine ve hidayete delalet eder.",
    },
    {
      category: "celestial",
      symbol: "Ay",
      icon: "🌙",
      meanings: ["Güzellik", "Zaman döngüleri", "Kadın figürü", "Manevi nur"],
      details: "Dolunay görmek, güzellik ve kemale işaret eder.",
    },
    {
      category: "celestial",
      symbol: "Güneş",
      icon: "☀️",
      meanings: ["Liderlik", "Güç ve otorite", "Aydınlanma", "Babaya işaret"],
      details: "Güneş görmek, üstünlük ve yüksek mevki alameti olabilir.",
    },
    {
      category: "nature",
      symbol: "Çiçek",
      icon: "🌸",
      meanings: ["Güzellik", "Geçici mutluluk", "Sevgi", "Nimetler"],
      details:
        "Güzel kokulu çiçek görmek, geçici ama güzel olaylara işarettir.",
    },
    {
      category: "spiritual",
      symbol: "Melek",
      icon: "👼",
      meanings: ["İlahi koruma", "Müjde", "Manevi rehberlik", "Hayır dua"],
      details: "Melek görmek, Allah'ın koruması altında olduğunuza işarettir.",
    },
    {
      category: "buildings",
      symbol: "Mescit",
      icon: "🕌",
      meanings: ["İbadet", "Manevi barış", "Topluluk", "Hidayet"],
      details: "Mescit görmek, dini hayatta ilerleme ve hidayete delalet eder.",
    },
    {
      category: "water",
      symbol: "Deniz",
      icon: "🌊",
      meanings: ["Büyük güç", "Duygusal derinlik", "Seyahat", "Bilgi okyanusu"],
      details:
        "Sakin deniz görmek huzur, dalgalı deniz ise zorlukları işaret eder.",
    },
    {
      category: "animals",
      symbol: "Aslan",
      icon: "🦁",
      meanings: ["Güç ve cesaret", "Liderlik", "Düşman", "Adalet"],
      details: "Aslan görmek, güçlü bir kişiyi veya otoriteyi temsil edebilir.",
    },
    {
      category: "nature",
      symbol: "Dağ",
      icon: "⛰️",
      meanings: ["Sağlamlık", "Zorluklar", "Yüce kişi", "Sabır"],
      details:
        "Yüksek dağ görmek, büyük zorlukları veya yüce kişileri işaret eder.",
    },
  ];

  const dreamCategories = [
    { id: "all", name: "Tümü", icon: "🔮" },
    { id: "water", name: "Su", icon: "🌊" },
    { id: "nature", name: "Doğa", icon: "🌳" },
    { id: "animals", name: "Hayvanlar", icon: "🦁" },
    { id: "celestial", name: "Göksel", icon: "🌙" },
    { id: "spiritual", name: "Manevi", icon: "👼" },
    { id: "buildings", name: "Yapılar", icon: "🕌" },
    { id: "light", name: "Işık", icon: "✨" },
  ];

  const interpretationPrinciples = [
    {
      title: "Rüyanın Zamanı",
      description: "Fecir vakti görülen rüyalar daha doğru kabul edilir",
      icon: "🌅",
    },
    {
      title: "Kişinin Hali",
      description: "Rüyayı gören kişinin dini ve ahlaki durumu önemlidir",
      icon: "🤲",
    },
    {
      title: "Sembolik Anlam",
      description: "Her sembol kişinin yaşantısına göre farklı anlamlar taşır",
      icon: "🔍",
    },
    {
      title: "Genel Prensip",
      description: "Güzel rüyalar müjde, kötü rüyalar uyarı niteliğindedir",
      icon: "⚖️",
    },
  ];

  const famousInterpretations = [
    {
      symbol: "Yedi İnek",
      source: "Hz. Yusuf (as)",
      meaning: "Yedi bolluk yılı ve yedi kıtlık yılı",
      reference: "Yusuf Suresi",
    },
    {
      symbol: "Rüyada Namaz",
      source: "İslam Alimları",
      meaning: "Dinde istikrar ve hidayet üzere olma",
      reference: "Hadis Şerifleri",
    },
    {
      symbol: "Yeşil Kubbe",
      source: "Rüya Tabirleri",
      meaning: "Medine-i Münevvere'ye yapılacak ziyaret",
      reference: "Geleneksel Tabir",
    },
  ];

  const handleDreamAnalysis = async () => {
    if (!dreamText.trim()) return;

    setIsAnalyzing(true);

    // Simulate AI analysis delay
    await new Promise((resolve) => setTimeout(resolve, 3000));

    // Simple keyword-based interpretation
    const keywords = dreamText.toLowerCase();
    let analysis = "🔮 **Rüya Tahlili:**\n\n";

    if (
      keywords.includes("su") ||
      keywords.includes("deniz") ||
      keywords.includes("nehir")
    ) {
      analysis +=
        "💧 **Su Sembolü:** Gördüğünüz su, temizlik ve manevi arınmayı işaret eder. Bu rüya, yakında hayatınızda olumlu değişikliklerin olacağının müjdesi olabilir.\n\n";
    }

    if (keywords.includes("kuş") || keywords.includes("uçmak")) {
      analysis +=
        "🕊️ **Kuş/Uçma Sembolü:** Özgürlük ve manevi yükselişi temsil eder. Hedeflerinize ulaşma konusunda umutlu olabilirsiniz.\n\n";
    }

    if (
      keywords.includes("ışık") ||
      keywords.includes("nur") ||
      keywords.includes("parlak")
    ) {
      analysis +=
        "✨ **Işık/Nur Sembolü:** İlahi rehberlik ve hidayet alametidir. Doğru yolda olduğunuzun işareti sayılabilir.\n\n";
    }

    if (
      keywords.includes("ağaç") ||
      keywords.includes("orman") ||
      keywords.includes("yeşil")
    ) {
      analysis +=
        "🌳 **Doğa Sembolü:** Büyüme, gelişim ve bereketi işaret eder. Aile hayatınızda güzel gelişmeler olabilir.\n\n";
    }

    analysis +=
      "📚 **Genel Değerlendirme:**\nBu rüya, genel olarak hayırlı işaretler taşımaktadır. Ancak unutmayın ki rüya tabiri kişinin kendi yaşantısı ve durumu ile yakından ilgilidir.\n\n";
    analysis +=
      "🤲 **Tavsiye:**\nGüzel rüyalar için Allah'a şükretmek, kötü rüyalar için istiğfar etmek ve kimseye anlatmamak sünnet-i seniyyedir.\n\n";
    analysis +=
      "⚠️ **Not:** Bu bir otomatik analiz olup, kesin yorum için İslami rüya tabiri konusunda uzman bir alimle görüşmeniz önerilir.";

    setInterpretation(analysis);
    setIsAnalyzing(false);
  };

  const filteredSymbols =
    selectedCategory === "all"
      ? dreamSymbols
      : dreamSymbols.filter((symbol) => symbol.category === selectedCategory);

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-spiritual-turquoise-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center animate-spiritual-glow">
                <span className="text-white font-bold text-xl">🕊️</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-spiritual-turquoise-600 to-spiritual-purple-600 bg-clip-text text-transparent">
                  Rüya Yorumu
                </h1>
                <p className="text-sm text-spiritual-gold-600 font-medium">
                  Kutbul Zaman - Manevi Rehberim
                </p>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-6">
              <Link
                href="/"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Ana Sayfa
              </Link>
              <Link
                href="/coaching"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Yaşam Koçluğu
              </Link>
              <Link
                href="/meditation"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Meditasyon
              </Link>
              <Link
                href="/products"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
              >
                Ürünler
              </Link>
              <Link
                href="/admin-login"
                className="text-red-600 hover:text-red-800 font-semibold"
                title="Admin Sistem Girişi"
              >
                🔐 Admin
              </Link>
              <Link
                href="/login"
                className="bg-spiritual-turquoise-500 text-white px-4 py-2 rounded-full"
              >
                Giriş
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-spiritual-turquoise-600 via-spiritual-purple-600 to-spiritual-gold-600 bg-clip-text text-transparent">
              🌙 Rüya Yorumu & Tabiri
            </h1>
            <p className="text-xl text-gray-700 mb-12 leading-relaxed">
              İslami kaynaklara dayalı rüya tabiri ile gördüklerinizin manevi
              anlamlarını keşfedin. Hz. Yusuf (as) geleneğinden günümüze kadar
              gelen bilgilerle rüyalarınızı yorumlayın.
            </p>
          </div>
        </div>
      </section>

      {/* Dream Input Section */}
      <section className="pb-8 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="spiritual-card p-8">
            <h2 className="text-3xl font-bold text-spiritual-purple-700 mb-6 text-center">
              🔮 Rüyanızı Anlatın
            </h2>

            <div className="space-y-6">
              <div>
                <label className="block text-lg font-medium text-spiritual-turquoise-700 mb-3">
                  Gördüğünüz rüyayı detaylı olarak yazın:
                </label>
                <textarea
                  value={dreamText}
                  onChange={(e) => setDreamText(e.target.value)}
                  placeholder="Rüyanızda gördüklerinizi mümkün olduğunca detaylı anlatın. Renkler, kişiler, mekanlar, duygular gibi ayrıntıları belirtmeyi unutmayın..."
                  className="w-full h-40 p-4 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500 focus:border-transparent resize-none"
                />
                <p className="text-sm text-gray-600 mt-2">
                  En az 20 kelime yazmanız önerilir
                </p>
              </div>

              <div className="text-center">
                <button
                  onClick={handleDreamAnalysis}
                  disabled={!dreamText.trim() || isAnalyzing}
                  className="bg-spiritual-turquoise-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spiritual-turquoise-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105"
                >
                  {isAnalyzing ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mr-3"></div>
                      Rüya Yorumlanıyor...
                    </div>
                  ) : (
                    "🌟 Rüyamı Yorumla"
                  )}
                </button>
              </div>

              {/* Interpretation Result */}
              {interpretation && (
                <div className="mt-8 p-6 bg-spiritual-gold-50 border border-spiritual-gold-200 rounded-lg">
                  <h3 className="text-xl font-bold text-spiritual-gold-700 mb-4">
                    ✨ Rüya Tahlili
                  </h3>
                  <div className="prose prose-sm text-gray-700 whitespace-pre-line">
                    {interpretation}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Interpretation Principles */}
      <section className="py-8 px-4 bg-white/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-spiritual-purple-700">
            📚 Rüya Tabiri Prensipleri
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {interpretationPrinciples.map((principle, index) => (
              <div key={index} className="spiritual-card p-6 text-center">
                <div className="text-4xl mb-4">{principle.icon}</div>
                <h3 className="text-lg font-bold text-spiritual-turquoise-700 mb-3">
                  {principle.title}
                </h3>
                <p className="text-sm text-gray-600">{principle.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Dream Symbols Dictionary */}
      <section className="py-8 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8 text-spiritual-purple-700">
            📖 Rüya Sembolleri Sözlüğü
          </h2>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            {dreamCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full font-semibold transition-colors ${
                  selectedCategory === category.id
                    ? "bg-spiritual-turquoise-500 text-white"
                    : "bg-white border border-spiritual-turquoise-300 text-spiritual-turquoise-700 hover:bg-spiritual-turquoise-50"
                }`}
              >
                {category.icon} {category.name}
              </button>
            ))}
          </div>

          {/* Symbols Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSymbols.map((symbol, index) => (
              <div
                key={index}
                className="spiritual-card p-6 hover:transform hover:scale-105 transition-all"
              >
                <div className="text-center mb-4">
                  <div className="text-5xl mb-3">{symbol.icon}</div>
                  <h3 className="text-xl font-bold text-spiritual-turquoise-700">
                    {symbol.symbol}
                  </h3>
                </div>

                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-spiritual-purple-700 mb-2">
                      Anlamları:
                    </h4>
                    <ul className="space-y-1">
                      {symbol.meanings.map((meaning, idx) => (
                        <li key={idx} className="flex items-center text-sm">
                          <span className="text-spiritual-gold-500 mr-2">
                            ★
                          </span>
                          <span className="text-gray-700">{meaning}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-3 border-t border-gray-200">
                    <p className="text-sm text-gray-600 italic">
                      {symbol.details}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Famous Dream Interpretations */}
      <section className="py-8 px-4 bg-white/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-spiritual-purple-700">
            📜 Meşhur Rüya Tabirleri
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {famousInterpretations.map((interpretation, index) => (
              <div key={index} className="spiritual-card p-6">
                <h3 className="text-xl font-bold text-spiritual-turquoise-700 mb-3">
                  {interpretation.symbol}
                </h3>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm font-semibold text-spiritual-purple-600">
                      Kaynak:
                    </span>
                    <span className="text-sm text-gray-700 ml-1">
                      {interpretation.source}
                    </span>
                  </div>
                  <div>
                    <span className="text-sm font-semibold text-spiritual-gold-600">
                      Anlam:
                    </span>
                    <span className="text-sm text-gray-700 ml-1">
                      {interpretation.meaning}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">
                      Referans: {interpretation.reference}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Islamic Guidance */}
      <section className="py-8 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="spiritual-card p-8 text-center">
            <h2 className="text-3xl font-bold text-spiritual-purple-700 mb-6">
              🤲 İslami Rehberlik
            </h2>

            <div className="space-y-6 text-left">
              <blockquote className="text-lg italic text-spiritual-turquoise-700 text-center mb-6">
                "Rüya, nübüvvetin kırk altıda birlik kısmıdır."
                <footer className="text-spiritual-purple-600 font-semibold mt-2">
                  - Hz. Muhammed (sav)
                </footer>
              </blockquote>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-green-50 p-6 rounded-lg">
                  <h4 className="font-bold text-green-700 mb-3">
                    ✅ Güzel Rüya Görürseniz:
                  </h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li>• Allah'a şükredin</li>
                    <li>• Sevdiklerinizle paylaşabilirsiniz</li>
                    <li>• Hayırlı işaretler olarak değerlendirin</li>
                    <li>• Dua ve istighfar etmeyi sürdürün</li>
                  </ul>
                </div>

                <div className="bg-red-50 p-6 rounded-lg">
                  <h4 className="font-bold text-red-700 mb-3">
                    ⚠️ Kötü Rüya Görürseniz:
                  </h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li>• Kimseye anlatmayın</li>
                    <li>• İstiğfar edin ve tövbe edin</li>
                    <li>• Sol tarafınıza 3 defa tükürün</li>
                    <li>• Allah'a sığının ve dua edin</li>
                  </ul>
                </div>
              </div>

              <div className="bg-spiritual-turquoise-50 p-6 rounded-lg">
                <h4 className="font-bold text-spiritual-turquoise-700 mb-3">
                  📚 Önemli Hatırlatma:
                </h4>
                <p className="text-gray-700">
                  Bu sayfa genel bilgilendirme amaçlıdır. Kesin rüya tabiri için
                  İslami ilimler konusunda uzman olan alimlere danışmanız en
                  doğrusudur. Her rüya kişinin yaşantısı ve durumuna göre farklı
                  anlamlar taşıyabilir.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-spiritual-turquoise-800 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h4 className="text-2xl font-bold mb-4">
            "Rüya, müminin müjdesidir"
          </h4>
          <p className="text-spiritual-turquoise-200 mb-6">
            İslami kaynaklara dayalı rüya tabiri ile manevi yolculuğunuza ışık
            tutun
          </p>

          <div className="flex justify-center space-x-6">
            <Link
              href="/"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Ana Sayfa
            </Link>
            <Link
              href="/coaching"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Yaşam Koçluğu
            </Link>
            <Link
              href="/meditation"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Meditasyon
            </Link>
            <Link
              href="/products"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Ürünler
            </Link>
          </div>

          <div className="mt-8 pt-6 border-t border-spiritual-turquoise-700">
            <p className="text-spiritual-turquoise-200 text-sm">
              © 2024 Kutbul Zaman - Manevi Rehberim. Tüm hakları saklıdır.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default DreamInterpretation;
