import { useState, useEffect } from "react";
import { Link } from "wouter";
import { isFounderLoggedIn, initializeFounder } from "../lib/authUtils";

const Index = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Header Navigation */}
      <header className="bg-white/90 backdrop-blur-sm shadow-lg border-b border-spiritual-turquoise-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center animate-spiritual-glow">
                <span className="text-white font-bold text-xl">🕊️</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-spiritual-turquoise-600 to-spiritual-purple-600 bg-clip-text text-transparent">
                  Kutbul Zaman
                </h1>
                <p className="text-sm text-spiritual-gold-600 font-medium">
                  Manevi Rehberim
                </p>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link
                href="/"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium transition-colors"
              >
                Ana Sayfa
              </Link>
              <Link
                href="/coaching"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium transition-colors"
              >
                Yaşam Koçluğu
              </Link>
              <Link
                href="/meditation"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium transition-colors"
              >
                Meditasyon
              </Link>
              <Link
                href="/dreams"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium transition-colors"
              >
                Rüya Yorumu
              </Link>
              <Link
                href="/products"
                className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium transition-colors"
              >
                Ürünler
              </Link>
              <Link
                href="/admin-login"
                className="text-red-600 hover:text-red-800 font-semibold transition-colors"
                title="Admin Sistem Girişi"
              >
                🔐 Admin Giriş
              </Link>
              <Link
                href="/login"
                className="bg-spiritual-turquoise-500 text-white px-6 py-2 rounded-full hover:bg-spiritual-turquoise-600 transition-colors"
              >
                Giriş
              </Link>
              <Link
                href="/register"
                className="bg-spiritual-purple-500 text-white px-6 py-2 rounded-full hover:bg-spiritual-purple-600 transition-colors"
              >
                Üye Ol
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-spiritual-turquoise-700"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <nav className="md:hidden mt-4 pb-4 border-t border-spiritual-turquoise-200">
              <div className="flex flex-col space-y-3 pt-4">
                <Link
                  href="/"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium"
                >
                  Ana Sayfa
                </Link>
                <Link
                  href="/coaching"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium"
                >
                  Yaşam Koçluğu
                </Link>
                <Link
                  href="/meditation"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium"
                >
                  Meditasyon
                </Link>
                <Link
                  href="/dreams"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium"
                >
                  Rüya Yorumu
                </Link>
                <Link
                  href="/products"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600 font-medium"
                >
                  Ürünler
                </Link>
                <Link
                  href="/admin-login"
                  className="text-red-600 hover:text-red-800 font-semibold"
                >
                  🔐 Admin Giriş
                </Link>
                <div className="flex space-x-3 pt-2">
                  <Link
                    href="/login"
                    className="bg-spiritual-turquoise-500 text-white px-4 py-2 rounded-full text-sm"
                  >
                    Giriş
                  </Link>
                  <Link
                    href="/register"
                    className="bg-spiritual-purple-500 text-white px-4 py-2 rounded-full text-sm"
                  >
                    Üye Ol
                  </Link>
                </div>
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-spiritual-turquoise-600 via-spiritual-purple-600 to-spiritual-gold-600 bg-clip-text text-transparent animate-pulse-spiritual">
              Kutbul Zaman
            </h2>
            <h3 className="text-2xl md:text-3xl font-semibold text-spiritual-purple-700 mb-8">
              Manevi Rehberim
            </h3>
            <p className="text-lg text-gray-700 mb-12 leading-relaxed">
              Ruhani gelişim yolculuğunuzda size rehberlik eden, İslami
              değerlerle harmanlanmış manevi büyüme platformu. 7 Nefs
              seviyesinde kendinizi geliştirin ve hem maddi hem manevi
              kazanımlar elde edin.
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Link
                href="/register"
                className="bg-spiritual-turquoise-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spiritual-turquoise-600 transform hover:scale-105 transition-all duration-300 animate-float shadow-lg"
              >
                🎁 7 Gün Ücretsiz Dene
              </Link>
              <Link
                href="/coaching"
                className="bg-spiritual-purple-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spiritual-purple-600 transform hover:scale-105 transition-all duration-300 shadow-lg"
              >
                👨‍⚕️ Dr. Abdulkadir Kan
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 7 Nefs Levels Section */}
      <section className="py-16 px-4 bg-white/50">
        <div className="container mx-auto">
          <h3 className="text-4xl font-bold text-center mb-12 text-spiritual-purple-700">
            7 Nefs Seviyesi ile Manevi Gelişim
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[
              {
                level: 1,
                name: "Nefs-i Emmare",
                icon: "🌿",
                commission: "%20",
                desc: "Yöneten nefs - başlangıç seviyesi",
              },
              {
                level: 2,
                name: "Nefs-i Levvame",
                icon: "🌱",
                commission: "%15",
                desc: "Kınayan nefs - farkındalık",
              },
              {
                level: 3,
                name: "Nefs-i Mülhime",
                icon: "🌾",
                commission: "%12",
                desc: "İlham alan nefs - rehberlik",
              },
              {
                level: 4,
                name: "Nefs-i Mutmainne",
                icon: "���",
                commission: "%10",
                desc: "Huzurlu nefs - sükunet",
              },
              {
                level: 5,
                name: "Nefs-i Râziye",
                icon: "🌸",
                commission: "%8",
                desc: "Razı olan nefs - kabul",
              },
              {
                level: 6,
                name: "Nefs-i Mardiyye",
                icon: "🌷",
                commission: "%6",
                desc: "Beğenilen nefs - tevazu",
              },
              {
                level: 7,
                name: "Nefs-i Kâmile",
                icon: "🌺",
                commission: "%4",
                desc: "Mükemmel nefs - olgunluk",
              },
            ].map((nefs) => (
              <div
                key={nefs.level}
                className="spiritual-card p-6 text-center group"
              >
                <div className="text-4xl mb-4 group-hover:animate-float">
                  {nefs.icon}
                </div>
                <h4 className="text-lg font-bold text-spiritual-turquoise-700 mb-2">
                  {nefs.name}
                </h4>
                <p className="text-spiritual-purple-600 font-semibold mb-2">
                  Komisyon: {nefs.commission}
                </p>
                <p className="text-sm text-gray-600">{nefs.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h3 className="text-4xl font-bold text-center mb-12 text-spiritual-purple-700">
            Manevi Hizmetlerimiz
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="spiritual-card p-8 text-center">
              <div className="text-5xl mb-4">🧘‍♂️</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-4">
                Meditasyon & Zikir
              </h4>
              <p className="text-gray-600">
                Günlük meditasyon ve zikir uygulamaları ile ruhunuzu arındırın.
              </p>
            </div>

            <div className="spiritual-card p-8 text-center">
              <div className="text-5xl mb-4">🌙</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-4">
                Rüya Yorumu
              </h4>
              <p className="text-gray-600">
                Rüyalar��nızın manevi anlamlarını keşfedin ve rehberlik alın.
              </p>
            </div>

            <div className="spiritual-card p-8 text-center">
              <div className="text-5xl mb-4">⭐</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-4">
                Astroloji & Burç
              </h4>
              <p className="text-gray-600">
                Yıldızların rehberliğinde kişisel gelişim yolculuğunuz.
              </p>
            </div>

            <div className="spiritual-card p-8 text-center">
              <div className="text-5xl mb-4">🤲</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-4">
                Günlük Dualar
              </h4>
              <p className="text-gray-600">
                Her gün yeni dualar ve zikirlerle ruhunuzu besleyin.
              </p>
            </div>

            <div className="spiritual-card p-8 text-center">
              <div className="text-5xl mb-4">👨‍⚕️</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-4">
                Yaşam Koçluğu
              </h4>
              <p className="text-gray-600">
                Dr. Abdulkadir Kan ile kişisel gelişim ve yaşam koçluğu.
              </p>
            </div>

            <div className="spiritual-card p-8 text-center">
              <div className="text-5xl mb-4">🤖</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-4">
                AI Manevi Rehber
              </h4>
              <p className="text-gray-600">
                Yapay zeka destekli manevi rehberlik ve sorularınıza yanıt.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* MLM Benefits Section */}
      <section className="py-16 px-4 bg-white/50">
        <div className="container mx-auto text-center">
          <h3 className="text-4xl font-bold mb-12 text-spiritual-purple-700">
            Manevi Gelişim + Maddi Kazanım
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="spiritual-card p-6">
              <div className="text-4xl mb-4">💰</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-2">
                İkili Sistem
              </h4>
              <p className="text-gray-600">
                7 seviyeli ikili ağ sistemi ile sürekli gelir elde edin.
              </p>
            </div>

            <div className="spiritual-card p-6">
              <div className="text-4xl mb-4">🌐</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-2">
                Klon Sayfalar
              </h4>
              <p className="text-gray-600">
                Kendi referans sayfanızla kolayca üye kazanın.
              </p>
            </div>

            <div className="spiritual-card p-6">
              <div className="text-4xl mb-4">📈</div>
              <h4 className="text-xl font-bold text-spiritual-turquoise-700 mb-2">
                Komisyon Sistemi
              </h4>
              <p className="text-gray-600">
                %4'den %20'ye kadar artan komisyon oranları.
              </p>
            </div>
          </div>

          <div className="mt-12">
            <p className="text-xl text-spiritual-purple-700 mb-6">
              <strong>Üyelik:</strong> $100 başlangıç + $10/ay
            </p>
            <Link
              href="/register"
              className="bg-spiritual-gold-500 text-white px-10 py-4 rounded-full text-xl font-bold hover:bg-spiritual-gold-600 transform hover:scale-105 transition-all duration-300 animate-spiritual-glow"
            >
              🎁 7 Gün Ücretsiz Başla
            </Link>
          </div>
        </div>
      </section>

      {/* Daily Inspiration */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <h3 className="text-4xl font-bold mb-8 text-spiritual-purple-700">
            Günün Manevi Mesajı
          </h3>
          <div className="max-w-2xl mx-auto spiritual-card p-8">
            <blockquote className="text-xl italic text-spiritual-turquoise-700 mb-4">
              "Kim nefsini bilirse, Rabbini bilir."
            </blockquote>
            <p className="text-spiritual-purple-600 font-semibold">
              - Hz. Ali (ra)
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-spiritual-turquoise-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-xl font-bold mb-4">Kutbul Zaman</h4>
              <p className="text-spiritual-turquoise-200">
                Manevi gelişim ve maddi kazancı bir araya getiren platform.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Hizmetler</h4>
              <ul className="space-y-2 text-spiritual-turquoise-200">
                <li>
                  <Link href="/coaching">Yaşam Koçluğu</Link>
                </li>
                <li>
                  <Link href="/meditation">Meditasyon</Link>
                </li>
                <li>
                  <Link href="/dreams">Rüya Yorumu</Link>
                </li>
                <li>
                  <Link href="/horoscope">Astroloji</Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">MLM Sistemi</h4>
              <ul className="space-y-2 text-spiritual-turquoise-200">
                <li>
                  <Link href="/register">Üye Ol</Link>
                </li>
                <li>
                  <Link href="/dashboard">Panosu</Link>
                </li>
                <li>
                  <Link href="/commission">Komisyonlar</Link>
                </li>
                <li>
                  <Link href="/clone">Klon Sayfa</Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">İletişim</h4>
              <p className="text-spiritual-turquoise-200 mb-2">
                Dr. Abdulkadir Kan
              </p>
              <p className="text-spiritual-turquoise-200 text-sm">
                Psikolog & Yaşam Koçu
              </p>
            </div>
          </div>

          <div className="border-t border-spiritual-turquoise-700 mt-8 pt-8 text-center">
            <p className="text-spiritual-turquoise-200">
              © 2024 Kutbul Zaman - Manevi Rehberim. Tüm hakları saklıdır.
            </p>
            {/* Hidden Admin Access - Secret Link */}
            <div className="mt-4">
              <Link
                href="/admin-login"
                className="text-xs text-spiritual-turquoise-700 hover:text-spiritual-turquoise-300 opacity-30 hover:opacity-100 transition-all duration-300"
                title="Admin Giriş"
              >
                🔐
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
