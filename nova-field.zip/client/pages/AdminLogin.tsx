import { useState } from "react";
import { useLocation } from "wouter";

const AdminLogin = () => {
  const [, setLocation] = useLocation();
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Hidden admin credentials
  const ADMIN_CREDENTIALS = {
    username: "abdulkadirkan",
    password: "Abdulkadir1983",
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Simulate loading delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    if (
      credentials.username === ADMIN_CREDENTIALS.username &&
      credentials.password === ADMIN_CREDENTIALS.password
    ) {
      // Store admin authentication
      localStorage.setItem("adminAuth", "true");
      localStorage.setItem("adminUser", credentials.username);
      localStorage.setItem("adminLoginTime", new Date().toISOString());

      alert("🔐 Admin girişi başarılı! Sistem kontrolü aktif.");
      setLocation("/admin-dashboard");
    } else {
      setError("❌ Geçersiz admin bilgileri!");
    }

    setIsLoading(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCredentials((prev) => ({
      ...prev,
      [name]: value,
    }));
    setError("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-gray-900 to-black flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div
          className={
            'absolute inset-0 bg-[url(\'data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.1"%3E%3Ccircle cx="30" cy="30" r="1"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\')]'
          }
        ></div>
      </div>

      <div className="relative w-full max-w-md">
        {/* Admin Login Card */}
        <div className="bg-black/80 backdrop-blur-lg border border-red-500/30 rounded-2xl shadow-2xl p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-700 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <span className="text-white text-3xl">🔐</span>
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">ADMIN GİRİŞİ</h1>
            <p className="text-red-400 text-sm font-medium">
              Sistem Yönetim Paneli
            </p>
            <div className="w-16 h-1 bg-gradient-to-r from-red-500 to-red-700 rounded-full mx-auto mt-3"></div>
          </div>

          {/* Warning Banner */}
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6">
            <div className="flex items-center space-x-2">
              <span className="text-red-400 text-xl">⚠️</span>
              <div>
                <p className="text-red-400 text-sm font-semibold">GİZLİ ALAN</p>
                <p className="text-red-300 text-xs">
                  Sadece yetkili admin erişimi
                </p>
              </div>
            </div>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-500/20 border border-red-500 rounded-lg p-3 text-center">
                <p className="text-red-400 text-sm font-semibold">{error}</p>
              </div>
            )}

            <div>
              <label className="block text-red-300 text-sm font-semibold mb-2">
                🔑 Admin Kullanıcı Adı
              </label>
              <input
                type="text"
                name="username"
                value={credentials.username}
                onChange={handleInputChange}
                placeholder="Admin kullanıcı adını girin"
                className="w-full px-4 py-3 bg-gray-900/50 border border-red-500/30 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                required
                disabled={isLoading}
              />
            </div>

            <div>
              <label className="block text-red-300 text-sm font-semibold mb-2">
                🔒 Admin Şifre
              </label>
              <input
                type="password"
                name="password"
                value={credentials.password}
                onChange={handleInputChange}
                placeholder="Admin şifresini girin"
                className="w-full px-4 py-3 bg-gray-900/50 border border-red-500/30 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                required
                disabled={isLoading}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-4 rounded-lg font-bold text-lg hover:from-red-700 hover:to-red-800 transform hover:scale-105 transition-all duration-300 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Doğrulanıyor...</span>
                </div>
              ) : (
                <>🚀 ADMİN PANELİ'NE GİRİŞ</>
              )}
            </button>
          </form>

          {/* Security Notice */}
          <div className="mt-8 pt-6 border-t border-red-500/20">
            <div className="text-center">
              <p className="text-gray-400 text-xs mb-2">
                🔒 Güvenlik Bildirimi
              </p>
              <p className="text-gray-500 text-xs">
                Bu alan tamamen gizlidir ve sadece sistem yöneticisi erişebilir.
                Tüm giriş denemeleri kayıt altına alınmaktadır.
              </p>
            </div>
          </div>

          {/* Return to Site */}
          <div className="mt-6 text-center">
            <button
              onClick={() => setLocation("/")}
              className="text-red-400 hover:text-red-300 text-sm underline transition-colors"
            >
              ← Ana Siteye Dön
            </button>
          </div>
        </div>

        {/* Admin Features Preview */}
        <div className="mt-8 grid grid-cols-2 gap-4">
          <div className="bg-black/40 backdrop-blur border border-red-500/20 rounded-lg p-4 text-center">
            <div className="text-red-400 text-2xl mb-2">👥</div>
            <p className="text-white text-xs font-semibold">
              Kullanıcı Yönetimi
            </p>
          </div>
          <div className="bg-black/40 backdrop-blur border border-red-500/20 rounded-lg p-4 text-center">
            <div className="text-red-400 text-2xl mb-2">💰</div>
            <p className="text-white text-xs font-semibold">Finans Kontrolü</p>
          </div>
          <div className="bg-black/40 backdrop-blur border border-red-500/20 rounded-lg p-4 text-center">
            <div className="text-red-400 text-2xl mb-2">🌳</div>
            <p className="text-white text-xs font-semibold">MLM Sistemleri</p>
          </div>
          <div className="bg-black/40 backdrop-blur border border-red-500/20 rounded-lg p-4 text-center">
            <div className="text-red-400 text-2xl mb-2">⚙️</div>
            <p className="text-white text-xs font-semibold">Sistem Ayarları</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
