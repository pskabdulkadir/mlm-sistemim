import { useState } from "react";
import { Link } from "wouter";

const Products = () => {
  // Admin configurable product link
  const [productLink, setProductLink] = useState(
    "https://example.com/admin-products",
  );

  const redirectToProducts = () => {
    window.open(productLink, "_blank");
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-spiritual-turquoise-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-spiritual-turquoise-500 rounded-full flex items-center justify-center animate-spiritual-glow">
                <span className="text-white font-bold text-xl">🕊️</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-spiritual-turquoise-600 to-spiritual-purple-600 bg-clip-text text-transparent">
                  Manevi Ürünler
                </h1>
                <p className="text-sm text-spiritual-gold-600 font-medium">
                  Kutbul Zaman - Manevi Rehberim
                </p>
              </div>
            </Link>

            <div className="flex items-center space-x-6">
              <nav className="hidden md:flex items-center space-x-6">
                <Link
                  href="/"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
                >
                  Ana Sayfa
                </Link>
                <Link
                  href="/coaching"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
                >
                  Yaşam Koçluğu
                </Link>
                <Link
                  href="/meditation"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
                >
                  Meditasyon
                </Link>
                <Link
                  href="/dreams"
                  className="text-spiritual-turquoise-700 hover:text-spiritual-purple-600"
                >
                  Rüya Yorumu
                </Link>
                <Link
                  href="/admin-login"
                  className="text-red-600 hover:text-red-800 font-semibold"
                  title="Admin Sistem Girişi"
                >
                  🔐 Admin
                </Link>
              </nav>

              <Link
                href="/login"
                className="bg-spiritual-purple-500 text-white px-4 py-2 rounded-full hover:bg-spiritual-purple-600"
              >
                Giriş
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-spiritual-turquoise-600 via-spiritual-purple-600 to-spiritual-gold-600 bg-clip-text text-transparent">
              🛍️ Manevi Ürünler
            </h1>
            <p className="text-xl text-gray-700 mb-12 leading-relaxed">
              Manevi gelişiminizi destekleyen özel ürünler. Aşağıdaki butona
              tıklayarak ürün kataloğumuza ulaşabilirsiniz.
            </p>
          </div>
        </div>
      </section>

      {/* Product Link Section */}
      <section className="pb-16 px-4">
        <div className="container mx-auto max-w-2xl">
          <div className="spiritual-card p-12 text-center">
            <div className="text-8xl mb-8">🎁</div>
            <h2 className="text-3xl font-bold text-spiritual-purple-700 mb-6">
              Ürün Kataloğumuz
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Tüm manevi ürünlerimizi görmek ve satın almak için aşağıdaki
              butona tıklayın.
            </p>

            <button
              onClick={redirectToProducts}
              className="bg-spiritual-turquoise-500 text-white px-12 py-6 rounded-full text-2xl font-bold hover:bg-spiritual-turquoise-600 transform hover:scale-105 transition-all duration-300 animate-spiritual-glow"
            >
              🛒 Ürünleri Görüntüle
            </button>

            <div className="mt-12 pt-8 border-t border-spiritual-turquoise-200">
              <h3 className="text-xl font-semibold text-spiritual-gold-700 mb-4">
                💼 Satış Ortağı Olun
              </h3>
              <p className="text-gray-600 mb-6">
                MLM sistemimize katılarak ürün satışlarından komisyon kazanın.
              </p>
              <Link
                href="/register"
                className="bg-spiritual-gold-500 text-white px-8 py-3 rounded-full font-semibold hover:bg-spiritual-gold-600 transition-colors"
              >
                🚀 Ücretsiz Katıl
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Admin Control Panel (Hidden from regular users) */}
      <section className="pb-16 px-4">
        <div className="container mx-auto max-w-2xl">
          <div className="spiritual-card p-6">
            <h3 className="text-xl font-bold text-spiritual-purple-700 mb-4">
              ⚙️ Admin Kontrol Paneli
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Bu bölüm sadece admin tarafından görülebilir
            </p>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ürün Kataloğu URL'si:
                </label>
                <input
                  type="url"
                  value={productLink}
                  onChange={(e) => setProductLink(e.target.value)}
                  placeholder="https://example.com/products"
                  className="w-full px-4 py-2 border border-spiritual-turquoise-300 rounded-lg focus:ring-2 focus:ring-spiritual-turquoise-500"
                />
              </div>
              <button
                onClick={() => alert("Ürün linki güncellendi!")}
                className="bg-spiritual-purple-500 text-white px-6 py-2 rounded-lg hover:bg-spiritual-purple-600 transition-colors"
              >
                Linki Güncelle
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-spiritual-turquoise-800 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h4 className="text-2xl font-bold mb-4">
            Manevi Gelişim Ürünleri ile Hem Kendine Hem Cebine Fayda Sağla
          </h4>
          <p className="text-spiritual-turquoise-200 mb-6">
            Kaliteli ürünler, yüksek komisyonlar ve sürekli destek
          </p>

          <div className="flex justify-center space-x-6">
            <Link
              href="/"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Ana Sayfa
            </Link>
            <Link
              href="/coaching"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Yaşam Koçluğu
            </Link>
            <Link
              href="/meditation"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Meditasyon
            </Link>
            <Link
              href="/dreams"
              className="text-spiritual-turquoise-200 hover:text-white"
            >
              Rüya Yorumu
            </Link>
          </div>

          <div className="mt-8 pt-6 border-t border-spiritual-turquoise-700">
            <p className="text-spiritual-turquoise-200 text-sm">
              © 2024 Kutbul Zaman - Manevi Rehberim. Tüm hakları saklıdır.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Products;
