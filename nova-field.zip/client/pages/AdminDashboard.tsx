import { useState, useEffect } from "react";
import { useLocation } from "wouter";

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  nefsLevel: number;
  status: "active" | "inactive" | "trial" | "expired";
  accountType: "trial" | "active" | "expired";
  joinDate: string;
  totalEarnings: number;
  walletBalance: number;
  sponsorId: string;
  trialEndDate?: string;
}

interface FinanceRequest {
  id: string;
  userId: string;
  userName: string;
  type: "deposit" | "withdraw";
  amount: number;
  status: "pending" | "approved" | "rejected";
  date: string;
  receipt?: string;
  userIBAN?: string;
  reason?: string;
}

interface SystemSettings {
  siteName: string;
  adminIBAN: string;
  adminBank: string;
  activationFee: number;
  minWithdraw: number;
  maxWithdraw: number;
  iyzipayEnabled: boolean;
  maintenanceMode: boolean;
  registrationEnabled: boolean;
}

const AdminDashboard = () => {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [users, setUsers] = useState<User[]>([]);
  const [financeRequests, setFinanceRequests] = useState<FinanceRequest[]>([]);
  const [systemSettings, setSystemSettings] = useState<SystemSettings>({
    siteName: "Kutbul Zaman - Manevi Rehberim",
    adminIBAN: "TR86 0011 1000 0000 0091 7751 22",
    adminBank: "QNB Finans Bank",
    activationFee: 100,
    minWithdraw: 10,
    maxWithdraw: 5000,
    iyzipayEnabled: true,
    maintenanceMode: false,
    registrationEnabled: true,
  });

  const [newUser, setNewUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    nefsLevel: 1,
    sponsorId: "",
    walletBalance: 0,
  });

  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showEditUserModal, setShowEditUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Check admin authentication
  useEffect(() => {
    const isAdminAuth = localStorage.getItem("adminAuth");
    if (!isAdminAuth) {
      setLocation("/admin-login");
      return;
    }

    // Load data
    loadUsersFromStorage();
    loadFinanceRequestsFromStorage();
    loadSystemSettings();
  }, [setLocation]);

  const loadUsersFromStorage = () => {
    // Load from localStorage - in real app this would be from database
    const storedUsers = JSON.parse(localStorage.getItem("allUsers") || "[]");
    setUsers(storedUsers);
  };

  const loadFinanceRequestsFromStorage = () => {
    const requests = JSON.parse(localStorage.getItem("adminRequests") || "[]");
    setFinanceRequests(requests);
  };

  const loadSystemSettings = () => {
    const settings = JSON.parse(
      localStorage.getItem("systemSettings") || JSON.stringify(systemSettings),
    );
    setSystemSettings(settings);
  };

  const handleLogout = () => {
    localStorage.removeItem("adminAuth");
    localStorage.removeItem("adminUser");
    localStorage.removeItem("adminLoginTime");
    setLocation("/admin-login");
  };

  const addUser = () => {
    const userId = "MB" + Date.now().toString().slice(-6);
    const user: User = {
      id: userId,
      firstName: newUser.firstName,
      lastName: newUser.lastName,
      email: newUser.email,
      phone: newUser.phone,
      nefsLevel: newUser.nefsLevel,
      status: "active",
      accountType: "active",
      joinDate: new Date().toISOString(),
      totalEarnings: 0,
      walletBalance: newUser.walletBalance,
      sponsorId: newUser.sponsorId || "admin-added",
    };

    const updatedUsers = [...users, user];
    setUsers(updatedUsers);
    localStorage.setItem("allUsers", JSON.stringify(updatedUsers));

    setNewUser({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      nefsLevel: 1,
      sponsorId: "",
      walletBalance: 0,
    });
    setShowAddUserModal(false);
    alert(`✅ Kullanıcı başarıyla eklendi! ID: ${userId}`);
  };

  const deleteUser = (userId: string) => {
    if (
      confirm(
        "Bu kullanıcıyı kalıcı olarak silmek istediğinizden emin misiniz?",
      )
    ) {
      const updatedUsers = users.filter((user) => user.id !== userId);
      setUsers(updatedUsers);
      localStorage.setItem("allUsers", JSON.stringify(updatedUsers));
      alert("🗑️ Kullanıcı başarıyla silindi!");
    }
  };

  const updateUser = () => {
    if (!editingUser) return;

    const updatedUsers = users.map((user) =>
      user.id === editingUser.id ? editingUser : user,
    );
    setUsers(updatedUsers);
    localStorage.setItem("allUsers", JSON.stringify(updatedUsers));
    setShowEditUserModal(false);
    setEditingUser(null);
    alert("✅ Kullanıcı bilgileri güncellendi!");
  };

  const approveFinanceRequest = (requestId: string) => {
    const updatedRequests = financeRequests.map((req) =>
      req.id === requestId ? { ...req, status: "approved" as const } : req,
    );
    setFinanceRequests(updatedRequests);
    localStorage.setItem("adminRequests", JSON.stringify(updatedRequests));
    alert("✅ İşlem onaylandı!");
  };

  const rejectFinanceRequest = (requestId: string) => {
    const updatedRequests = financeRequests.map((req) =>
      req.id === requestId ? { ...req, status: "rejected" as const } : req,
    );
    setFinanceRequests(updatedRequests);
    localStorage.setItem("adminRequests", JSON.stringify(updatedRequests));
    alert("❌ İşlem reddedildi!");
  };

  const saveSystemSettings = () => {
    localStorage.setItem("systemSettings", JSON.stringify(systemSettings));
    alert("⚙️ Sistem ayarları kaydedildi!");
  };

  const resetSystem = () => {
    if (
      confirm("TÜM SİSTEMİ SIFIRLAMAK İSTİYOR MUSUNUZ? Bu işlem geri alınamaz!")
    ) {
      if (
        confirm("SON UYARI: Tüm kullanıcılar, veriler ve ayarlar silinecek!")
      ) {
        localStorage.clear();
        setUsers([]);
        setFinanceRequests([]);
        alert("🔥 Sistem tamamen sıfırlandı!");
        window.location.reload();
      }
    }
  };

  const exportData = () => {
    const exportData = {
      users,
      financeRequests,
      systemSettings,
      exportDate: new Date().toISOString(),
    };

    const dataStr = JSON.stringify(exportData, null, 2);
    const dataUri =
      "data:application/json;charset=utf-8," + encodeURIComponent(dataStr);

    const exportFileDefaultName = `kutbul-zaman-backup-${new Date().toISOString().slice(0, 10)}.json`;

    const linkElement = document.createElement("a");
    linkElement.setAttribute("href", dataUri);
    linkElement.setAttribute("download", exportFileDefaultName);
    linkElement.click();

    alert("📊 Sistem verileri başarıyla dışa aktarıldı!");
  };

  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter((u) => u.status === "active").length,
    trialUsers: users.filter((u) => u.accountType === "trial").length,
    totalEarnings: users.reduce((sum, u) => sum + u.totalEarnings, 0),
    totalWalletBalance: users.reduce((sum, u) => sum + u.walletBalance, 0),
    pendingRequests: financeRequests.filter((r) => r.status === "pending")
      .length,
  };

  const renderDashboard = () => (
    <div className="space-y-8">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-700 text-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">Toplam Kullanıcı</p>
              <p className="text-3xl font-bold">{stats.totalUsers}</p>
            </div>
            <div className="text-4xl opacity-80">👥</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-700 text-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">Aktif Kullanıcı</p>
              <p className="text-3xl font-bold">{stats.activeUsers}</p>
            </div>
            <div className="text-4xl opacity-80">✅</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-yellow-500 to-yellow-700 text-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-100 text-sm">Deneme Kullanıcısı</p>
              <p className="text-3xl font-bold">{stats.trialUsers}</p>
            </div>
            <div className="text-4xl opacity-80">🎁</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-700 text-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">Toplam Kazanç</p>
              <p className="text-3xl font-bold">${stats.totalEarnings}</p>
            </div>
            <div className="text-4xl opacity-80">💰</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-500 to-red-700 text-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100 text-sm">Bekleyen İşlem</p>
              <p className="text-3xl font-bold">{stats.pendingRequests}</p>
            </div>
            <div className="text-4xl opacity-80">⏳</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 text-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-indigo-100 text-sm">Toplam Bakiye</p>
              <p className="text-3xl font-bold">${stats.totalWalletBalance}</p>
            </div>
            <div className="text-4xl opacity-80">💳</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => setShowAddUserModal(true)}
          className="bg-green-500 text-white p-4 rounded-lg hover:bg-green-600 transition-colors"
        >
          <div className="text-2xl mb-2">➕</div>
          <p className="font-semibold">Kullanıcı Ekle</p>
        </button>

        <button
          onClick={exportData}
          className="bg-blue-500 text-white p-4 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <div className="text-2xl mb-2">📊</div>
          <p className="font-semibold">Veri Dışa Aktar</p>
        </button>

        <button
          onClick={() => setActiveTab("settings")}
          className="bg-purple-500 text-white p-4 rounded-lg hover:bg-purple-600 transition-colors"
        >
          <div className="text-2xl mb-2">⚙️</div>
          <p className="font-semibold">Sistem Ayarları</p>
        </button>

        <button
          onClick={resetSystem}
          className="bg-red-500 text-white p-4 rounded-lg hover:bg-red-600 transition-colors"
        >
          <div className="text-2xl mb-2">🔥</div>
          <p className="font-semibold">Sistemi Sıfırla</p>
        </button>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4">
          Son Aktiviteler
        </h3>
        <div className="space-y-3">
          {financeRequests.slice(0, 5).map((req) => (
            <div
              key={req.id}
              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <div
                  className={`w-3 h-3 rounded-full ${
                    req.status === "pending"
                      ? "bg-yellow-500"
                      : req.status === "approved"
                        ? "bg-green-500"
                        : "bg-red-500"
                  }`}
                ></div>
                <div>
                  <p className="font-semibold text-sm">{req.userName}</p>
                  <p className="text-xs text-gray-600">
                    {req.type === "deposit" ? "Para Yatırma" : "Para Çekme"} - $
                    {req.amount}
                  </p>
                </div>
              </div>
              <span className="text-xs text-gray-500">
                {new Date(req.date).toLocaleDateString("tr-TR")}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-gray-800">
          👥 Kullanıcı Yönetimi
        </h3>
        <button
          onClick={() => setShowAddUserModal(true)}
          className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 font-semibold"
        >
          ➕ Yeni Kullanıcı
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Kullanıcı
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İletişim
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Nefs Level
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Durum
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Bakiye
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İşlemler
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {user.firstName} {user.lastName}
                      </div>
                      <div className="text-sm text-gray-500">ID: {user.id}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{user.email}</div>
                    <div className="text-sm text-gray-500">{user.phone}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                      Level {user.nefsLevel}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        user.status === "active"
                          ? "bg-green-100 text-green-800"
                          : user.status === "trial"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {user.status === "active"
                        ? "Aktif"
                        : user.status === "trial"
                          ? "Deneme"
                          : "Pasif"}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${user.walletBalance}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => {
                        setEditingUser(user);
                        setShowEditUserModal(true);
                      }}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      ✏️ Düzenle
                    </button>
                    <button
                      onClick={() => deleteUser(user.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      🗑️ Sil
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderFinance = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-gray-800">💰 Finans Yönetimi</h3>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İşlem
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Kullanıcı
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tutar
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tarih
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Durum
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İşlemler
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {financeRequests.map((request) => (
                <tr key={request.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        request.type === "deposit"
                          ? "bg-green-100 text-green-800"
                          : "bg-blue-100 text-blue-800"
                      }`}
                    >
                      {request.type === "deposit" ? "💰 Yatırma" : "💸 Çekme"}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {request.userName}
                    </div>
                    <div className="text-sm text-gray-500">
                      {request.userId}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">
                    ${request.amount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(request.date).toLocaleDateString("tr-TR")}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        request.status === "pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : request.status === "approved"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {request.status === "pending"
                        ? "Bekliyor"
                        : request.status === "approved"
                          ? "Onaylandı"
                          : "Reddedildi"}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    {request.status === "pending" && (
                      <>
                        <button
                          onClick={() => approveFinanceRequest(request.id)}
                          className="text-green-600 hover:text-green-900"
                        >
                          ✅ Onayla
                        </button>
                        <button
                          onClick={() => rejectFinanceRequest(request.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          ❌ Reddet
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-gray-800">⚙️ Sistem Ayarları</h3>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Genel Ayarlar */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h4 className="text-lg font-semibold text-gray-800 mb-4">
            🌐 Genel Ayarlar
          </h4>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Site Adı
              </label>
              <input
                type="text"
                value={systemSettings.siteName}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    siteName: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Aktivasyon Ücreti ($)
              </label>
              <input
                type="number"
                value={systemSettings.activationFee}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    activationFee: Number(e.target.value),
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={systemSettings.registrationEnabled}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    registrationEnabled: e.target.checked,
                  })
                }
                className="mr-2"
              />
              <label className="text-sm text-gray-700">Kayıt Açık</label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={systemSettings.maintenanceMode}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    maintenanceMode: e.target.checked,
                  })
                }
                className="mr-2"
              />
              <label className="text-sm text-gray-700">Bakım Modu</label>
            </div>
          </div>
        </div>

        {/* Finans Ayarları */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h4 className="text-lg font-semibold text-gray-800 mb-4">
            💰 Finans Ayarları
          </h4>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Admin Banka
              </label>
              <input
                type="text"
                value={systemSettings.adminBank}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    adminBank: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Admin IBAN
              </label>
              <input
                type="text"
                value={systemSettings.adminIBAN}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    adminIBAN: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Min Çekim ($)
              </label>
              <input
                type="number"
                value={systemSettings.minWithdraw}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    minWithdraw: Number(e.target.value),
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Çekim ($)
              </label>
              <input
                type="number"
                value={systemSettings.maxWithdraw}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    maxWithdraw: Number(e.target.value),
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={systemSettings.iyzipayEnabled}
                onChange={(e) =>
                  setSystemSettings({
                    ...systemSettings,
                    iyzipayEnabled: e.target.checked,
                  })
                }
                className="mr-2"
              />
              <label className="text-sm text-gray-700">Iyzipay Aktif</label>
            </div>
          </div>
        </div>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={saveSystemSettings}
          className="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 font-semibold"
        >
          💾 Ayarları Kaydet
        </button>
        <button
          onClick={resetSystem}
          className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 font-semibold"
        >
          🔥 Sistemi Sıfırla
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Admin Header */}
      <header className="bg-gradient-to-r from-red-600 to-red-800 text-white shadow-lg">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">🔐</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold">SİSTEM YÖNETİM PANELİ</h1>
                <p className="text-red-200 text-sm">
                  Kutbul Zaman - Admin Control
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium">
                  Admin: {localStorage.getItem("adminUser")}
                </p>
                <p className="text-xs text-red-200">Tam Erişim Aktif</p>
              </div>
              <button
                onClick={handleLogout}
                className="bg-red-700 text-white px-4 py-2 rounded-lg hover:bg-red-800 text-sm font-semibold"
              >
                🚪 Çıkış Yap
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Admin Sidebar */}
        <aside className="w-64 bg-white shadow-lg min-h-screen">
          <nav className="p-4">
            <ul className="space-y-2">
              {[
                { id: "dashboard", label: "Ana Panel", icon: "📊" },
                { id: "users", label: "Kullanıcılar", icon: "👥" },
                { id: "finance", label: "Finans", icon: "💰" },
                { id: "mlm", label: "MLM Sistemi", icon: "🌳" },
                { id: "payments", label: "Ödemeler", icon: "💳" },
                { id: "content", label: "İçerik", icon: "📝" },
                { id: "reports", label: "Raporlar", icon: "📈" },
                { id: "settings", label: "Ayarlar", icon: "⚙️" },
                { id: "logs", label: "Loglar", icon: "📋" },
                { id: "backup", label: "Yedekleme", icon: "💾" },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                      activeTab === item.id
                        ? "bg-red-100 text-red-700 border-l-4 border-red-500"
                        : "text-gray-600 hover:bg-gray-100"
                    }`}
                  >
                    <span className="text-xl">{item.icon}</span>
                    <span className="font-medium">{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Main Admin Content */}
        <main className="flex-1 p-8">
          {activeTab === "dashboard" && renderDashboard()}
          {activeTab === "users" && renderUsers()}
          {activeTab === "finance" && renderFinance()}
          {activeTab === "settings" && renderSettings()}

          {/* MLM System Controls */}
          {activeTab === "mlm" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">
                🌳 MLM Sistemi Yönetimi
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    💰 Komisyon Oranları
                  </h4>
                  <div className="space-y-2">
                    {[
                      { level: 1, name: "Nefs-i Emmare", commission: 20 },
                      { level: 2, name: "Nefs-i Levvame", commission: 15 },
                      { level: 3, name: "Nefs-i Mülhime", commission: 12 },
                      { level: 4, name: "Nefs-i Mutmainne", commission: 10 },
                      { level: 5, name: "Nefs-i Râziye", commission: 8 },
                      { level: 6, name: "Nefs-i Mardiyye", commission: 6 },
                      { level: 7, name: "Nefs-i Kâmile", commission: 4 },
                    ].map((nefs) => (
                      <div
                        key={nefs.level}
                        className="flex justify-between items-center p-2 bg-gray-50 rounded"
                      >
                        <span className="text-sm font-medium">
                          Level {nefs.level}
                        </span>
                        <span className="text-sm text-green-600">
                          %{nefs.commission}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    🌳 İkili Ağaç Kontrolü
                  </h4>
                  <div className="space-y-4">
                    <button className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600">
                      Ağaç Yapısını Görüntüle
                    </button>
                    <button className="w-full bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600">
                      Manuel Yerleştirme
                    </button>
                    <button className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600">
                      Otomatik Yerleştirme
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    📊 MLM İstatistikler
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Toplam Ağ:</span>
                      <span className="font-semibold">{stats.totalUsers}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Aktif Ağ:</span>
                      <span className="font-semibold">{stats.activeUsers}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Toplam Komisyon:</span>
                      <span className="font-semibold">
                        ${(stats.totalEarnings * 0.1).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Payments System */}
          {activeTab === "payments" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">
                💳 Ödeme Sistemi Yönetimi
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    🔒 Iyzipay Ayarları
                  </h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Iyzipay Aktif:</span>
                      <span
                        className={`px-2 py-1 rounded text-xs ${systemSettings.iyzipayEnabled ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                      >
                        {systemSettings.iyzipayEnabled ? "Aktif" : "Pasif"}
                      </span>
                    </div>
                    <button className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600">
                      API Ayarlarını Düzenle
                    </button>
                    <button className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600">
                      Test Ödemesi Yap
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    🏦 Banka Ayarları
                  </h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-600">Banka:</p>
                      <p className="font-semibold">
                        {systemSettings.adminBank}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">IBAN:</p>
                      <p className="font-semibold">
                        {systemSettings.adminIBAN}
                      </p>
                    </div>
                    <button className="mt-3 w-full bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600">
                      Banka Bilgilerini Güncelle
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Content Management */}
          {activeTab === "content" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">
                📝 İçerik Yönetimi
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    🧘‍♂️ Meditasyon İçeriği
                  </h4>
                  <div className="space-y-3">
                    <button className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600">
                      YouTube Linklerini Yönet
                    </button>
                    <button className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600">
                      Zikir Listesini D��zenle
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    🤲 Dua İçeriği
                  </h4>
                  <div className="space-y-3">
                    <button className="w-full bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600">
                      Günlük Duaları Yönet
                    </button>
                    <button className="w-full bg-indigo-500 text-white py-2 rounded-lg hover:bg-indigo-600">
                      Özel Dualar Ekle
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    🌙 Rüya Yorumu
                  </h4>
                  <div className="space-y-3">
                    <button className="w-full bg-yellow-500 text-white py-2 rounded-lg hover:bg-yellow-600">
                      Sembol Sözlüğünü Düzenle
                    </button>
                    <button className="w-full bg-orange-500 text-white py-2 rounded-lg hover:bg-orange-600">
                      AI Yorumları Kontrol Et
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Reports and Analytics */}
          {activeTab === "reports" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">
                📈 Raporlar ve Analizler
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    📊 Kullanıcı Analizi
                  </h4>
                  <div className="space-y-4">
                    <div className="h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                      <span className="text-gray-500">Grafik Alanı</span>
                    </div>
                    <button className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600">
                      Detaylı Raporu İndir
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    💰 Finansal Rapor
                  </h4>
                  <div className="space-y-4">
                    <div className="h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                      <span className="text-gray-500">Gelir Grafiği</span>
                    </div>
                    <button className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600">
                      Mali Raporu İndir
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* System Logs */}
          {activeTab === "logs" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">
                📋 Sistem Logları
              </h3>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="text-lg font-semibold text-gray-800">
                      Son Aktiviteler
                    </h4>
                    <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                      Logları Temizle
                    </button>
                  </div>

                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {[
                      {
                        time: new Date().toISOString(),
                        action: "Admin login",
                        user: "abdulkadirkan",
                      },
                      {
                        time: new Date(Date.now() - 60000).toISOString(),
                        action: "User registration",
                        user: "test@example.com",
                      },
                      {
                        time: new Date(Date.now() - 120000).toISOString(),
                        action: "Payment request",
                        user: "member123",
                      },
                      {
                        time: new Date(Date.now() - 180000).toISOString(),
                        action: "System backup",
                        user: "system",
                      },
                    ].map((log, index) => (
                      <div
                        key={index}
                        className="p-3 bg-gray-50 rounded-lg text-sm"
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-medium">{log.action}</span>
                          <span className="text-gray-500">
                            {new Date(log.time).toLocaleString("tr-TR")}
                          </span>
                        </div>
                        <p className="text-gray-600">Kullanıcı: {log.user}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Backup System */}
          {activeTab === "backup" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">
                💾 Yedekleme Sistemi
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    🔄 Otomatik Yedekleme
                  </h4>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Otomatik Yedekleme:</span>
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                        Aktif
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Son Yedekleme:</span>
                      <span className="text-sm text-gray-600">
                        {new Date().toLocaleDateString("tr-TR")}
                      </span>
                    </div>
                    <button
                      onClick={exportData}
                      className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600"
                    >
                      Manuel Yedekleme Yap
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    📥 Veri Geri Yükleme
                  </h4>
                  <div className="space-y-4">
                    <input
                      type="file"
                      accept=".json"
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                    <button className="w-full bg-orange-500 text-white py-2 rounded-lg hover:bg-orange-600">
                      Yedekten Geri Yükle
                    </button>
                    <p className="text-xs text-red-600">
                      ⚠️ Bu işlem mevcut verileri geçersiz kılacaktır!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">
              ➕ Yeni Kullanıcı Ekle
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Ad
                </label>
                <input
                  type="text"
                  value={newUser.firstName}
                  onChange={(e) =>
                    setNewUser({ ...newUser, firstName: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Soyad
                </label>
                <input
                  type="text"
                  value={newUser.lastName}
                  onChange={(e) =>
                    setNewUser({ ...newUser, lastName: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={newUser.email}
                  onChange={(e) =>
                    setNewUser({ ...newUser, email: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Telefon
                </label>
                <input
                  type="tel"
                  value={newUser.phone}
                  onChange={(e) =>
                    setNewUser({ ...newUser, phone: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nefs Level
                </label>
                <select
                  value={newUser.nefsLevel}
                  onChange={(e) =>
                    setNewUser({
                      ...newUser,
                      nefsLevel: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  {[1, 2, 3, 4, 5, 6, 7].map((level) => (
                    <option key={level} value={level}>
                      Level {level}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Başlangıç Bakiyesi ($)
                </label>
                <input
                  type="number"
                  value={newUser.walletBalance}
                  onChange={(e) =>
                    setNewUser({
                      ...newUser,
                      walletBalance: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>

            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowAddUserModal(false)}
                className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600"
              >
                İptal
              </button>
              <button
                onClick={addUser}
                className="flex-1 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600"
              >
                ✅ Kullanıcı Ekle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {showEditUserModal && editingUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">
              ✏️ Kullanıcı Düzenle
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Ad
                </label>
                <input
                  type="text"
                  value={editingUser.firstName}
                  onChange={(e) =>
                    setEditingUser({
                      ...editingUser,
                      firstName: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Soyad
                </label>
                <input
                  type="text"
                  value={editingUser.lastName}
                  onChange={(e) =>
                    setEditingUser({ ...editingUser, lastName: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={editingUser.email}
                  onChange={(e) =>
                    setEditingUser({ ...editingUser, email: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nefs Level
                </label>
                <select
                  value={editingUser.nefsLevel}
                  onChange={(e) =>
                    setEditingUser({
                      ...editingUser,
                      nefsLevel: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  {[1, 2, 3, 4, 5, 6, 7].map((level) => (
                    <option key={level} value={level}>
                      Level {level}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Durum
                </label>
                <select
                  value={editingUser.status}
                  onChange={(e) =>
                    setEditingUser({
                      ...editingUser,
                      status: e.target.value as any,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="active">Aktif</option>
                  <option value="inactive">Pasif</option>
                  <option value="trial">Deneme</option>
                  <option value="expired">Süresi Dolmuş</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Cüzdan Bakiyesi ($)
                </label>
                <input
                  type="number"
                  value={editingUser.walletBalance}
                  onChange={(e) =>
                    setEditingUser({
                      ...editingUser,
                      walletBalance: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>

            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => {
                  setShowEditUserModal(false);
                  setEditingUser(null);
                }}
                className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600"
              >
                İptal
              </button>
              <button
                onClick={updateUser}
                className="flex-1 bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600"
              >
                💾 Güncelle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
