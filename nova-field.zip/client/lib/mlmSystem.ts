// MLM System Core Functions
export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  sponsorId: string;
  nefsLevel: number;
  status: "active" | "inactive" | "trial" | "expired";
  accountType: "trial" | "active" | "expired";
  joinDate: string;
  renewalDate: string;
  lastRenewalDate?: string;
  position: "left" | "right" | null;
  parentId?: string;
  leftLegVolume: number;
  rightLegVolume: number;
  personalSales: number;
  totalEarnings: number;
  walletBalance: number;
  bonusHistory: BonusRecord[];
  renewalHistory: RenewalRecord[];
  loginHistory: LoginRecord[];
  ipAddress?: string;
  deviceInfo?: string;
  twoFactorEnabled: boolean;
  role: "user" | "admin" | "dealer";
}

export interface BonusRecord {
  id: string;
  userId: string;
  type: "sponsor" | "matching" | "leadership" | "sales" | "passive" | "binary";
  amount: number;
  date: string;
  description: string;
  fromUserId?: string;
  leftVolume?: number;
  rightVolume?: number;
  calculationDetails?: any;
}

export interface RenewalRecord {
  id: string;
  userId: string;
  renewalDate: string;
  nextRenewalDate: string;
  amount: number;
  status: "completed" | "pending" | "overdue";
  remindersSent: number;
}

export interface LoginRecord {
  id: string;
  userId: string;
  loginTime: string;
  ipAddress: string;
  deviceInfo: string;
  success: boolean;
  twoFactorUsed: boolean;
}

// Nefs Levels Configuration
export const NEFS_LEVELS = [
  {
    level: 1,
    name: "Nefs-i Emmare",
    icon: "🌿",
    commission: 20,
    minReferrals: 1,
    monthlyFee: 50,
  },
  {
    level: 2,
    name: "Nefs-i Levvame",
    icon: "🌱",
    commission: 15,
    minReferrals: 2,
    monthlyFee: 60,
  },
  {
    level: 3,
    name: "Nefs-i Mülhime",
    icon: "🌾",
    commission: 12,
    minReferrals: 4,
    monthlyFee: 70,
  },
  {
    level: 4,
    name: "Nefs-i Mutmainne",
    icon: "🌼",
    commission: 10,
    minReferrals: 8,
    monthlyFee: 80,
  },
  {
    level: 5,
    name: "Nefs-i Râziye",
    icon: "🌸",
    commission: 8,
    minReferrals: 16,
    monthlyFee: 90,
  },
  {
    level: 6,
    name: "Nefs-i Mardiyye",
    icon: "🌷",
    commission: 6,
    minReferrals: 32,
    monthlyFee: 100,
  },
  {
    level: 7,
    name: "Nefs-i Kâmile",
    icon: "🌺",
    commission: 4,
    minReferrals: 64,
    monthlyFee: 120,
  },
];

// Income Types Configuration
export const INCOME_TYPES = {
  sponsor: { rate: 25, description: "Sponsor Bonusu - Yeni üye kazandırma" },
  matching: { rate: 10, description: "Eşleşme Bonusu - Sağ/sol kol dengesi" },
  leadership: {
    baseAmount: 500,
    description: "Liderlik Bonusu - Aylık sabit gelir",
  },
  sales: { rate: 15, description: "Satış Bonusu - Kişisel satışlar" },
  passive: {
    rates: [5, 4, 3, 2, 1],
    description: "Pasif Gelir - Alt kol satışları",
  },
  binary: { rate: 10, description: "Binary Bonus - Zayıf kolun %10'u" },
};

// Binary Bonus Calculation Function
export function calculateBinaryBonus(
  user: User,
  allUsers: User[],
): BonusRecord {
  const leftVolume = calculateLegVolume(user.id, "left", allUsers);
  const rightVolume = calculateLegVolume(user.id, "right", allUsers);

  // Zayıf kolu belirle
  const weakerLeg = Math.min(leftVolume, rightVolume);
  const strongerLeg = Math.max(leftVolume, rightVolume);

  // %10 binary bonus hesapla
  const bonusAmount = (weakerLeg * INCOME_TYPES.binary.rate) / 100;

  // Bonus kaydı oluştur
  const bonusRecord: BonusRecord = {
    id: `BIN${Date.now()}`,
    userId: user.id,
    type: "binary",
    amount: bonusAmount,
    date: new Date().toISOString(),
    description: `Binary Bonus - Zayıf kol: $${weakerLeg}`,
    leftVolume: leftVolume,
    rightVolume: rightVolume,
    calculationDetails: {
      leftLeg: leftVolume,
      rightLeg: rightVolume,
      weakerLeg: weakerLeg,
      strongerLeg: strongerLeg,
      rate: INCOME_TYPES.binary.rate,
    },
  };

  return bonusRecord;
}

// Calculate leg volume recursively
function calculateLegVolume(
  userId: string,
  leg: "left" | "right",
  allUsers: User[],
): number {
  const directMembers = allUsers.filter(
    (u) => u.parentId === userId && u.position === leg,
  );

  let totalVolume = 0;

  for (const member of directMembers) {
    // Add member's personal sales
    totalVolume += member.personalSales;

    // Add member's downline volume recursively
    totalVolume += calculateLegVolume(member.id, "left", allUsers);
    totalVolume += calculateLegVolume(member.id, "right", allUsers);
  }

  return totalVolume;
}

// Calculate all bonus types for a user
export function calculateAllBonuses(
  user: User,
  allUsers: User[],
  weeklyData: any,
): BonusRecord[] {
  const bonuses: BonusRecord[] = [];

  // 1. Binary Bonus
  const binaryBonus = calculateBinaryBonus(user, allUsers);
  if (binaryBonus.amount > 0) {
    bonuses.push(binaryBonus);
  }

  // 2. Sponsor Bonus
  const sponsorBonuses = calculateSponsorBonuses(user, allUsers);
  bonuses.push(...sponsorBonuses);

  // 3. Matching Bonus
  const matchingBonus = calculateMatchingBonus(user, allUsers);
  if (matchingBonus.amount > 0) {
    bonuses.push(matchingBonus);
  }

  // 4. Leadership Bonus
  const leadershipBonus = calculateLeadershipBonus(user, allUsers);
  if (leadershipBonus.amount > 0) {
    bonuses.push(leadershipBonus);
  }

  // 5. Sales Bonus
  const salesBonus = calculateSalesBonus(user);
  if (salesBonus.amount > 0) {
    bonuses.push(salesBonus);
  }

  // 6. Passive Income
  const passiveBonuses = calculatePassiveIncome(user, allUsers);
  bonuses.push(...passiveBonuses);

  return bonuses;
}

// Sponsor Bonus Calculation
function calculateSponsorBonuses(user: User, allUsers: User[]): BonusRecord[] {
  const directReferrals = allUsers.filter((u) => u.sponsorId === user.id);
  const bonuses: BonusRecord[] = [];

  directReferrals.forEach((referral) => {
    if (referral.personalSales > 0) {
      const bonusAmount =
        (referral.personalSales * INCOME_TYPES.sponsor.rate) / 100;

      bonuses.push({
        id: `SPO${Date.now()}_${referral.id}`,
        userId: user.id,
        type: "sponsor",
        amount: bonusAmount,
        date: new Date().toISOString(),
        description: `Sponsor bonus from ${referral.firstName} ${referral.lastName}`,
        fromUserId: referral.id,
      });
    }
  });

  return bonuses;
}

// Matching Bonus Calculation
function calculateMatchingBonus(user: User, allUsers: User[]): BonusRecord {
  const leftVolume = calculateLegVolume(user.id, "left", allUsers);
  const rightVolume = calculateLegVolume(user.id, "right", allUsers);

  // Eşleşen hacim (daha küçük olan)
  const matchedVolume = Math.min(leftVolume, rightVolume);
  const bonusAmount = (matchedVolume * INCOME_TYPES.matching.rate) / 100;

  return {
    id: `MAT${Date.now()}`,
    userId: user.id,
    type: "matching",
    amount: bonusAmount,
    date: new Date().toISOString(),
    description: `Matching bonus - Matched volume: $${matchedVolume}`,
    leftVolume: leftVolume,
    rightVolume: rightVolume,
  };
}

// Leadership Bonus Calculation
function calculateLeadershipBonus(user: User, allUsers: User[]): BonusRecord {
  const nefs = NEFS_LEVELS.find((n) => n.level === user.nefsLevel);
  if (!nefs || user.nefsLevel < 4) return { amount: 0 } as BonusRecord; // Sadece level 4+ için

  const teamSize = allUsers.filter((u) =>
    isInDownline(u.id, user.id, allUsers),
  ).length;

  // Liderlik kriteri: En az 50 aktif üye
  if (teamSize >= 50) {
    return {
      id: `LEA${Date.now()}`,
      userId: user.id,
      type: "leadership",
      amount: INCOME_TYPES.leadership.baseAmount,
      date: new Date().toISOString(),
      description: `Leadership bonus - Team size: ${teamSize}`,
    };
  }

  return { amount: 0 } as BonusRecord;
}

// Sales Bonus Calculation
function calculateSalesBonus(user: User): BonusRecord {
  const bonusAmount = (user.personalSales * INCOME_TYPES.sales.rate) / 100;

  return {
    id: `SAL${Date.now()}`,
    userId: user.id,
    type: "sales",
    amount: bonusAmount,
    date: new Date().toISOString(),
    description: `Sales bonus - Personal sales: $${user.personalSales}`,
  };
}

// Passive Income Calculation (Level-based)
function calculatePassiveIncome(user: User, allUsers: User[]): BonusRecord[] {
  const bonuses: BonusRecord[] = [];
  const downlineUsers = allUsers.filter((u) =>
    isInDownline(u.id, user.id, allUsers),
  );

  // Her level için ayrı hesaplama
  INCOME_TYPES.passive.rates.forEach((rate, index) => {
    const level = index + 1;
    const levelUsers = downlineUsers.filter(
      (u) => getDownlineLevel(u.id, user.id, allUsers) === level,
    );

    let levelSales = 0;
    levelUsers.forEach((u) => (levelSales += u.personalSales));

    if (levelSales > 0) {
      const bonusAmount = (levelSales * rate) / 100;

      bonuses.push({
        id: `PAS${Date.now()}_L${level}`,
        userId: user.id,
        type: "passive",
        amount: bonusAmount,
        date: new Date().toISOString(),
        description: `Passive income Level ${level} - Sales: $${levelSales}`,
      });
    }
  });

  return bonuses;
}

// Helper function to check if user is in downline
function isInDownline(
  checkUserId: string,
  uplineUserId: string,
  allUsers: User[],
): boolean {
  const user = allUsers.find((u) => u.id === checkUserId);
  if (!user || !user.parentId) return false;

  if (user.parentId === uplineUserId) return true;

  return isInDownline(user.parentId, uplineUserId, allUsers);
}

// Helper function to get downline level
function getDownlineLevel(
  checkUserId: string,
  uplineUserId: string,
  allUsers: User[],
): number {
  const user = allUsers.find((u) => u.id === checkUserId);
  if (!user || !user.parentId) return 0;

  if (user.parentId === uplineUserId) return 1;

  return 1 + getDownlineLevel(user.parentId, uplineUserId, allUsers);
}

// Renewal System Functions
export function calculateRenewalDate(lastRenewalDate: string): string {
  const lastDate = new Date(lastRenewalDate);
  lastDate.setMonth(lastDate.getMonth() + 1);
  return lastDate.toISOString();
}

export function getDaysUntilRenewal(renewalDate: string): number {
  const renewal = new Date(renewalDate);
  const now = new Date();
  const diffTime = renewal.getTime() - now.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function isRenewalDue(renewalDate: string): boolean {
  return getDaysUntilRenewal(renewalDate) <= 0;
}

export function needsRenewalReminder(renewalDate: string): boolean {
  const daysLeft = getDaysUntilRenewal(renewalDate);
  return daysLeft <= 7 && daysLeft > 0; // 7 gün ve daha az kaldığında
}

// Auto-placement algorithm for binary tree
export function findOptimalPlacement(
  sponsorId: string,
  allUsers: User[],
): { parentId: string; position: "left" | "right" } {
  const sponsor = allUsers.find((u) => u.id === sponsorId);
  if (!sponsor) throw new Error("Sponsor not found");

  // BFS ile en uygun yeri bul
  const queue = [sponsorId];
  const visited = new Set<string>();

  while (queue.length > 0) {
    const currentUserId = queue.shift()!;
    if (visited.has(currentUserId)) continue;
    visited.add(currentUserId);

    const currentUser = allUsers.find((u) => u.id === currentUserId);
    if (!currentUser) continue;

    // Sol pozisyonu kontrol et
    const leftChild = allUsers.find(
      (u) => u.parentId === currentUserId && u.position === "left",
    );
    if (!leftChild) {
      return { parentId: currentUserId, position: "left" };
    }

    // Sağ pozisyonu kontrol et
    const rightChild = allUsers.find(
      (u) => u.parentId === currentUserId && u.position === "right",
    );
    if (!rightChild) {
      return { parentId: currentUserId, position: "right" };
    }

    // Alt seviyeye geç
    queue.push(leftChild.id, rightChild.id);
  }

  // Fallback: Sponsor'un altına yerleştir
  return { parentId: sponsorId, position: "left" };
}

// Network visualization data
export function generateNetworkData(userId: string, allUsers: User[]): any {
  const user = allUsers.find((u) => u.id === userId);
  if (!user) return null;

  const networkData = {
    id: user.id,
    name: `${user.firstName} ${user.lastName}`,
    level: user.nefsLevel,
    sales: user.personalSales,
    earnings: user.totalEarnings,
    children: [] as any[],
  };

  // Sol ve sağ çocukları bul
  const leftChild = allUsers.find(
    (u) => u.parentId === userId && u.position === "left",
  );
  const rightChild = allUsers.find(
    (u) => u.parentId === userId && u.position === "right",
  );

  if (leftChild) {
    networkData.children.push(generateNetworkData(leftChild.id, allUsers));
  }

  if (rightChild) {
    networkData.children.push(generateNetworkData(rightChild.id, allUsers));
  }

  return networkData;
}

// AI-powered earnings prediction
export function predictEarnings(user: User, allUsers: User[]): any {
  const historicalGrowth = calculateGrowthRate(user, allUsers);
  const teamSize = allUsers.filter((u) =>
    isInDownline(u.id, user.id, allUsers),
  ).length;

  // Basit linear regression ile tahmin
  const predictions = {
    nextMonth: user.totalEarnings * (1 + historicalGrowth),
    next3Months: user.totalEarnings * Math.pow(1 + historicalGrowth, 3),
    next6Months: user.totalEarnings * Math.pow(1 + historicalGrowth, 6),
    nextYear: user.totalEarnings * Math.pow(1 + historicalGrowth, 12),
  };

  return {
    predictions,
    confidence: Math.min(teamSize / 100, 0.95), // %95 max güven
    factors: {
      teamGrowthRate: historicalGrowth,
      currentTeamSize: teamSize,
      nefsLevel: user.nefsLevel,
      personalSales: user.personalSales,
    },
  };
}

function calculateGrowthRate(user: User, allUsers: User[]): number {
  // Son 3 ayın verilerine göre büyüme oranı hesapla
  // Bu örnekte sabit %5 kullanıyoruz, gerçek uygulamada geçmiş veriler analiz edilir
  return 0.05;
}

// JWT Token simulation (for frontend)
export function generateToken(user: User): string {
  const header = btoa(JSON.stringify({ typ: "JWT", alg: "HS256" }));
  const payload = btoa(
    JSON.stringify({
      userId: user.id,
      email: user.email,
      role: user.role,
      exp: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    }),
  );
  const signature = btoa("fake-signature-for-demo");

  return `${header}.${payload}.${signature}`;
}

export function validateToken(token: string): boolean {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;

    const payload = JSON.parse(atob(parts[1]));
    return payload.exp > Date.now();
  } catch {
    return false;
  }
}

export function decodeToken(token: string): any {
  try {
    const parts = token.split(".");
    return JSON.parse(atob(parts[1]));
  } catch {
    return null;
  }
}

// Cron job simulation (would be server-side in real app)
export function scheduleBonusDistribution() {
  // Bu fonksiyon gerçek uygulamada sunucu tarafında çalışacak
  console.log("Weekly bonus distribution scheduled...");

  // Her hafta pazar günü çalışacak şekilde ayarlanır
  const now = new Date();
  const nextSunday = new Date(now);
  nextSunday.setDate(now.getDate() + (7 - now.getDay()));
  nextSunday.setHours(0, 0, 0, 0);

  const timeUntilSunday = nextSunday.getTime() - now.getTime();

  setTimeout(() => {
    // Bonus dağıtım işlemi
    distributeBonuses();

    // Bir sonraki hafta için tekrar zamanla
    setInterval(distributeBonuses, 7 * 24 * 60 * 60 * 1000); // 7 gün
  }, timeUntilSunday);
}

function distributeBonuses() {
  console.log("Distributing weekly bonuses...");

  // Tüm kullanıcıları al
  const allUsers: User[] = JSON.parse(localStorage.getItem("allUsers") || "[]");

  allUsers.forEach((user) => {
    if (user.status === "active") {
      // Haftalık bonusları hesapla
      const weeklyBonuses = calculateAllBonuses(user, allUsers, {});

      // Bonusları kullanıcının cüzdanına ekle
      let totalBonus = 0;
      weeklyBonuses.forEach((bonus) => {
        totalBonus += bonus.amount;
      });

      // Kullanıcı verilerini güncelle
      user.walletBalance += totalBonus;
      user.totalEarnings += totalBonus;
      user.bonusHistory.push(...weeklyBonuses);
    }
  });

  // Güncellenmiş verileri kaydet
  localStorage.setItem("allUsers", JSON.stringify(allUsers));

  console.log("Weekly bonuses distributed successfully!");
}
