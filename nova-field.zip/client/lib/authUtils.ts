// Authentication utilities for founder access
export const FOUNDER_EMAIL = "psikologabdulkadirkan@gmail.com";
export const FOUNDER_ID = "MB000001"; // First member ID

// Check if current logged-in user is the founder
export function isFounderLoggedIn(): boolean {
  try {
    const userEmail = localStorage.getItem("userEmail");
    const userAuth = localStorage.getItem("userAuth");

    if (!userAuth || !userEmail) {
      return false;
    }

    return userEmail === FOUNDER_EMAIL;
  } catch {
    return false;
  }
}

// Check if user is founder by email
export function isFounderEmail(email: string): boolean {
  return email === FOUNDER_EMAIL;
}

// Check if user is founder by ID
export function isFounderId(userId: string): boolean {
  return userId === FOUNDER_ID;
}

// Get founder user data
export function createFounderUser() {
  return {
    id: FOUNDER_ID,
    firstName: "Abdulkadir",
    lastName: "Kan",
    email: FOUNDER_EMAIL,
    phone: "+90 532 123 45 67",
    sponsorId: "SYSTEM",
    nefsLevel: 7, // Highest level
    status: "active",
    accountType: "active",
    joinDate: "2024-01-01T00:00:00.000Z",
    renewalDate: "2025-01-01T00:00:00.000Z",
    lastRenewalDate: "2024-01-01T00:00:00.000Z",
    position: null,
    parentId: undefined,
    leftLegVolume: 0,
    rightLegVolume: 0,
    personalSales: 10000,
    totalEarnings: 50000,
    walletBalance: 25000,
    bonusHistory: [],
    renewalHistory: [],
    loginHistory: [],
    twoFactorEnabled: false,
    role: "admin" as const,
  };
}

// Initialize founder as first user if not exists
export function initializeFounder() {
  const allUsers = JSON.parse(localStorage.getItem("allUsers") || "[]");

  // Check if founder already exists
  const founderExists = allUsers.find((u: any) => u.email === FOUNDER_EMAIL);

  if (!founderExists) {
    const founder = createFounderUser();
    allUsers.unshift(founder); // Add as first user
    localStorage.setItem("allUsers", JSON.stringify(allUsers));
    console.log("Founder user initialized");
  }
}
